
# Full Codebase Documentation

## Server-Side Code

### server/index.ts
Main Express server setup with logging middleware running on port 5000.

### server/routes.ts
Route registration and HTTP server setup.

### server/storage.ts
Storage interface implementation for data persistence.

### server/vite.ts
Vite configuration for server-side rendering.

## Client-Side Code

### client/src/App.tsx
Main React application with routing and animations.

### client/src/lib/queryClient.ts
```typescript
import { QueryClient, QueryFunction } from "@tanstack/react-query";

async function throwIfResNotOk(res: Response) {
  if (!res.ok) {
    const text = (await res.text()) || res.statusText;
    throw new Error(`${res.status}: ${text}`);
  }
}

export async function apiRequest(
  method: string,
  url: string,
  data?: unknown | undefined,
): Promise<Response> {
  const res = await fetch(url, {
    method,
    headers: data ? { "Content-Type": "application/json" } : {},
    body: data ? JSON.stringify(data) : undefined,
    credentials: "include",
  });

  await throwIfResNotOk(res);
  return res;
}

type UnauthorizedBehavior = "returnNull" | "throw";
export const getQueryFn: <T>(options: {
  on401: UnauthorizedBehavior;
}) => QueryFunction<T> =
  ({ on401: unauthorizedBehavior }) =>
  async ({ queryKey }) => {
    const res = await fetch(queryKey[0] as string, {
      credentials: "include",
    });

    if (unauthorizedBehavior === "returnNull" && res.status === 401) {
      return null;
    }

    await throwIfResNotOk(res);
    return await res.json();
  };

export const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      queryFn: getQueryFn({ on401: "throw" }),
      refetchInterval: false,
      refetchOnWindowFocus: false,
      staleTime: Infinity,
      retry: false,
    },
    mutations: {
      retry: false,
    },
  },
});
```

### client/src/components/ParticleBackground.tsx
```typescript
// Particle system implementation
const generateGradient = () => {
  const gradient = ctx.createLinearGradient(0, 0, width, height);
  gradient.addColorStop(0, `${color}FF`);
  gradient.addColorStop(1, `${color}00`);
  return gradient;
};

const init = () => {
  canvas.width = width;
  canvas.height = height;
  offscreenCanvas.width = width;
  offscreenCanvas.height = height;
  
  particles = [];
  const totalParticles = Math.floor((width * height) / 15000) * density;
  
  for (let i = 0; i < totalParticles; i++) {
    const size = Math.random() * 2.5 + 0.5;
    const x = Math.random() * width;
    const y = Math.random() * height;
    
    particles.push(new Particle(x, y, size, color, i));
  }
  
  setIsLoaded(true);
};
```

### client/src/components/ui/sidebar.tsx
```typescript
const SidebarMenuItem = React.forwardRef<
  HTMLLIElement,
  React.ComponentProps<"li">
>(({ className, ...props }, ref) => (
  <li
    ref={ref}
    data-sidebar="menu-item"
    className={cn("group/menu-item relative", className)}
    {...props}
  />
))
SidebarMenuItem.displayName = "SidebarMenuItem"
```

## Configuration Files

### Project Dependencies (package.json)
```json
{
  "name": "rest-express",
  "version": "1.0.0",
  "type": "module",
  "license": "MIT",
  "scripts": {
    "dev": "tsx server/index.ts",
    "build": "vite build && esbuild server/index.ts --platform=node --packages=external --bundle --format=esm --outdir=dist",
    "start": "NODE_ENV=production node dist/index.js",
    "check": "tsc",
    "db:push": "drizzle-kit push"
  }
}
```

### Replit Configuration (.replit)
```
modules = ["nodejs-20", "web", "postgresql-16"]
run = "npm run dev"
hidden = [".config", ".git", "generated-icon.png", "node_modules", "dist"]

[deployment]
deploymentTarget = "autoscale"
build = ["npm", "run", "build"]
run = ["npm", "run", "start"]

[[ports]]
localPort = 5000
externalPort = 80
```

## Tech Stack Overview
- Frontend: React with TypeScript
- Backend: Express.js
- Database: PostgreSQL with Drizzle ORM
- Styling: Tailwind CSS
- Animations: GSAP
- Development: Vite
- Deployment: Replit Autoscale

All the code is contained within this Replit project and can be accessed through the file system or this documentation.
