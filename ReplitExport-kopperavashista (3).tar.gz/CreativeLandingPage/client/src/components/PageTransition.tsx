import { ReactNode, useEffect, useRef, useState, useCallback, useMemo } from "react";
import { motion, useMotionValue, useTransform, useSpring, AnimatePresence, useAnimation } from "framer-motion";
import { useLocation } from "wouter";
import { useIsMobile } from "../hooks/use-mobile";
import gsap from "gsap";

interface PageTransitionProps {
  children: ReactNode;
  index: number;
  direction?: number;
}

// Ultra-premium macOS-inspired variants
const macVariants = {
  // Initial state - complex multi-effect entry
  initial: (direction: number) => ({
    opacity: 0,
    scale: direction > 0 ? 0.85 : 0.9,
    rotateY: direction > 0 ? '2.5deg' : '-2.5deg',
    filter: "brightness(1.1) contrast(1.05) blur(8px) saturate(1.1)",
    y: direction > 0 ? 10 : -10,
    transformPerspective: 1000,
    transformOrigin: direction > 0 ? 'left center' : 'right center',
    transition: {
      duration: 0
    }
  }),
  // Animated state - precise control with professional timing
  animate: {
    opacity: 1,
    scale: 1,
    rotateY: '0deg',
    y: 0,
    filter: "brightness(1) contrast(1) blur(0px) saturate(1)",
    transition: {
      opacity: { duration: 0.6, ease: [0.23, 1, 0.32, 1] },
      scale: { type: "spring", stiffness: 350, damping: 34, mass: 0.75 },
      rotateY: { duration: 0.8, ease: [0.17, 0.67, 0.83, 0.97] },
      y: { type: "spring", stiffness: 400, damping: 40 },
      filter: { duration: 0.7, ease: [0.16, 1, 0.3, 1] },
      delay: 0.05
    }
  },
  // Exit state - sophisticated departure effect
  exit: (direction: number) => ({
    opacity: 0,
    scale: 1.02,
    rotateY: direction > 0 ? '-2.5deg' : '2.5deg',
    filter: "brightness(1.25) contrast(1.05) blur(10px) saturate(0.95)",
    y: direction > 0 ? -20 : 20,
    transition: {
      opacity: { duration: 0.5, ease: [0.36, 0.66, 0.04, 1] },
      scale: { duration: 0.5, ease: [0.22, 1, 0.36, 1] },
      rotateY: { duration: 0.5, ease: [0.22, 1, 0.36, 1] },
      filter: { duration: 0.4, ease: [0.43, 0.13, 0.23, 0.96] },
      y: { duration: 0.5, ease: [0.43, 0.13, 0.23, 0.96] }
    }
  })
};

// iOS-inspired slide-up modal transition
const iosVariants = {
  initial: (direction: number) => ({
    opacity: 0.5,
    y: direction >= 0 ? '5%' : '-5%',
    scale: 0.92,
    filter: "brightness(0.95) blur(6px)",
    transition: { duration: 0 }
  }),
  animate: {
    opacity: 1,
    y: 0,
    scale: 1,
    filter: "brightness(1) blur(0px)",
    transition: {
      opacity: { duration: 0.5, ease: [0.16, 1, 0.3, 1] },
      y: { type: "spring", stiffness: 300, damping: 30, mass: 1 },
      scale: { duration: 0.6, ease: [0.34, 1.56, 0.64, 1] },
      filter: { duration: 0.5, ease: [0.34, 1.56, 0.64, 1] }
    }
  },
  exit: (direction: number) => ({
    opacity: 0,
    y: direction >= 0 ? '-5%' : '5%',
    scale: 0.95,
    filter: "brightness(1.1) blur(6px)",
    transition: {
      opacity: { duration: 0.3, ease: [0.36, 0, 0.66, -0.56] },
      y: { duration: 0.5, ease: [0.36, 0, 0.66, -0.56] },
      scale: { duration: 0.5, ease: [0.36, 0, 0.66, -0.56] },
      filter: { duration: 0.2, ease: [0.36, 0, 0.66, -0.56] }
    }
  })
};

// Mobile-optimized variants
const mobileVariants = {
  initial: (direction: number) => ({
    opacity: 0,
    y: direction > 0 ? 10 : -10,
    filter: "brightness(1.1) blur(4px)",
    transition: { duration: 0 }
  }),
  animate: {
    opacity: 1,
    y: 0,
    filter: "brightness(1) blur(0px)",
    transition: {
      opacity: { duration: 0.4, ease: "easeOut" },
      y: { type: "spring", stiffness: 250, damping: 30 },
      filter: { duration: 0.4, ease: "easeOut" }
    }
  },
  exit: (direction: number) => ({
    opacity: 0,
    y: direction > 0 ? -10 : 10,
    filter: "brightness(1.1) blur(4px)",
    transition: {
      opacity: { duration: 0.3, ease: "easeIn" },
      y: { duration: 0.4, ease: "easeIn" },
      filter: { duration: 0.3, ease: "easeIn" }
    }
  })
};

export default function PageTransition({ children, index, direction = 0 }: PageTransitionProps) {
  const [location] = useLocation();
  const contentRef = useRef<HTMLDivElement>(null);
  const overlayRef = useRef<HTMLDivElement>(null);
  const isMobile = useIsMobile();
  const controls = useAnimation();

  // Track animation direction
  const animationDirection = useRef(direction);
  
  // States for complex effects
  const [isFlashing, setIsFlashing] = useState(false);
  const [hasGlitch, setHasGlitch] = useState(false);
  const [hasRipple, setHasRipple] = useState(false);
  
  // Ref for ripple position
  const ripplePosition = useRef({ x: 0, y: 0 });
  
  // Check for reduced motion preference
  const [prefersReducedMotion, setPrefersReducedMotion] = useState(false);
  
  useEffect(() => {
    const mediaQuery = window.matchMedia('(prefers-reduced-motion: reduce)');
    setPrefersReducedMotion(mediaQuery.matches);
    
    const handleMediaChange = (e: MediaQueryListEvent) => {
      setPrefersReducedMotion(e.matches);
    };
    
    mediaQuery.addEventListener('change', handleMediaChange);
    return () => mediaQuery.removeEventListener('change', handleMediaChange);
  }, []);
  
  // Motion values for parallax, depth, and 3D effects
  const mouseX = useMotionValue(0);
  const mouseY = useMotionValue(0);
  const rotateX = useTransform(mouseY, [-300, 300], [2, -2]);
  const rotateY = useTransform(mouseX, [-300, 300], [-2, 2]);
  
  // Enhanced 3D transforms with physics-based springs
  const springConfig = { stiffness: 150, damping: 25, mass: 0.5 };
  const springX = useSpring(mouseX, springConfig);
  const springY = useSpring(mouseY, springConfig);
  const springRotateX = useSpring(rotateX, springConfig);
  const springRotateY = useSpring(rotateY, springConfig);
  
  // Parallax effect intensity based on device
  const parallaxFactor = useMemo(() => isMobile ? 0.005 : 0.02, [isMobile]);
  
  // Premium ripple effect on page changes
  const createRippleEffect = useCallback((x: number, y: number) => {
    if (prefersReducedMotion) return;
    
    // Store ripple position
    ripplePosition.current = { x, y };
    
    // Trigger ripple effect
    setHasRipple(true);
    setTimeout(() => setHasRipple(false), 1000);
  }, [prefersReducedMotion]);
  
  // GSAP-powered glitch effect
  const createGlitchEffect = useCallback(() => {
    if (prefersReducedMotion || !contentRef.current) return;
    
    setHasGlitch(true);
    
    const glitchTimeline = gsap.timeline({
      onComplete: () => setHasGlitch(false)
    });
    
    // Series of rapid micro-movements and filter changes
    for (let i = 0; i < 5; i++) {
      glitchTimeline.to(contentRef.current, {
        x: gsap.utils.random(-5, 5),
        y: gsap.utils.random(-5, 5),
        skewX: gsap.utils.random(-2, 2),
        skewY: gsap.utils.random(-1, 1),
        opacity: gsap.utils.random(0.8, 1),
        duration: 0.05
      });
    }
    
    // Reset back to normal
    glitchTimeline.to(contentRef.current, {
      x: 0,
      y: 0,
      skewX: 0,
      skewY: 0,
      opacity: 1,
      duration: 0.1
    });
    
  }, [prefersReducedMotion]);
  
  // Enhanced parallax effect on mouse move (Apple-like)
  useEffect(() => {
    if (isMobile || prefersReducedMotion) return;
    
    const handleMouseMove = (e: MouseEvent) => {
      // Calculate position relative to center of screen
      const centerX = window.innerWidth / 2;
      const centerY = window.innerHeight / 2;
      
      // Apply subtle movement
      mouseX.set((e.clientX - centerX) * parallaxFactor);
      mouseY.set((e.clientY - centerY) * parallaxFactor);
    };
    
    window.addEventListener("mousemove", handleMouseMove);
    return () => window.removeEventListener("mousemove", handleMouseMove);
  }, [mouseX, mouseY, isMobile, prefersReducedMotion, parallaxFactor]);
  
  // Update direction and trigger effects when changing pages
  useEffect(() => {
    animationDirection.current = direction;
    
    // Skip effects for reduced motion
    if (prefersReducedMotion) return;
    
    // Trigger flash effect
    setIsFlashing(true);
    setTimeout(() => setIsFlashing(false), 300);
    
    // 50% chance of glitch effect for variety
    if (Math.random() > 0.5) {
      setTimeout(() => createGlitchEffect(), 100);
    }
    
    // Create ripple from center point
    createRippleEffect(window.innerWidth / 2, window.innerHeight / 2);
    
    // Trigger GSAP animation sequence
    if (contentRef.current) {
      gsap.fromTo(
        contentRef.current,
        { 
          filter: "hue-rotate(5deg) brightness(1.05)",
          boxShadow: "0 0 40px rgba(255, 255, 255, 0.15)"
        },
        { 
          filter: "hue-rotate(0deg) brightness(1)",
          boxShadow: "0 0 0px rgba(255, 255, 255, 0)",
          duration: 0.8,
          ease: "power3.out"
        }
      );
    }
    
  }, [direction, prefersReducedMotion, createGlitchEffect, createRippleEffect]);

  // Choose transition variants based on device and preference
  const transitionVariants = useMemo(() => {
    if (prefersReducedMotion) return mobileVariants;
    if (isMobile) return iosVariants;
    return macVariants;
  }, [prefersReducedMotion, isMobile]);

  return (
    <>
      {/* Flash effect overlay */}
      <AnimatePresence>
        {isFlashing && !prefersReducedMotion && (
          <motion.div 
            className="fixed inset-0 bg-white z-[100] pointer-events-none"
            initial={{ opacity: 0 }}
            animate={{ opacity: 0.2 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.2 }}
            key="flash-overlay"
            ref={overlayRef}
          />
        )}
      </AnimatePresence>
      
      {/* Ripple effect overlay */}
      <AnimatePresence>
        {hasRipple && !prefersReducedMotion && (
          <motion.div
            className="fixed z-[99] pointer-events-none overflow-hidden"
            initial={{ 
              width: 0, 
              height: 0,
              x: ripplePosition.current.x,
              y: ripplePosition.current.y,
              borderRadius: '50%',
              opacity: 0.8,
              background: 'radial-gradient(circle, rgba(255,255,255,0.6) 0%, rgba(255,255,255,0) 70%)'
            }}
            animate={{ 
              width: Math.max(window.innerWidth, window.innerHeight) * 2,
              height: Math.max(window.innerWidth, window.innerHeight) * 2,
              x: ripplePosition.current.x - Math.max(window.innerWidth, window.innerHeight),
              y: ripplePosition.current.y - Math.max(window.innerWidth, window.innerHeight),
              opacity: 0
            }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.8, ease: [0.22, 1, 0.36, 1] }}
            key="ripple-overlay"
            style={{
              transformOrigin: 'center'
            }}
          />
        )}
      </AnimatePresence>
      
      {/* Glitch effect overlay */}
      <AnimatePresence>
        {hasGlitch && !prefersReducedMotion && (
          <motion.div
            className="fixed inset-0 z-[98] pointer-events-none mix-blend-screen"
            initial={{ opacity: 0 }}
            animate={{ opacity: 0.5 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.2 }}
            key="glitch-overlay"
            style={{
              backgroundImage: 'linear-gradient(to bottom, rgba(255,0,0,0.1), rgba(0,255,255,0.1))',
              backgroundSize: '200% 100%',
              animation: 'noise 0.2s steps(2) infinite'
            }}
          />
        )}
      </AnimatePresence>
      
      {/* Main content with premium transitions */}
      <motion.div
        custom={animationDirection.current}
        variants={transitionVariants}
        initial="initial"
        animate="animate"
        exit="exit"
        className="w-full h-full overflow-hidden"
        style={{
          x: !isMobile && !prefersReducedMotion ? springX : 0,
          y: !isMobile && !prefersReducedMotion ? springY : 0,
          rotateX: !isMobile && !prefersReducedMotion ? springRotateX : 0,
          rotateY: !isMobile && !prefersReducedMotion ? springRotateY : 0,
          perspective: 1000,
          transformStyle: "preserve-3d"
        }}
        ref={contentRef}
      >
        {children}
      </motion.div>
      
      {/* Extra noise texture overlay for premium feel */}
      {!prefersReducedMotion && (
        <div 
          className="fixed inset-0 pointer-events-none z-[90] opacity-[0.015] mix-blend-overlay"
          style={{
            backgroundImage: 'url("data:image/svg+xml,%3Csvg viewBox=\'0 0 250 250\' xmlns=\'http://www.w3.org/2000/svg\'%3E%3Cfilter id=\'noiseFilter\'%3E%3CfeTurbulence type=\'fractalNoise\' baseFrequency=\'0.65\' numOctaves=\'3\' stitchTiles=\'stitch\'/%3E%3C/filter%3E%3Crect width=\'100%25\' height=\'100%25\' filter=\'url(%23noiseFilter)\'/%3E%3C/svg%3E")',
            backgroundSize: '200px 200px'
          }}
        />
      )}
    </>
  );
}