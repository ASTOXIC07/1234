import { useEffect, useRef } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

// Register ScrollTrigger plugin
gsap.registerPlugin(ScrollTrigger);

export default function CTASection() {
  const sectionRef = useRef<HTMLElement>(null);

  useEffect(() => {
    if (!sectionRef.current) return;

    // Set initial state
    gsap.set(sectionRef.current, { opacity: 0 });

    // Create ScrollTrigger animation
    const trigger = ScrollTrigger.create({
      trigger: sectionRef.current,
      start: "top 70%",
      onEnter: () => {
        gsap.to(sectionRef.current, {
          opacity: 1,
          duration: 1,
          ease: "power2.out"
        });
      },
      once: true
    });

    return () => {
      trigger.kill();
    };
  }, []);

  return (
    <section 
      id="cta" 
      ref={sectionRef}
      className="py-20 md:py-32 px-6 opacity-0"
    >
      <div className="container mx-auto max-w-4xl">
        <div className="bg-gradient-to-r from-[#6366F1] to-[#EC4899] bg-[length:400%_400%] animate-[gradient_15s_ease_infinite] rounded-2xl p-10 md:p-16 shadow-xl text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-6">Ready to Create Amazing Animations?</h2>
          <p className="text-xl mb-10 max-w-2xl mx-auto">
            Start building engaging user experiences that will captivate your audience and elevate your brand.
          </p>
          <button className="bg-[#F8FAFC] text-[#6366F1] px-8 py-4 rounded-full font-semibold text-lg shadow-lg hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1 animate-[pulse_2s_infinite]">
            Get Started Today
          </button>
        </div>
      </div>
    </section>
  );
}

// Add the required keyframes animation to global CSS in the App component
