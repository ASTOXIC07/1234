import { motion } from "framer-motion";

interface PageIndicatorProps {
  pages: Array<{
    id: string;
    path: string;
    title: string;
  }>;
  currentPageIndex: number;
  navigateTo: (index: number) => void;
}

export default function PageIndicator({ pages, currentPageIndex, navigateTo }: PageIndicatorProps) {
  return (
    <motion.div 
      className="fixed right-8 top-1/2 transform -translate-y-1/2 z-40 flex flex-col gap-5 items-center"
      initial={{ opacity: 0, x: 20 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ 
        delay: 1, 
        duration: 0.8, 
        ease: [0.16, 1, 0.3, 1] 
      }}
    >
      {pages.map((page, index) => (
        <motion.button
          key={page.id}
          className="relative w-2 h-2 rounded-full focus:outline-none group"
          onClick={() => navigateTo(index)}
          whileHover={{ scale: 1.2 }}
          whileTap={{ scale: 0.9 }}
        >
          {/* Indicator dot */}
          <motion.div 
            className={`absolute inset-0 rounded-full ${
              currentPageIndex === index 
                ? "bg-white" 
                : "bg-white/30"
            }`}
            animate={{
              scale: currentPageIndex === index ? 1 : 0.8,
            }}
            transition={{ 
              duration: 0.3, 
              ease: [0.16, 1, 0.3, 1]
            }}
          />
          
          {/* Label that appears on hover */}
          <div className="absolute right-full mr-3 top-1/2 transform -translate-y-1/2 opacity-0 group-hover:opacity-100 transition-opacity duration-200">
            <div className="py-1 px-3 bg-black/40 backdrop-blur-md rounded-full whitespace-nowrap text-white text-xs font-light">
              {page.title}
            </div>
          </div>
        </motion.button>
      ))}
    </motion.div>
  );
}