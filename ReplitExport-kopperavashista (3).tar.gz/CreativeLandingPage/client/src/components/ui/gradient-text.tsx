import { FC, ReactNode } from "react";
import { cn } from "../../lib/utils";

interface GradientTextProps {
  children: ReactNode;
  className?: string;
}

export const GradientText: FC<GradientTextProps> = ({ children, className = '' }) => {
  return (
    <span className={cn(
      "bg-gradient-to-r from-[#4F46E5] to-[#0EA5E9] bg-clip-text text-transparent",
      className
    )}>
      {children}
    </span>
  );
};