import { ReactNode } from "react";
import { motion } from "framer-motion";

interface FeatureCardProps {
  icon: ReactNode;
  title: string;
  description: string;
  delay?: number;
}

export function FeatureCard({ icon, title, description, delay = 0 }: FeatureCardProps) {
  return (
    <motion.div
      className="relative bg-[#0A0A1B] rounded-2xl p-8 border border-[#1E1E3F] overflow-hidden group"
      initial={{ opacity: 0, y: 50 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-100px" }}
      transition={{ duration: 0.7, delay, ease: [0.22, 1, 0.36, 1] }}
    >
      {/* Glow effect */}
      <div className="absolute -inset-[1px] bg-gradient-to-r from-transparent via-[#4F46E5]/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-700 blur-sm" />
      
      <div className="flex flex-col space-y-4">
        <div className="w-14 h-14 rounded-xl bg-gradient-to-br from-[#4F46E5] to-[#0EA5E9] flex items-center justify-center text-white">
          {icon}
        </div>
        
        <h3 className="text-xl font-semibold text-white group-hover:text-[#8B5CF6] transition-colors duration-300">
          {title}
        </h3>
        
        <p className="text-[#94A3B8] group-hover:text-gray-300 transition-colors duration-300">
          {description}
        </p>
      </div>
      
      {/* Hover effect */}
      <motion.div
        className="absolute -bottom-1 -right-1 w-32 h-32 bg-gradient-to-br from-[#4F46E5]/10 to-[#0EA5E9]/10 rounded-full blur-xl opacity-0 group-hover:opacity-100 transition-opacity duration-700"
        initial={{ scale: 0.8 }}
        whileHover={{ scale: 1.2 }}
      />
    </motion.div>
  );
}