import { ButtonHTMLAttributes } from "react";
import { cn } from "../../lib/utils";

interface NeonButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: "primary" | "secondary";
  size?: "sm" | "md" | "lg";
  glowing?: boolean;
}

export function NeonButton({
  children,
  className,
  variant = "primary",
  size = "md",
  glowing = true,
  ...props
}: NeonButtonProps) {
  const variantStyles = {
    primary: "bg-gradient-to-r from-[#4F46E5] to-[#0EA5E9] text-white",
    secondary: "bg-[#030014] border border-[#4F46E5] text-[#4F46E5]",
  };

  const sizeStyles = {
    sm: "px-4 py-2 text-sm",
    md: "px-6 py-3 text-base",
    lg: "px-8 py-4 text-lg",
  };

  const glowStyle = glowing
    ? "hover:shadow-[0_0_15px_rgba(79,70,229,0.5)] shadow-[0_0_5px_rgba(79,70,229,0.3)]"
    : "";

  return (
    <button
      className={cn(
        "rounded-full font-medium transition-all duration-300 transform hover:-translate-y-1 relative overflow-hidden",
        variantStyles[variant],
        sizeStyles[size],
        glowStyle,
        className
      )}
      {...props}
    >
      {variant === "primary" && (
        <span className="absolute inset-0 w-full h-full bg-gradient-to-r from-[#4F46E5] to-[#0EA5E9] bg-[length:200%_100%] animate-[gradient_3s_ease_infinite] opacity-85"></span>
      )}
      <span className="relative z-10">{children}</span>
    </button>
  );
}