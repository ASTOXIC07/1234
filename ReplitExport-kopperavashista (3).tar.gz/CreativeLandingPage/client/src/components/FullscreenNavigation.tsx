import { useEffect, useRef } from "react";
import { motion, AnimatePresence } from "framer-motion";

interface FullscreenNavigationProps {
  isOpen: boolean;
  onClose: () => void;
  pages: Array<{
    id: string;
    path: string;
    title: string;
  }>;
  currentPageIndex: number;
  navigateTo: (index: number) => void;
}

export default function FullscreenNavigation({ 
  isOpen, 
  onClose, 
  pages, 
  currentPageIndex, 
  navigateTo 
}: FullscreenNavigationProps) {
  // Ref for the container to detect click outside
  const containerRef = useRef<HTMLDivElement>(null);
  
  // Handle keyboard shortcuts (ESC to close)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === "Escape" && isOpen) {
        onClose();
      }
    };
    
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [isOpen, onClose]);
  
  // Function to get a description for each page
  function getPageDescription(pageId: string): string {
    switch (pageId) {
      case "home":
        return "Discover our vision and mission";
      case "features":
        return "Explore our powerful capabilities";
      case "showcase":
        return "See our platform in action";
      case "contact":
        return "Connect with our team";
      default:
        return "";
    }
  }
  
  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-50 overflow-hidden">
          {/* Backdrop with Apple-style blur */}
          <motion.div
            className="absolute inset-0 bg-black/60 backdrop-blur-xl"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ 
              duration: 0.3, 
              ease: [0.16, 1, 0.3, 1] 
            }}
            onClick={onClose}
          />
          
          {/* Main content container */}
          <motion.div
            className="absolute inset-0 z-10 flex items-center justify-center p-6"
            initial={{ opacity: 0, scale: 0.98 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.98 }}
            transition={{ 
              duration: 0.4, 
              ease: [0.16, 1, 0.3, 1] 
            }}
            ref={containerRef}
          >
            {/* Close button */}
            <motion.button
              className="absolute top-6 right-6 w-10 h-10 rounded-full bg-white/10 backdrop-blur-lg flex items-center justify-center text-white/90 border border-white/10 z-20"
              onClick={onClose}
              whileHover={{ scale: 1.05, backgroundColor: "rgba(255, 255, 255, 0.15)" }}
              whileTap={{ scale: 0.95 }}
            >
              <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
                <line x1="18" y1="6" x2="6" y2="18"></line>
                <line x1="6" y1="6" x2="18" y2="18"></line>
              </svg>
            </motion.button>
            
            {/* Navigation links */}
            <div className="w-full max-w-2xl mx-auto">
              <nav className="space-y-5">
                {pages.map((page, index) => (
                  <motion.div
                    key={page.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ 
                      delay: 0.1 + index * 0.05, 
                      duration: 0.5, 
                      ease: [0.16, 1, 0.3, 1] 
                    }}
                  >
                    <motion.button
                      className={`w-full text-left p-5 rounded-2xl backdrop-blur-lg border ${
                        currentPageIndex === index 
                          ? "bg-white/10 border-white/20" 
                          : "bg-white/5 border-white/10 hover:bg-white/10"
                      } transition-colors duration-200`}
                      onClick={() => navigateTo(index)}
                      whileHover={{ scale: 1.02 }}
                      whileTap={{ scale: 0.98 }}
                    >
                      <div className="flex items-center justify-between">
                        <div>
                          <h3 className="text-xl font-light text-white mb-1">{page.title}</h3>
                          <p className="text-sm text-white/60 font-light">{getPageDescription(page.id)}</p>
                        </div>
                        
                        <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                          currentPageIndex === index ? "bg-blue-500 text-white" : "bg-white/10 text-white/60"
                        }`}>
                          {currentPageIndex === index ? (
                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                              <polyline points="20 6 9 17 4 12"></polyline>
                            </svg>
                          ) : (
                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                              <path d="m9 18 6-6-6-6"></path>
                            </svg>
                          )}
                        </div>
                      </div>
                    </motion.button>
                  </motion.div>
                ))}
              </nav>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}