import { useEffect, useRef } from 'react';
import gsap from 'gsap';
import { GradientText } from '@/components/ui/gradient-text';

export default function HeroSection() {
  const titleRef = useRef<HTMLHeadingElement>(null);
  const subtitleRef = useRef<HTMLParagraphElement>(null);
  const buttonRef = useRef<HTMLDivElement>(null);
  const scrollRef = useRef<HTMLDivElement>(null);

  const scrollToFeatures = () => {
    const featuresSection = document.getElementById("features");
    if (featuresSection) {
      const navHeight = document.querySelector("nav")?.offsetHeight || 0;
      const targetPosition = featuresSection.offsetTop - navHeight;
      
      window.scrollTo({
        top: targetPosition,
        behavior: "smooth",
      });
    }
  };

  // Typewriter effect
  const typewriterEffect = (element: HTMLElement, text: string) => {
    const duration = 0.05; // Duration per character
    const timeline = gsap.timeline();
    
    // Set initial state
    gsap.set(element, { 
      autoAlpha: 1,
      innerHTML: '' 
    });
    
    // Add each character with a staggered animation
    for (let i = 0; i < text.length; i++) {
      timeline.add(() => {
        element.innerHTML = text.substring(0, i + 1) + 
          (i < text.length - 1 ? '<span class="border-r-2 border-[#F8FAFC]"></span>' : '');
      }, i * duration);
    }
    
    return timeline;
  };

  useEffect(() => {
    const timeline = gsap.timeline({ defaults: { ease: "power2.out" } });
    
    if (titleRef.current) {
      const titleElement = titleRef.current;
      const titleText = titleElement.innerText;
      
      // Clear the title first
      titleElement.innerHTML = '';
      titleElement.style.opacity = '1';
      
      // Start the animation sequence
      timeline
        .add(typewriterEffect(titleElement, titleText))
        .to(subtitleRef.current, { opacity: 1, y: 0, duration: 1 }, "-=0.5")
        .to(buttonRef.current, { opacity: 1, y: 0, duration: 0.8 }, "-=0.7")
        .to(scrollRef.current, { opacity: 1, y: 0, duration: 0.8 }, "-=0.5");
    }
    
    return () => {
      timeline.kill();
    };
  }, []);

  return (
    <section id="hero" className="pt-28 md:pt-40 pb-20 md:pb-32 px-6">
      <div className="container mx-auto text-center">
        <h1 
          ref={titleRef}
          className="text-4xl md:text-6xl font-bold mb-6 opacity-0 text-[#F8FAFC] whitespace-pre-line"
        >
          Create Stunning <GradientText>Animations</GradientText>
        </h1>
        
        <p 
          ref={subtitleRef}
          className="text-xl md:text-2xl max-w-2xl mx-auto mb-10 opacity-0 transform translate-y-4 transition-all duration-300"
        >
          Engage your audience with smooth scrolling effects and interactive elements that leave a lasting impression.
        </p>
        
        <div 
          ref={buttonRef}
          className="flex justify-center opacity-0 transform translate-y-4"
        >
          <button 
            className="bg-gradient-to-r from-[#6366F1] to-[#EC4899] px-8 py-4 rounded-full font-medium text-[#F8FAFC] shadow-lg hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1 hover:scale-105"
            onClick={scrollToFeatures}
          >
            Get Started
          </button>
        </div>
        
        <div 
          ref={scrollRef}
          className="mt-16 opacity-0 transform translate-y-4"
        >
          <div className="w-6 h-10 rounded-full border-2 border-[#F8FAFC] mx-auto flex justify-center">
            <div className="w-1 h-3 bg-[#F8FAFC] rounded-full mt-2 animate-bounce"></div>
          </div>
          <p className="mt-2 text-sm">Scroll Down</p>
        </div>
      </div>
    </section>
  );
}
