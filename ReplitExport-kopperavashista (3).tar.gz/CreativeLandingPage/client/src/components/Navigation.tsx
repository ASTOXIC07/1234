import { useState, useEffect } from "react";
import { useLocation, Link } from "wouter";
import { motion, AnimatePresence } from "framer-motion";

export default function Navigation() {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);
  const [location] = useLocation();

  // Handle scroll event to add background to nav when scrolled
  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10);
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const toggleMobileMenu = () => {
    setIsMobileMenuOpen(!isMobileMenuOpen);
  };

  const closeMobileMenu = () => {
    setIsMobileMenuOpen(false);
  };

  return (
    <motion.nav 
      className={`fixed w-full z-50 transition-all duration-300 ${isScrolled ? 'bg-[#030014]/90 backdrop-blur-md shadow-md' : 'bg-transparent'}`}
      initial={{ opacity: 0, y: -20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
    >
      <div className="container mx-auto px-6 py-4 flex justify-between items-center">
        <Link href="/">
          <a className="text-2xl font-bold group flex items-center">
            <span className="bg-gradient-to-r from-[#4F46E5] to-[#0EA5E9] bg-clip-text text-transparent group-hover:from-[#7C3AED] group-hover:to-[#2563EB] transition-all duration-300">Neura</span>
            <span className="text-[#F8FAFC] group-hover:text-purple-300 transition-all duration-300">Flow</span>
          </a>
        </Link>
        
        <div className="hidden md:flex space-x-10">
          <NavLink href="/" label="Home" currentPath={location} onClick={closeMobileMenu} />
          <NavLink href="/features" label="Features" currentPath={location} onClick={closeMobileMenu} />
          <NavLink href="/showcase" label="Showcase" currentPath={location} onClick={closeMobileMenu} />
          <NavLink href="/contact" label="Contact" currentPath={location} onClick={closeMobileMenu} />
        </div>
        
        <button 
          className="md:hidden text-2xl text-[#F8FAFC]" 
          onClick={toggleMobileMenu}
          aria-label="Toggle menu"
        >
          {isMobileMenuOpen ? "✕" : "☰"}
        </button>
      </div>
      
      <AnimatePresence>
        {isMobileMenuOpen && (
          <motion.div 
            className="md:hidden bg-[#030014]/95 backdrop-blur-md w-full absolute"
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ duration: 0.3 }}
          >
            <div className="container mx-auto px-6 py-6 flex flex-col space-y-5">
              <NavLink href="/" label="Home" currentPath={location} onClick={closeMobileMenu} mobile />
              <NavLink href="/features" label="Features" currentPath={location} onClick={closeMobileMenu} mobile />
              <NavLink href="/showcase" label="Showcase" currentPath={location} onClick={closeMobileMenu} mobile />
              <NavLink href="/contact" label="Contact" currentPath={location} onClick={closeMobileMenu} mobile />
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.nav>
  );
}

interface NavLinkProps {
  href: string;
  label: string;
  currentPath: string;
  onClick: () => void;
  mobile?: boolean;
}

function NavLink({ href, label, currentPath, onClick, mobile = false }: NavLinkProps) {
  const isActive = currentPath === href;
  
  return (
    <Link href={href}>
      <a 
        onClick={onClick}
        className={`relative ${mobile ? 'text-left text-lg' : ''} ${isActive 
          ? 'text-[#8B5CF6]' 
          : 'text-[#F8FAFC] hover:text-[#8B5CF6]'} 
          transition-colors duration-300 group`}
      >
        {label}
        <motion.span 
          className="absolute -bottom-1 left-0 w-0 h-[2px] bg-gradient-to-r from-[#4F46E5] to-[#0EA5E9] group-hover:w-full transition-all duration-300"
          initial={{ width: isActive ? '100%' : '0%' }}
          animate={{ width: isActive ? '100%' : '0%' }}
          exit={{ width: '0%' }}
        />
      </a>
    </Link>
  );
}
