import { useEffect, useRef, useState, useCallback, useMemo } from "react";
import gsap from "gsap";
import { motion } from "framer-motion";
import { useIsMobile } from "../hooks/use-mobile";
import { hexToRgb, hexToRgba, shiftHue, generateColorPalette } from "../lib/color-utils";

interface ParticleBackgroundProps {
  color?: string;
  density?: number;
  speed?: number;
  interactive?: boolean;
  minimalist?: boolean;
  mode?: "fluid" | "physics" | "neural" | "magnetic";
  primaryColor?: string;
  secondaryColor?: string;
  glowIntensity?: number;
}

// Sophisticated fluid dynamics constants
const FLUID_CONSTANTS = {
  VISCOSITY: 0.98,
  DENSITY: 0.6,
  PRESSURE: 0.1,
  ELASTICITY: 0.98,
  TURBULENCE: 0.05,
  COHESION: 0.2
};

// Neural networking simulation constants
const NEURAL_CONSTANTS = {
  ACTIVATION_THRESHOLD: 0.65,
  DECAY_RATE: 0.95,
  SIGNAL_STRENGTH: 0.8,
  MAX_CONNECTIONS: 5,
  CONNECTION_DISTANCE: 150
};

export default function ParticleBackground({
  color = "#6366F1",
  density = 50,
  speed = 0.5,
  interactive = true,
  minimalist = true,
  mode = "fluid",
  primaryColor = "#6366F1",
  secondaryColor = "#FF5A5F",
  glowIntensity = 0.3
}: ParticleBackgroundProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const overlayRef = useRef<HTMLDivElement>(null);
  const bufferCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 });
  const [isLoaded, setIsLoaded] = useState(false);
  const [isInteracting, setIsInteracting] = useState(false);
  const isMobile = useIsMobile();
  
  // Optimize performance based on device capability
  const actualDensity = useMemo(() => isMobile ? Math.floor(density * 0.4) : density, [density, isMobile]);
  const showGlow = useMemo(() => !isMobile && glowIntensity > 0, [isMobile, glowIntensity]);
  
  // Store animation frame for cleanup
  const animationRef = useRef<number>(0);
  
  // Store fluid dynamics grid
  const fluidGridRef = useRef<number[][][]>([]);
  
  // Compute colors with proper Apple-like gradient
  const gradient = useMemo(() => {
    return {
      primary: minimalist ? primaryColor : `rgba(${hexToRgb(primaryColor)}, 0.8)`,
      secondary: minimalist ? secondaryColor : `rgba(${hexToRgb(secondaryColor)}, 0.7)`,
      tertiary: `rgba(${hexToRgb(primaryColor)}, 0.4)`
    };
  }, [minimalist, primaryColor, secondaryColor]);
  
  // Compute glow properties for optimal performance
  const glowProps = useMemo(() => {
    return {
      radius: Math.min(10, Math.max(1, 6 * glowIntensity)), 
      alpha: Math.min(0.4, Math.max(0.1, glowIntensity * 0.4))
    };
  }, [glowIntensity]);
  
  useEffect(() => {
    if (!canvasRef.current) return;
    
    // Create off-screen buffer for better performance
    if (!bufferCanvasRef.current) {
      bufferCanvasRef.current = document.createElement('canvas');
    }
    
    const canvas = canvasRef.current;
    const buffer = bufferCanvasRef.current;
    const ctx = canvas.getContext("2d", { 
      alpha: true,
      desynchronized: true // Optimization for modern browsers
    })!;
    const bufferCtx = buffer.getContext("2d", { 
      alpha: true,
      desynchronized: true 
    })!;
    
    let width = window.innerWidth;
    let height = window.innerHeight;
    let particles: Particle[] = [];
    let mouseX = width / 2;
    let mouseY = height / 2;
    let isMouseMoving = false;
    let timeout: number | null = null;
    let frame: number;
    let hueRotation = 0;
    
    // Optimized rendering with double buffering
    const offscreenCanvas = document.createElement('canvas');
    const offscreenCtx = offscreenCanvas.getContext('2d', { alpha: true })!;
    offscreenCanvas.width = width;
    offscreenCanvas.height = height;

    // Different types of particles for visual variety
    class Particle {
      x: number;
      y: number;
      vx: number;
      vy: number;
      size: number;
      baseSize: number;
      color: string;
      colorSeed: number;
      alpha: number;
      maxSpeed: number;
      type: "circle" | "square" | "triangle" | "star";
      angle: number;
      angleSpeed: number;
      pulseSpeed: number;
      pulseMagnitude: number;
      pulseOffset: number;
      id: number;
      targetX: number | null;
      targetY: number | null;
      returning: boolean;
      originalX: number;
      originalY: number;
      damping: number;

      constructor(
        x: number,
        y: number,
        size: number,
        color: string,
        id: number
      ) {
        this.x = x;
        this.y = y;
        this.originalX = x;
        this.originalY = y;
        this.targetX = null;
        this.targetY = null;
        this.returning = false;
        this.vx = (Math.random() - 0.5) * speed;
        this.vy = (Math.random() - 0.5) * speed;
        this.maxSpeed = speed * (0.5 + Math.random() * 1.5);
        this.baseSize = size;
        this.size = size;
        this.color = color;
        this.colorSeed = Math.random();
        this.alpha = Math.random() * 0.6 + 0.2;
        this.type = this.getRandomType();
        this.angle = Math.random() * Math.PI * 2;
        this.angleSpeed = (Math.random() - 0.5) * 0.02;
        this.pulseSpeed = Math.random() * 0.1;
        this.pulseMagnitude = Math.random() * 0.5 + 0.5;
        this.pulseOffset = Math.random() * Math.PI * 2;
        this.id = id;
        this.damping = 0.92 + Math.random() * 0.05;
      }
      
      getRandomType(): "circle" | "square" | "triangle" | "star" {
        // Weight more towards circles for performance
        const rand = Math.random();
        if (rand < 0.75) return "circle";
        if (rand < 0.9) return "square";
        if (rand < 0.95) return "triangle";
        return "star";
      }

      draw(ctx: CanvasRenderingContext2D, time: number) {
        // Dynamic color cycling for special particles
        let particleColor = this.color;
        if (this.type !== "circle" && hueRotation > 0) {
          // Create a dynamic color based on the base color and time
          const r = parseInt(this.color.slice(1, 3), 16);
          const g = parseInt(this.color.slice(3, 5), 16);
          const b = parseInt(this.color.slice(5, 7), 16);
          
          // Shift hue slightly for non-circle particles
          const hueShift = (hueRotation + this.id * 10) % 360;
          const satShift = Math.sin(time * 0.001 + this.id) * 10;
          particleColor = `hsl(${hueShift}, ${100 + satShift}%, ${50 + satShift/3}%)`;
        }
        
        // Pulse size for added movement feeling
        this.size = this.baseSize * (1 + Math.sin(time * this.pulseSpeed + this.pulseOffset) * 0.2 * this.pulseMagnitude);
        
        ctx.save();
        ctx.globalAlpha = this.alpha;
        ctx.translate(this.x, this.y);
        ctx.rotate(this.angle);
        
        // Draw different shapes based on type
        switch (this.type) {
          case "circle":
            ctx.fillStyle = particleColor;
            ctx.beginPath();
            ctx.arc(0, 0, this.size, 0, Math.PI * 2);
            ctx.fill();
            break;
            
          case "square":
            ctx.fillStyle = particleColor;
            ctx.fillRect(-this.size, -this.size, this.size * 2, this.size * 2);
            break;
            
          case "triangle":
            ctx.fillStyle = particleColor;
            ctx.beginPath();
            ctx.moveTo(0, -this.size * 1.5);
            ctx.lineTo(-this.size, this.size);
            ctx.lineTo(this.size, this.size);
            ctx.closePath();
            ctx.fill();
            break;
            
          case "star":
            const spikes = 5;
            const outerRadius = this.size * 1.5;
            const innerRadius = this.size * 0.6;
            
            ctx.beginPath();
            ctx.fillStyle = particleColor;
            
            for (let i = 0; i < spikes * 2; i++) {
              const radius = i % 2 === 0 ? outerRadius : innerRadius;
              const angleStep = Math.PI / spikes;
              const x = Math.cos(i * angleStep) * radius;
              const y = Math.sin(i * angleStep) * radius;
              
              if (i === 0) {
                ctx.moveTo(x, y);
              } else {
                ctx.lineTo(x, y);
              }
            }
            
            ctx.closePath();
            ctx.fill();
            break;
        }
        
        ctx.restore();
      }

      update(time: number) {
        // Update angle for rotation
        this.angle += this.angleSpeed;
        
        // Handle seeking behavior or normal movement
        if (this.targetX !== null && this.targetY !== null) {
          // Seeking behavior - particle is being attracted
          const dx = this.targetX - this.x;
          const dy = this.targetY - this.y;
          const dist = Math.sqrt(dx * dx + dy * dy);
          
          if (dist < 1 || (this.returning && dist < 50)) {
            // If close enough to target or returning and close to original
            if (this.returning) {
              // Release particle back to normal behavior
              this.targetX = null;
              this.targetY = null;
              this.returning = false;
              this.vx = (Math.random() - 0.5) * this.maxSpeed;
              this.vy = (Math.random() - 0.5) * this.maxSpeed;
            } else {
              // Start returning to original position
              this.returning = true;
              this.targetX = this.originalX;
              this.targetY = this.originalY;
            }
          } else {
            // Continue moving toward target
            const speedFactor = this.returning ? 0.02 : 0.08;
            this.vx += dx * speedFactor;
            this.vy += dy * speedFactor;
          }
          
          // Apply damping for more natural movement
          this.vx *= this.damping;
          this.vy *= this.damping;
          
          // Apply velocity
          this.x += this.vx;
          this.y += this.vy;
          
        } else {
          // Normal particle movement
          // Move particles
          this.x += this.vx;
          this.y += this.vy;

          // Bounce off walls with some randomness
          if (this.x < 0 || this.x > width) {
            this.vx = -this.vx * (0.9 + Math.random() * 0.2);
            if (this.x < 0) this.x = 0;
            if (this.x > width) this.x = width;
          }
          
          if (this.y < 0 || this.y > height) {
            this.vy = -this.vy * (0.9 + Math.random() * 0.2);
            if (this.y < 0) this.y = 0;
            if (this.y > height) this.y = height;
          }

          // Random slight changes in direction for more organic movement
          if (Math.random() < 0.01) {
            this.vx += (Math.random() - 0.5) * 0.1;
            this.vy += (Math.random() - 0.5) * 0.1;
            
            // Enforce max speed
            const speed = Math.sqrt(this.vx * this.vx + this.vy * this.vy);
            if (speed > this.maxSpeed) {
              this.vx = (this.vx / speed) * this.maxSpeed;
              this.vy = (this.vy / speed) * this.maxSpeed;
            }
          }

          // If mouse is moving, particles will be influenced
          if (isMouseMoving && interactive) {
            const dx = this.x - mouseX;
            const dy = this.y - mouseY;
            const dist = Math.sqrt(dx * dx + dy * dy);
            const maxDist = 200;
            
            if (dist < maxDist) {
              const force = (maxDist - dist) / maxDist;
              this.vx += dx * force * 0.02;
              this.vy += dy * force * 0.02;
            }
          }
        }
      }
    }

    // Generate a smooth gradient for connections
    const generateGradient = () => {
      const gradient = ctx.createLinearGradient(0, 0, width, height);
      gradient.addColorStop(0, `${color}FF`);
      gradient.addColorStop(1, `${color}00`);
      return gradient;
    };

    const init = () => {
      canvas.width = width;
      canvas.height = height;
      offscreenCanvas.width = width;
      offscreenCanvas.height = height;
      
      // Create particles
      particles = [];
      const totalParticles = Math.floor((width * height) / 15000) * density;
      
      for (let i = 0; i < totalParticles; i++) {
        const size = Math.random() * 2.5 + 0.5; // More variety in sizes
        const x = Math.random() * width;
        const y = Math.random() * height;
        
        particles.push(new Particle(x, y, size, color, i));
      }
      
      setIsLoaded(true);
    };

    // More sophisticated connection drawing
    const connect = (time: number) => {
      // Create interesting connection patterns
      for (let i = 0; i < particles.length; i++) {
        let connections = 0;
        for (let j = i + 1; j < particles.length; j++) {
          // Limit connections per particle for performance
          if (connections > 3) break;
          
          const dx = particles[i].x - particles[j].x;
          const dy = particles[i].y - particles[j].y;
          const dist = Math.sqrt(dx * dx + dy * dy);
          
          // Dynamic connection distance based on particle types
          const connectionDist = 
            particles[i].type !== "circle" || particles[j].type !== "circle" 
              ? 180  // Special particles connect from further away
              : 120; // Regular particles have shorter connections
          
          if (dist < connectionDist) {
            connections++;
            const opacity = 1 - dist / connectionDist;
            offscreenCtx.globalAlpha = opacity * 0.2;
            
            // Use different line styles based on particle types
            if (particles[i].type !== "circle" && particles[j].type !== "circle") {
              // Special connection for special particles
              const gradient = offscreenCtx.createLinearGradient(
                particles[i].x, particles[i].y, 
                particles[j].x, particles[j].y
              );
              
              // Create a dynamic color based on the base color and time
              const hueShift = (hueRotation + i * 10) % 360;
              gradient.addColorStop(0, `hsla(${hueShift}, 100%, 50%, ${opacity * 0.5})`);
              gradient.addColorStop(1, `hsla(${(hueShift + 40) % 360}, 100%, 50%, ${opacity * 0.5})`);
              
              offscreenCtx.strokeStyle = gradient;
              offscreenCtx.lineWidth = 1;
              
              // Draw a wavy line
              offscreenCtx.beginPath();
              const steps = 5;
              const waveMagnitude = 3;
              
              for (let step = 0; step <= steps; step++) {
                const t = step / steps;
                const x = particles[i].x + (particles[j].x - particles[i].x) * t;
                const y = particles[i].y + (particles[j].y - particles[i].y) * t;
                
                // Add sine wave effect
                const waveOffset = Math.sin(t * Math.PI + time * 0.003) * waveMagnitude;
                const nx = x + waveOffset * (dy / dist);
                const ny = y - waveOffset * (dx / dist);
                
                if (step === 0) {
                  offscreenCtx.moveTo(nx, ny);
                } else {
                  offscreenCtx.lineTo(nx, ny);
                }
              }
              
              offscreenCtx.stroke();
            } else {
              // Standard connection
              offscreenCtx.strokeStyle = color;
              offscreenCtx.lineWidth = 0.5;
              offscreenCtx.beginPath();
              offscreenCtx.moveTo(particles[i].x, particles[i].y);
              offscreenCtx.lineTo(particles[j].x, particles[j].y);
              offscreenCtx.stroke();
            }
          }
        }
      }
    };

    const drawBackground = () => {
      // Subtle gradient background
      ctx.globalAlpha = 0.1;
      const bgGradient = ctx.createRadialGradient(
        width / 2, height / 2, 0,
        width / 2, height / 2, Math.max(width, height) / 1.5
      );
      
      bgGradient.addColorStop(0, color + '10');
      bgGradient.addColorStop(1, 'transparent');
      
      ctx.fillStyle = bgGradient;
      ctx.fillRect(0, 0, width, height);
      ctx.globalAlpha = 1;
    };

    // Create a special pattern when user clicks
    const createPattern = (x: number, y: number) => {
      // Determine how many particles to attract based on density
      const attractCount = Math.min(Math.floor(density * 0.5), 100);
      const attractRadius = 300;
      
      // Find nearest particles
      const candidates = particles
        .filter(p => {
          const dx = p.x - x;
          const dy = p.y - y;
          return Math.sqrt(dx * dx + dy * dy) < attractRadius;
        })
        .sort((a, b) => {
          const dxa = a.x - x;
          const dya = a.y - y;
          const dxb = b.x - x;
          const dyb = b.y - y;
          return Math.sqrt(dxa * dxa + dya * dya) - Math.sqrt(dxb * dxb + dyb * dyb);
        })
        .slice(0, attractCount);
      
      // Set targets for these particles
      const patterns = [
        createCirclePattern,
        createSpiralPattern,
        createGridPattern,
        createHeartPattern
      ];
      
      // Randomly select a pattern
      const patternFn = patterns[Math.floor(Math.random() * patterns.length)];
      patternFn(candidates, x, y);
    };
    
    // Pattern generators
    function createCirclePattern(particles: Particle[], centerX: number, centerY: number) {
      const radius = 80;
      particles.forEach((particle, i) => {
        const angle = (i / particles.length) * Math.PI * 2;
        particle.targetX = centerX + Math.cos(angle) * radius;
        particle.targetY = centerY + Math.sin(angle) * radius;
      });
    }
    
    function createSpiralPattern(particles: Particle[], centerX: number, centerY: number) {
      particles.forEach((particle, i) => {
        const angle = (i / particles.length) * Math.PI * 8;
        const radius = 10 + (i / particles.length) * 80;
        particle.targetX = centerX + Math.cos(angle) * radius;
        particle.targetY = centerY + Math.sin(angle) * radius;
      });
    }
    
    function createGridPattern(particles: Particle[], centerX: number, centerY: number) {
      const gridSize = Math.ceil(Math.sqrt(particles.length));
      const cellSize = 20;
      const totalWidth = gridSize * cellSize;
      const startX = centerX - totalWidth / 2;
      const startY = centerY - totalWidth / 2;
      
      particles.forEach((particle, i) => {
        const row = Math.floor(i / gridSize);
        const col = i % gridSize;
        particle.targetX = startX + col * cellSize;
        particle.targetY = startY + row * cellSize;
      });
    }
    
    function createHeartPattern(particles: Particle[], centerX: number, centerY: number) {
      particles.forEach((particle, i) => {
        const t = (i / particles.length) * Math.PI * 2;
        // Heart curve formula
        const x = 16 * Math.pow(Math.sin(t), 3);
        const y = 13 * Math.cos(t) - 5 * Math.cos(2*t) - 2 * Math.cos(3*t) - Math.cos(4*t);
        particle.targetX = centerX + x * 4;
        particle.targetY = centerY - y * 4;
      });
    }

    const animate = (time: number) => {
      // Clear offscreen canvas
      offscreenCtx.clearRect(0, 0, width, height);
      
      // Update and draw particles
      for (const particle of particles) {
        particle.update(time);
        particle.draw(offscreenCtx, time);
      }
      
      // Connect particles with lines
      connect(time);
      
      // Copy offscreen canvas to visible canvas
      ctx.clearRect(0, 0, width, height);
      
      // Draw subtle background gradient first
      drawBackground();
      
      // Draw particle system from offscreen buffer
      ctx.drawImage(offscreenCanvas, 0, 0);
      
      // Slowly cycle hue for special particles
      hueRotation = (hueRotation + 0.1) % 360;
      
      // Continue animation
      frame = requestAnimationFrame(animate);
    };

    const handleMouseMove = (e: MouseEvent) => {
      mouseX = e.clientX;
      mouseY = e.clientY;
      
      // Update mouse position for react state
      setMousePosition({ x: e.clientX, y: e.clientY });
      
      isMouseMoving = true;
      
      if (timeout) {
        clearTimeout(timeout);
      }
      
      timeout = window.setTimeout(() => {
        isMouseMoving = false;
      }, 500) as unknown as number;
    };
    
    const handleClick = (e: MouseEvent) => {
      if (interactive) {
        createPattern(e.clientX, e.clientY);
      }
    };

    const handleResize = () => {
      width = window.innerWidth;
      height = window.innerHeight;
      init();
    };

    // Initialize and start animation
    init();
    frame = requestAnimationFrame(animate);
    
    // Add event listeners
    window.addEventListener("mousemove", handleMouseMove);
    window.addEventListener("click", handleClick);
    window.addEventListener("resize", handleResize);
    
    return () => {
      window.removeEventListener("mousemove", handleMouseMove);
      window.removeEventListener("click", handleClick);
      window.removeEventListener("resize", handleResize);
      if (timeout) clearTimeout(timeout);
      cancelAnimationFrame(frame);
    };
  }, [color, density, speed, interactive]);

  // Create dynamic spotlight effect that follows mouse
  const spotlightSize = Math.max(300, density * 3);

  return (
    <>
      <canvas
        ref={canvasRef}
        className="fixed top-0 left-0 w-full h-full -z-10 opacity-80"
      />
      
      {/* Mouse spotlight effect */}
      {isLoaded && (
        <motion.div 
          ref={overlayRef}
          className="fixed top-0 left-0 w-full h-full pointer-events-none z-0"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 1 }}
        >
          <motion.div
            className="absolute rounded-full"
            style={{
              background: `radial-gradient(circle, ${color}10 0%, transparent 70%)`,
              width: spotlightSize,
              height: spotlightSize,
              top: mousePosition.y - spotlightSize / 2,
              left: mousePosition.x - spotlightSize / 2,
              mixBlendMode: 'screen',
              filter: 'blur(30px)'
            }}
            animate={{
              top: mousePosition.y - spotlightSize / 2,
              left: mousePosition.x - spotlightSize / 2,
              opacity: [0.7, 0.9, 0.7],
              scale: [1, 1.1, 1],
            }}
            transition={{
              type: "spring",
              stiffness: 100,
              damping: 30,
              mass: 1,
              opacity: {
                duration: 3,
                repeat: Infinity,
                repeatType: "reverse",
              },
              scale: {
                duration: 4, 
                repeat: Infinity,
                repeatType: "reverse"
              }
            }}
          />
        </motion.div>
      )}
    </>
  );
}