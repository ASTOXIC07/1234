import { useEffect, useRef } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { GradientText } from '@/components/ui/gradient-text';

// Register ScrollTrigger plugin
gsap.registerPlugin(ScrollTrigger);

// Showcase items data
const showcaseItems = [
  {
    image: "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=600&h=400&q=80",
    title: "Digital Experience",
    description: "Interactive website with scroll animations"
  },
  {
    image: "https://images.unsplash.com/photo-1550745165-9bc0b252726f?w=600&h=400&q=80",
    title: "3D Animations",
    description: "Dynamic product showcase with 3D elements"
  },
  {
    image: "https://images.unsplash.com/photo-1563089145-599997674d42?w=600&h=400&q=80",
    title: "Mobile Interactions",
    description: "Smooth touch-based animations for mobile apps"
  },
  {
    image: "https://images.unsplash.com/photo-1558655146-9f40138edfeb?w=600&h=400&q=80",
    title: "Data Visualization",
    description: "Animated charts and interactive graphs"
  },
  {
    image: "https://images.unsplash.com/photo-1620641788421-7a1c342ea42e?w=600&h=400&q=80",
    title: "Creative Layouts",
    description: "Unique page transitions and layout animations"
  },
  {
    image: "https://images.unsplash.com/photo-1633356122102-3fe601e05bd2?w=600&h=400&q=80",
    title: "Interactive Elements",
    description: "Engaging UI components with fluid animations"
  }
];

export default function ShowcaseSection() {
  const sectionRef = useRef<HTMLElement>(null);
  const itemsRef = useRef<Array<HTMLDivElement | null>>([]);

  useEffect(() => {
    if (!sectionRef.current) return;

    // Set initial state for showcase items
    gsap.set(itemsRef.current, { 
      opacity: 0, 
      y: 50 
    });

    // Create staggered animation for items entering viewport
    itemsRef.current.forEach((item, index) => {
      if (!item) return;
      
      ScrollTrigger.create({
        trigger: item,
        start: "top 85%",
        onEnter: () => {
          gsap.to(item, {
            opacity: 1,
            y: 0,
            duration: 0.6,
            delay: index * 0.1,
            ease: "power2.out"
          });
        },
        once: true
      });
    });

    return () => {
      ScrollTrigger.getAll().forEach(trigger => trigger.kill());
    };
  }, []);

  return (
    <section 
      id="showcase" 
      ref={sectionRef}
      className="py-20 md:py-32 px-6"
    >
      <div className="container mx-auto">
        <h2 className="text-3xl md:text-4xl font-bold text-center mb-16">
          Our <GradientText>Showcase</GradientText>
        </h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {showcaseItems.map((item, index) => (
            <div 
              key={index}
              ref={el => itemsRef.current[index] = el}
              className="opacity-0"
            >
              <div className="overflow-hidden rounded-xl shadow-lg">
                <img 
                  src={item.image} 
                  alt={item.title} 
                  className="w-full h-64 object-cover transition-transform duration-300 hover:scale-105"
                />
              </div>
              <h3 className="text-lg font-semibold mt-4 mb-2">{item.title}</h3>
              <p className="text-slate-300 text-sm">{item.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
