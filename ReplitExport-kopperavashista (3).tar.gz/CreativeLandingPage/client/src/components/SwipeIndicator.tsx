import { useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";

export default function SwipeIndicator() {
  const [isVisible, setIsVisible] = useState(true);
  
  // Hide the indicator after 6 seconds
  useEffect(() => {
    const timer = setTimeout(() => {
      setIsVisible(false);
    }, 6000);
    
    return () => clearTimeout(timer);
  }, []);
  
  return (
    <AnimatePresence>
      {isVisible && (
        <motion.div
          className="fixed bottom-10 left-1/2 transform -translate-x-1/2 z-40 pointer-events-none"
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: 10 }}
          transition={{ 
            delay: 3, 
            duration: 0.8, 
            ease: [0.16, 1, 0.3, 1] 
          }}
        >
          <div className="px-4 py-2 bg-black/20 backdrop-blur-md rounded-full flex items-center gap-3 shadow-lg border border-white/10">
            <motion.div
              animate={{ x: [0, 8, 0] }}
              transition={{ 
                repeat: Infinity, 
                duration: 2,
                ease: "easeInOut" 
              }}
            >
              <svg 
                xmlns="http://www.w3.org/2000/svg" 
                className="h-4 w-4 text-white/70" 
                viewBox="0 0 24 24" 
                fill="none" 
                stroke="currentColor" 
                strokeWidth="1.5" 
                strokeLinecap="round" 
                strokeLinejoin="round"
              >
                <path d="M5 12h14m-7-7 7 7-7 7" />
              </svg>
            </motion.div>
            <span className="text-xs text-white/70 font-light tracking-wide">Swipe to navigate</span>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}