import { useEffect, useRef, useState, useCallback, useMemo } from "react";
import gsap from "gsap";
import { motion } from "framer-motion";
import { useIsMobile } from "../hooks/use-mobile";
import { hexToRgb, hexToRgba, shiftHue, generateColorPalette, adjustBrightness } from "../lib/color-utils";

interface EnhancedParticleBackgroundProps {
  primaryColor?: string;
  secondaryColor?: string;
  density?: number;
  speed?: number;
  interactive?: boolean;
  glowIntensity?: number;
  mode?: "fluid" | "neural" | "magnetic" | "cosmos" | "quantum";
  turbulence?: number;
  reactivity?: number;
  particleSize?: number;
  depth?: number;
  complexity?: "simple" | "advanced" | "premium";
}

// Advanced physics simulation constants - Apple-level premium
const PHYSICS_CONSTANTS = {
  VISCOSITY: 0.983,
  DENSITY: 0.65,
  PRESSURE: 0.12,
  ELASTICITY: 0.97,
  TURBULENCE: 0.08,
  COHESION: 0.25,
  MAGNETIC_FORCE: 0.18,
  GRAVITATIONAL_PULL: 0.004,
  QUANTUM_FLUCTUATION: 0.12,
  RELATIVITY_FACTOR: 0.002
};

// Neural network simulation - advanced AI aesthetics
const NEURAL_CONSTANTS = {
  ACTIVATION_THRESHOLD: 0.55,
  DECAY_RATE: 0.92,
  SIGNAL_STRENGTH: 0.85,
  MAX_CONNECTIONS: 8,
  CONNECTION_DISTANCE: 180,
  LEARNING_RATE: 0.02,
  SIGNAL_PROPAGATION: 0.075
};

// Cosmos simulation - spacetime fabric effect
const COSMOS_CONSTANTS = {
  STAR_DENSITY: 0.6,
  NEBULA_INTENSITY: 0.35,
  GRAVITY_WELLS: 2,
  PARALLAX_DEPTH: 3,
  COSMIC_EXPANSION: 0.03,
  STELLAR_LUMINOSITY: 0.7
};

// Quantum simulation - subatomic particle behavior
const QUANTUM_CONSTANTS = {
  UNCERTAINTY: 0.4,
  ENTANGLEMENT_PROBABILITY: 0.15,
  WAVE_FUNCTION_COLLAPSE: 0.25,
  QUANTUM_TUNNELING: 0.1,
  PROBABILITY_DENSITY: 0.65,
  SUPERPOSITION: 0.35
};

export default function EnhancedParticleBackground({
  primaryColor = "#6366F1",
  secondaryColor = "#FF5A5F",
  density = 70,
  speed = 0.6,
  interactive = true,
  glowIntensity = 0.6,
  mode = "neural",
  turbulence = 0.15,
  reactivity = 0.8,
  particleSize = 1.5,
  depth = 3,
  complexity = "premium"
}: EnhancedParticleBackgroundProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const bufferCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const particlesRef = useRef<any[]>([]);
  const connectionsRef = useRef<any[]>([]);
  const [dimensions, setDimensions] = useState({ width: 0, height: 0 });
  const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 });
  const [isLoaded, setIsLoaded] = useState(false);
  const [isHovering, setIsHovering] = useState(false);
  const [isPulsing, setIsPulsing] = useState(false);
  const isMobile = useIsMobile();
  const animationRef = useRef<number>(0);
  const timeRef = useRef<number>(0);
  
  // Optimize performance based on device capabilities
  const actualDensity = useMemo(() => {
    return isMobile ? Math.floor(density * 0.3) : density;
  }, [density, isMobile]);
  
  const actualParticleSize = useMemo(() => {
    return isMobile ? particleSize * 0.8 : particleSize;
  }, [particleSize, isMobile]);
  
  const actualDepth = useMemo(() => {
    return isMobile ? Math.min(2, depth) : depth;
  }, [depth, isMobile]);
  
  // Determine if we should show glow effects based on device capabilities
  const showGlow = useMemo(() => !isMobile && glowIntensity > 0, [isMobile, glowIntensity]);
  
  // Compute premium color palette
  const colorPalette = useMemo(() => {
    // Get base palette
    const basePalette = generateColorPalette(primaryColor);
    
    // Secondary palette for accents
    const accentPalette = generateColorPalette(secondaryColor);
    
    // Create a rich, Apple-inspired color system
    return {
      primary: hexToRgba(primaryColor, 0.85),
      secondary: hexToRgba(secondaryColor, 0.8),
      tertiary: hexToRgba(shiftHue(primaryColor, 60), 0.75),
      accent: hexToRgba(shiftHue(secondaryColor, -30), 0.9),
      glow: hexToRgba(adjustBrightness(primaryColor, 20), glowIntensity * 0.8),
      highlight: hexToRgba(adjustBrightness(secondaryColor, 30), glowIntensity * 0.9),
      subtle: hexToRgba(shiftHue(primaryColor, 180), 0.4),
      dark: hexToRgba(adjustBrightness(primaryColor, -40), 0.7),
      light: hexToRgba(adjustBrightness(primaryColor, 50), 0.5),
      gradient: [
        hexToRgba(primaryColor, 0.8),
        hexToRgba(shiftHue(primaryColor, 30), 0.7),
        hexToRgba(secondaryColor, 0.75)
      ]
    };
  }, [primaryColor, secondaryColor, glowIntensity]);
  
  // Calculate spotlight glow sizes
  const spotlightSizes = useMemo(() => {
    return {
      primary: Math.max(300, density * 4),
      secondary: Math.max(200, density * 2.5),
      accent: Math.max(150, density * 1.5),
      pulse: Math.max(400, density * 5)
    };
  }, [density]);
  
  // Initialize the canvas and particles
  useEffect(() => {
    if (!canvasRef.current) return;
    
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d', { alpha: true, desynchronized: true });
    if (!ctx) return;
    
    // Create a high-performance buffer canvas for advanced effects
    const bufferCanvas = document.createElement('canvas');
    bufferCanvasRef.current = bufferCanvas;
    const bufferCtx = bufferCanvas.getContext('2d', { alpha: true });
    if (!bufferCtx) return;
    
    // Set dimensions with high DPI support for retina displays
    const updateDimensions = () => {
      if (!canvas || !bufferCanvas) return;
      
      const container = containerRef.current || document.body;
      const rect = container.getBoundingClientRect();
      const { width, height } = rect;
      
      // Calculate device pixel ratio for super sharp rendering
      const dpr = window.devicePixelRatio || 1;
      
      // Set physical canvas size to match CSS size * DPI
      canvas.width = width * dpr;
      canvas.height = height * dpr;
      bufferCanvas.width = width * dpr;
      bufferCanvas.height = height * dpr;
      
      // Scale the context to ensure correct drawing operations
      ctx.scale(dpr, dpr);
      bufferCtx.scale(dpr, dpr);
      
      // Store dimensions for calculations
      setDimensions({ width, height });
      
      // Initialize particle positions when dimensions change
      initializeParticles();
    };
    
    // Create our premium particle system
    const initializeParticles = () => {
      if (!canvas) return;
      
      const particles = [];
      const count = Math.floor(actualDensity * (dimensions.width / 1000));
      
      // Use different particle distributions based on mode
      for (let i = 0; i < count; i++) {
        // Create particles with z-depth for 3D effect
        const particle = {
          x: Math.random() * dimensions.width,
          y: Math.random() * dimensions.height,
          z: Math.random() * actualDepth,
          size: ((Math.random() * 0.5) + 0.5) * actualParticleSize * (1 + Math.random() * 0.4),
          vx: (Math.random() - 0.5) * speed * 0.8,
          vy: (Math.random() - 0.5) * speed * 0.8,
          vz: (Math.random() - 0.5) * speed * 0.3,
          color: Math.random() > 0.5 ? colorPalette.primary : colorPalette.secondary,
          alpha: 0.1 + Math.random() * 0.9,
          // Unique properties for different simulation modes
          ...(mode === 'neural' && {
            connections: [],
            signalStrength: Math.random() * NEURAL_CONSTANTS.SIGNAL_STRENGTH,
            active: Math.random() > 0.7
          }),
          ...(mode === 'quantum' && {
            uncertainty: Math.random() * QUANTUM_CONSTANTS.UNCERTAINTY,
            waveFunction: Math.random(),
            entangled: null,
            superposition: Math.random() > 0.7,
            originalX: 0,
            originalY: 0
          }),
          ...(mode === 'cosmos' && {
            luminosity: Math.random() * COSMOS_CONSTANTS.STELLAR_LUMINOSITY,
            parallaxFactor: 0.3 + Math.random() * 0.7,
            isStar: Math.random() > 0.8
          }),
          lastUpdate: 0,
          pulseOffset: Math.random() * Math.PI * 2,
          pulseSpeed: 0.5 + Math.random() * 1.5,
          angularVelocity: (Math.random() - 0.5) * 0.02,
          angle: Math.random() * Math.PI * 2
        };
        
        if (mode === 'quantum') {
          particle.originalX = particle.x;
          particle.originalY = particle.y;
        }
        
        particles.push(particle);
      }
      
      particlesRef.current = particles;
      
      // For neural mode, establish connections
      if (mode === 'neural') {
        // Create neural network connections
        particlesRef.current.forEach((particle, i) => {
          const connections = [];
          
          // Find nearest neighbors
          for (let j = 0; j < particlesRef.current.length; j++) {
            if (i === j) continue;
            
            const other = particlesRef.current[j];
            const dx = particle.x - other.x;
            const dy = particle.y - other.y;
            const distance = Math.sqrt(dx * dx + dy * dy);
            
            if (distance < NEURAL_CONSTANTS.CONNECTION_DISTANCE && connections.length < NEURAL_CONSTANTS.MAX_CONNECTIONS) {
              connections.push({
                index: j,
                distance,
                strength: 1 - (distance / NEURAL_CONSTANTS.CONNECTION_DISTANCE),
                signalPosition: 0,
                signalDirection: 1,
                active: false,
                lastSignalTime: 0
              });
            }
          }
          
          particle.connections = connections;
        });
      }
      
      // Quantum entanglement for quantum mode
      if (mode === 'quantum') {
        // Create quantum entanglements
        for (let i = 0; i < particlesRef.current.length; i += 2) {
          if (i + 1 < particlesRef.current.length && Math.random() < QUANTUM_CONSTANTS.ENTANGLEMENT_PROBABILITY) {
            particlesRef.current[i].entangled = i + 1;
            particlesRef.current[i + 1].entangled = i;
          }
        }
      }
      
      setIsLoaded(true);
    };
    
    // Update and draw animation frame
    const draw = (timestamp: number) => {
      if (!ctx || !bufferCtx || !particlesRef.current) return;
      
      // Clear canvas with slight fade for trailing effect
      ctx.clearRect(0, 0, dimensions.width, dimensions.height);
      bufferCtx.clearRect(0, 0, dimensions.width, dimensions.height);
      
      const deltaTime = timestamp - (timeRef.current || timestamp);
      timeRef.current = timestamp;
      
      // Draw glow effects in buffer canvas
      if (showGlow) {
        bufferCtx.save();
        // Apply different effects based on mode
        if (mode === 'neural') {
          drawNeuralGlow(bufferCtx, deltaTime);
        } else if (mode === 'cosmos') {
          drawCosmosGlow(bufferCtx, deltaTime);
        } else if (mode === 'quantum') {
          drawQuantumGlow(bufferCtx, deltaTime);
        } else {
          drawStandardGlow(bufferCtx, deltaTime);
        }
        bufferCtx.restore();
      }
      
      // Update and draw each particle
      for (let i = 0; i < particlesRef.current.length; i++) {
        const particle = particlesRef.current[i];
        
        // Update particle position and state based on simulation mode
        if (mode === 'neural') {
          updateNeuralParticle(particle, deltaTime, i);
        } else if (mode === 'cosmos') {
          updateCosmosParticle(particle, deltaTime, i);
        } else if (mode === 'quantum') {
          updateQuantumParticle(particle, deltaTime, i);
        } else if (mode === 'magnetic') {
          updateMagneticParticle(particle, deltaTime, i);
        } else {
          updateFluidParticle(particle, deltaTime, i);
        }
        
        // Draw the particle - with depth effect
        const depth = 1 + (particle.z / actualDepth) * 2;
        const size = particle.size * depth;
        const alpha = particle.alpha * (particle.z + 1) / (actualDepth + 1);
        
        ctx.save();
        
        // Apply advanced rendering effects by mode
        if (mode === 'neural') {
          renderNeuralParticle(ctx, particle, size, alpha);
        } else if (mode === 'cosmos') {
          renderCosmosParticle(ctx, particle, size, alpha);
        } else if (mode === 'quantum') {
          renderQuantumParticle(ctx, particle, size, alpha);
        } else {
          renderStandardParticle(ctx, particle, size, alpha);
        }
        
        ctx.restore();
      }
      
      // Composite the buffer canvas onto the main canvas for glow effects
      if (showGlow && bufferCanvasRef.current) {
        ctx.save();
        ctx.globalCompositeOperation = 'lighter';
        ctx.drawImage(bufferCanvasRef.current, 0, 0, dimensions.width, dimensions.height);
        ctx.restore();
      }
      
      // Continue animation loop
      animationRef.current = requestAnimationFrame(draw);
    };
    
    // Different update functions for different modes
    const updateNeuralParticle = (particle: any, deltaTime: number, index: number) => {
      // Basic movement
      particle.x += particle.vx * deltaTime * 0.05;
      particle.y += particle.vy * deltaTime * 0.05;
      particle.z += particle.vz * deltaTime * 0.01;
      
      // Mouse interactivity
      if (interactive && isHovering) {
        const dx = mousePosition.x - particle.x;
        const dy = mousePosition.y - particle.y;
        const distance = Math.sqrt(dx * dx + dy * dy);
        const maxDistance = 150;
        
        if (distance < maxDistance) {
          const force = (1 - distance / maxDistance) * reactivity * 0.2;
          particle.vx += (dx / distance) * force;
          particle.vy += (dy / distance) * force;
        }
      }
      
      // Neural network behavior
      if (Math.random() < 0.001) {
        particle.active = true;
      }
      
      // Update connections
      for (let i = 0; i < particle.connections.length; i++) {
        const connection = particle.connections[i];
        const otherParticle = particlesRef.current[connection.index];
        
        // Update connection distance (may have changed with movement)
        const dx = particle.x - otherParticle.x;
        const dy = particle.y - otherParticle.y;
        connection.distance = Math.sqrt(dx * dx + dy * dy);
        
        // Signal propagation along connections
        if (particle.active && !connection.active && Math.random() < NEURAL_CONSTANTS.SIGNAL_PROPAGATION) {
          connection.active = true;
          connection.signalPosition = 0;
          connection.lastSignalTime = timeRef.current;
        }
        
        // Update signal position
        if (connection.active) {
          connection.signalPosition += connection.signalDirection * deltaTime * 0.0015;
          
          // When signal reaches end
          if (connection.signalPosition >= 1) {
            connection.signalPosition = 1;
            connection.signalDirection = -1;
            
            // Activate receiving particle
            otherParticle.active = true;
          } else if (connection.signalPosition <= 0) {
            // Reset signal
            connection.active = false;
            connection.signalDirection = 1;
          }
        }
      }
      
      // Neural activation decay
      if (particle.active) {
        if (Math.random() < 0.03) {
          particle.active = false;
        }
      }
      
      // Boundary conditions
      boundaryCheck(particle);
    };
    
    const updateQuantumParticle = (particle: any, deltaTime: number, index: number) => {
      // Quantum particles exhibit uncertainty in their movement
      const uncertainty = Math.random() * particle.uncertainty * turbulence;
      
      particle.x += particle.vx * deltaTime * 0.05 + uncertainty - uncertainty / 2;
      particle.y += particle.vy * deltaTime * 0.05 + uncertainty - uncertainty / 2;
      particle.z += particle.vz * deltaTime * 0.01;
      
      // Quantum tunneling - occasional teleportation
      if (Math.random() < QUANTUM_CONSTANTS.QUANTUM_TUNNELING * 0.01) {
        particle.x = Math.random() * dimensions.width;
        particle.y = Math.random() * dimensions.height;
      }
      
      // Wave function collapse - particles tend to return to original position
      if (Math.random() < QUANTUM_CONSTANTS.WAVE_FUNCTION_COLLAPSE * 0.01) {
        particle.vx = (particle.originalX - particle.x) * 0.001;
        particle.vy = (particle.originalY - particle.y) * 0.001;
      }
      
      // Quantum entanglement - entangled particles mirror each other
      if (particle.entangled !== null) {
        const entangledParticle = particlesRef.current[particle.entangled];
        if (Math.random() < 0.05 && entangledParticle) {
          entangledParticle.vx = -particle.vx;
          entangledParticle.vy = -particle.vy;
          entangledParticle.superposition = particle.superposition;
        }
      }
      
      // Superposition state changes
      if (Math.random() < 0.01) {
        particle.superposition = !particle.superposition;
      }
      
      // Mouse interaction creates quantum disturbance
      if (interactive && isHovering) {
        const dx = mousePosition.x - particle.x;
        const dy = mousePosition.y - particle.y;
        const distance = Math.sqrt(dx * dx + dy * dy);
        const maxDistance = 180;
        
        if (distance < maxDistance) {
          // Collapse superposition near mouse
          if (distance < maxDistance * 0.5 && particle.superposition) {
            particle.superposition = false;
          }
          
          const force = (1 - distance / maxDistance) * reactivity * 0.15;
          particle.vx -= (dx / distance) * force;
          particle.vy -= (dy / distance) * force;
        }
      }
      
      // Boundary conditions with quantum behavior
      boundaryCheck(particle);
    };
    
    const updateCosmosParticle = (particle: any, deltaTime: number, index: number) => {
      // Parallax effect - different depths move at different speeds
      const parallaxFactor = particle.parallaxFactor || 1;
      
      // Base movement with parallax
      particle.x += particle.vx * deltaTime * 0.03 * parallaxFactor;
      particle.y += particle.vy * deltaTime * 0.03 * parallaxFactor;
      particle.z += particle.vz * deltaTime * 0.01;
      
      // Cosmic expansion - gradual outward movement
      const centerX = dimensions.width / 2;
      const centerY = dimensions.height / 2;
      const dx = particle.x - centerX;
      const dy = particle.y - centerY;
      const distFromCenter = Math.sqrt(dx * dx + dy * dy);
      
      if (distFromCenter > 0) {
        particle.vx += (dx / distFromCenter) * COSMOS_CONSTANTS.COSMIC_EXPANSION * 0.01;
        particle.vy += (dy / distFromCenter) * COSMOS_CONSTANTS.COSMIC_EXPANSION * 0.01;
      }
      
      // Gravity wells - simulate black holes or massive stars
      for (let i = 0; i < COSMOS_CONSTANTS.GRAVITY_WELLS; i++) {
        const wellX = dimensions.width * (0.3 + 0.4 * Math.sin(timeRef.current * 0.0001 + i));
        const wellY = dimensions.height * (0.3 + 0.4 * Math.cos(timeRef.current * 0.0001 + i + Math.PI/2));
        
        const wellDx = particle.x - wellX;
        const wellDy = particle.y - wellY;
        const wellDist = Math.sqrt(wellDx * wellDx + wellDy * wellDy);
        
        if (wellDist > 0 && wellDist < 300) {
          const force = -0.05 / (wellDist * wellDist + 1);
          particle.vx += (wellDx / wellDist) * force * deltaTime * 0.1;
          particle.vy += (wellDy / wellDist) * force * deltaTime * 0.1;
        }
      }
      
      // Stars twinkle
      if (particle.isStar) {
        particle.alpha = 0.5 + 0.5 * Math.sin(timeRef.current * 0.001 + particle.pulseOffset);
        particle.luminosity = 0.5 + 0.5 * Math.sin(timeRef.current * 0.0005 + particle.pulseOffset + Math.PI/4);
      }
      
      // Mouse interaction creates gravitational disruption
      if (interactive && isHovering) {
        const dx = mousePosition.x - particle.x;
        const dy = mousePosition.y - particle.y;
        const distance = Math.sqrt(dx * dx + dy * dy);
        const maxDistance = 200;
        
        if (distance < maxDistance && distance > 0) {
          const force = (1 - distance / maxDistance) * reactivity * 0.25;
          // Repulsive for stars, attractive for dust
          const multiplier = particle.isStar ? -1 : 1;
          particle.vx += (dx / distance) * force * multiplier;
          particle.vy += (dy / distance) * force * multiplier;
        }
      }
      
      // Apply velocity dampening - space resistance
      particle.vx *= 0.99;
      particle.vy *= 0.99;
      
      // Wrap around universe edges
      wrapAroundBoundary(particle);
    };
    
    const updateMagneticParticle = (particle: any, deltaTime: number, index: number) => {
      // Base movement
      particle.x += particle.vx * deltaTime * 0.05;
      particle.y += particle.vy * deltaTime * 0.05;
      particle.z += particle.vz * deltaTime * 0.01;
      
      // Magnetic field alignment
      const fieldAngle = Math.atan2(
        Math.sin(particle.y * 0.01 + timeRef.current * 0.0001),
        Math.cos(particle.x * 0.01 + timeRef.current * 0.0001)
      );
      
      // Gradually align particles with the field
      const targetVx = Math.cos(fieldAngle) * speed * 0.5;
      const targetVy = Math.sin(fieldAngle) * speed * 0.5;
      
      particle.vx += (targetVx - particle.vx) * PHYSICS_CONSTANTS.MAGNETIC_FORCE * 0.1;
      particle.vy += (targetVy - particle.vy) * PHYSICS_CONSTANTS.MAGNETIC_FORCE * 0.1;
      
      // Mouse creates magnetic disturbance
      if (interactive && isHovering) {
        const dx = mousePosition.x - particle.x;
        const dy = mousePosition.y - particle.y;
        const distance = Math.sqrt(dx * dx + dy * dy);
        const maxDistance = 180;
        
        if (distance < maxDistance && distance > 0) {
          // Create circular motion around cursor
          const perpX = -dy / distance;
          const perpY = dx / distance;
          
          const force = (1 - distance / maxDistance) * reactivity * 0.3;
          particle.vx += perpX * force;
          particle.vy += perpY * force;
        }
      }
      
      // Apply velocity dampening
      particle.vx *= 0.98;
      particle.vy *= 0.98;
      
      // Boundary conditions
      boundaryCheck(particle);
    };
    
    const updateFluidParticle = (particle: any, deltaTime: number, index: number) => {
      // Base fluid movement
      particle.x += particle.vx * deltaTime * 0.05;
      particle.y += particle.vy * deltaTime * 0.05;
      particle.z += particle.vz * deltaTime * 0.01;
      
      // Apply fluid dynamics forces
      const noiseX = noise(particle.x * 0.005, particle.y * 0.005, timeRef.current * 0.0005);
      const noiseY = noise(particle.x * 0.005 + 100, particle.y * 0.005 + 100, timeRef.current * 0.0005);
      
      particle.vx += (noiseX - 0.5) * turbulence * 0.1;
      particle.vy += (noiseY - 0.5) * turbulence * 0.1;
      
      // Apply fluid viscosity
      particle.vx *= PHYSICS_CONSTANTS.VISCOSITY;
      particle.vy *= PHYSICS_CONSTANTS.VISCOSITY;
      
      // Apply fluid density separation
      for (let i = 0; i < particlesRef.current.length; i += 5) {
        if (i !== index) {
          const other = particlesRef.current[i];
          const dx = particle.x - other.x;
          const dy = particle.y - other.y;
          const distance = Math.sqrt(dx * dx + dy * dy);
          
          if (distance > 0 && distance < 50) {
            const force = 0.5 / (distance + 1) * PHYSICS_CONSTANTS.DENSITY;
            particle.vx += (dx / distance) * force;
            particle.vy += (dy / distance) * force;
          }
        }
      }
      
      // Simulate turbulence with fluid swirls
      particle.angle += particle.angularVelocity * deltaTime * 0.05;
      
      // Mouse interaction creates fluid disturbance
      if (interactive && isHovering) {
        const dx = mousePosition.x - particle.x;
        const dy = mousePosition.y - particle.y;
        const distance = Math.sqrt(dx * dx + dy * dy);
        const maxDistance = 150;
        
        if (distance < maxDistance && distance > 0) {
          const force = (1 - distance / maxDistance) * reactivity * 0.2;
          particle.vx += (dx / distance) * force;
          particle.vy += (dy / distance) * force;
        }
      }
      
      // Boundary conditions
      boundaryCheck(particle);
    };
    
    // Different rendering methods for different particle types
    const renderNeuralParticle = (ctx: CanvasRenderingContext2D, particle: any, size: number, alpha: number) => {
      // First draw connections
      for (let i = 0; i < particle.connections.length; i++) {
        const connection = particle.connections[i];
        const otherParticle = particlesRef.current[connection.index];
        
        if (!otherParticle) continue;
        
        // Calculate connection line alpha
        let connectionAlpha = connection.strength * 0.3;
        
        // Highlight active connections
        if (connection.active) {
          connectionAlpha = 0.8;
          
          // Draw signal pulse animation
          const signalX = particle.x + (otherParticle.x - particle.x) * connection.signalPosition;
          const signalY = particle.y + (otherParticle.y - particle.y) * connection.signalPosition;
          
          // Signal glow
          ctx.beginPath();
          ctx.arc(signalX, signalY, size * 1.5, 0, Math.PI * 2);
          ctx.fillStyle = colorPalette.highlight;
          ctx.globalAlpha = connection.signalDirection > 0 ? 
                           1 - connection.signalPosition : connection.signalPosition;
          ctx.fill();
        }
        
        // Draw connection line
        ctx.beginPath();
        ctx.moveTo(particle.x, particle.y);
        ctx.lineTo(otherParticle.x, otherParticle.y);
        ctx.strokeStyle = particle.active && otherParticle.active ? 
                         colorPalette.accent : colorPalette.subtle;
        ctx.globalAlpha = connectionAlpha;
        ctx.lineWidth = size * 0.3;
        ctx.stroke();
      }
      
      // Then draw neuron
      ctx.beginPath();
      ctx.arc(particle.x, particle.y, size, 0, Math.PI * 2);
      
      // Active neurons glow
      if (particle.active) {
        ctx.fillStyle = colorPalette.accent;
        ctx.globalAlpha = alpha * 1.2;
      } else {
        ctx.fillStyle = particle.color;
        ctx.globalAlpha = alpha * 0.7;
      }
      
      ctx.fill();
      
      // Add outer glow to active neurons
      if (particle.active) {
        ctx.beginPath();
        ctx.arc(particle.x, particle.y, size * 2, 0, Math.PI * 2);
        const glowGradient = ctx.createRadialGradient(
          particle.x, particle.y, size * 0.5,
          particle.x, particle.y, size * 2
        );
        glowGradient.addColorStop(0, colorPalette.highlight);
        glowGradient.addColorStop(1, 'rgba(0,0,0,0)');
        ctx.fillStyle = glowGradient;
        ctx.globalAlpha = alpha * 0.6;
        ctx.fill();
      }
    };
    
    const renderQuantumParticle = (ctx: CanvasRenderingContext2D, particle: any, size: number, alpha: number) => {
      // Quantum particles are rendered differently based on observation state
      if (particle.superposition) {
        // In superposition, particles appear as wave patterns
        const waveSize = size * 3;
        const waveCount = 3;
        
        for (let i = 0; i < waveCount; i++) {
          const waveRadius = waveSize * (i + 1) / waveCount;
          const waveAlpha = alpha * (1 - i / waveCount) * 0.4;
          
          ctx.beginPath();
          ctx.arc(particle.x, particle.y, waveRadius, 0, Math.PI * 2);
          ctx.strokeStyle = particle.entangled !== null ? colorPalette.tertiary : colorPalette.secondary;
          ctx.globalAlpha = waveAlpha;
          ctx.lineWidth = size * 0.15;
          ctx.stroke();
        }
        
        // Central probability cloud
        ctx.beginPath();
        ctx.arc(particle.x, particle.y, size * 0.8, 0, Math.PI * 2);
        ctx.fillStyle = particle.entangled !== null ? colorPalette.tertiary : colorPalette.primary;
        ctx.globalAlpha = alpha * 0.7;
        ctx.fill();
      } else {
        // Collapsed state, particles appear as points
        ctx.beginPath();
        ctx.arc(particle.x, particle.y, size * 1.2, 0, Math.PI * 2);
        ctx.fillStyle = particle.entangled !== null ? colorPalette.accent : colorPalette.primary;
        ctx.globalAlpha = alpha;
        ctx.fill();
      }
      
      // Entanglement visualization
      if (particle.entangled !== null && particlesRef.current[particle.entangled]) {
        const entangledParticle = particlesRef.current[particle.entangled];
        
        // Draw faint entanglement line
        ctx.beginPath();
        ctx.moveTo(particle.x, particle.y);
        ctx.lineTo(entangledParticle.x, entangledParticle.y);
        ctx.strokeStyle = colorPalette.tertiary;
        ctx.globalAlpha = 0.1;
        ctx.lineWidth = size * 0.2;
        ctx.stroke();
        
        // Pulsing entanglement effect
        const pulseTime = timeRef.current * 0.001;
        const pulsePosition = (Math.sin(pulseTime + particle.pulseOffset) + 1) / 2;
        const midX = particle.x + (entangledParticle.x - particle.x) * pulsePosition;
        const midY = particle.y + (entangledParticle.y - particle.y) * pulsePosition;
        
        ctx.beginPath();
        ctx.arc(midX, midY, size * 0.8, 0, Math.PI * 2);
        ctx.fillStyle = colorPalette.highlight;
        ctx.globalAlpha = 0.3;
        ctx.fill();
      }
    };
    
    const renderCosmosParticle = (ctx: CanvasRenderingContext2D, particle: any, size: number, alpha: number) => {
      // Stars and cosmic dust are rendered differently
      if (particle.isStar) {
        // Stars have glows and twinkle
        const starSize = size * (1.2 + 0.8 * particle.luminosity);
        
        // Star glow
        ctx.beginPath();
        const glowSize = starSize * 3;
        const glowGradient = ctx.createRadialGradient(
          particle.x, particle.y, starSize * 0.5,
          particle.x, particle.y, glowSize
        );
        glowGradient.addColorStop(0, particle.color);
        glowGradient.addColorStop(1, 'rgba(0,0,0,0)');
        ctx.fillStyle = glowGradient;
        ctx.globalAlpha = alpha * 0.4 * particle.luminosity;
        ctx.fillRect(
          particle.x - glowSize, 
          particle.y - glowSize, 
          glowSize * 2, 
          glowSize * 2
        );
        
        // Star core
        ctx.beginPath();
        ctx.arc(particle.x, particle.y, starSize, 0, Math.PI * 2);
        ctx.fillStyle = colorPalette.light;
        ctx.globalAlpha = alpha * particle.luminosity;
        ctx.fill();
        
        // Lens flare effect
        if (particle.luminosity > 0.8) {
          ctx.beginPath();
          const flareSize = starSize * 0.5;
          ctx.moveTo(particle.x - flareSize * 2, particle.y);
          ctx.lineTo(particle.x + flareSize * 2, particle.y);
          ctx.moveTo(particle.x, particle.y - flareSize * 2);
          ctx.lineTo(particle.x, particle.y + flareSize * 2);
          ctx.strokeStyle = colorPalette.light;
          ctx.globalAlpha = alpha * 0.4 * particle.luminosity;
          ctx.lineWidth = flareSize * 0.2;
          ctx.stroke();
        }
      } else {
        // Cosmic dust and nebula particles
        ctx.beginPath();
        ctx.arc(particle.x, particle.y, size * 0.8, 0, Math.PI * 2);
        
        const dustColor = particle.z > actualDepth / 2 ? 
                         colorPalette.secondary : colorPalette.primary;
        
        ctx.fillStyle = dustColor;
        ctx.globalAlpha = alpha * 0.5;
        ctx.fill();
      }
    };
    
    const renderStandardParticle = (ctx: CanvasRenderingContext2D, particle: any, size: number, alpha: number) => {
      // Standard fluid/magnetic particles
      ctx.beginPath();
      ctx.arc(particle.x, particle.y, size, 0, Math.PI * 2);
      ctx.fillStyle = particle.color;
      ctx.globalAlpha = alpha * 0.8;
      ctx.fill();
      
      // Add subtle glow
      if (showGlow) {
        ctx.beginPath();
        const glowSize = size * 2;
        const glowGradient = ctx.createRadialGradient(
          particle.x, particle.y, size * 0.5,
          particle.x, particle.y, glowSize
        );
        glowGradient.addColorStop(0, particle.color);
        glowGradient.addColorStop(1, 'rgba(0,0,0,0)');
        ctx.fillStyle = glowGradient;
        ctx.globalAlpha = alpha * 0.2;
        ctx.fillRect(
          particle.x - glowSize, 
          particle.y - glowSize, 
          glowSize * 2, 
          glowSize * 2
        );
      }
    };
    
    // Draw different glow effects in buffer canvas
    const drawNeuralGlow = (ctx: CanvasRenderingContext2D, deltaTime: number) => {
      // Add ambient neural network glow
      if (isPulsing) {
        const pulseIntensity = (Math.sin(timeRef.current * 0.001) + 1) / 2;
        
        // Neural pulse waves
        ctx.beginPath();
        const gradient = ctx.createRadialGradient(
          dimensions.width / 2, dimensions.height / 2, 0,
          dimensions.width / 2, dimensions.height / 2, dimensions.width * 0.6
        );
        gradient.addColorStop(0, hexToRgba(colorPalette.accent, 0.02 + 0.03 * pulseIntensity));
        gradient.addColorStop(1, 'rgba(0,0,0,0)');
        ctx.fillStyle = gradient;
        ctx.fillRect(0, 0, dimensions.width, dimensions.height);
      }
      
      // Draw neural connection pathway glows
      const activeNeurons = particlesRef.current.filter(p => p.active);
      
      // Connect active neurons with light beams
      if (activeNeurons.length > 1) {
        for (let i = 0; i < activeNeurons.length; i++) {
          const neuron = activeNeurons[i];
          
          // Connect to a random subset of other active neurons
          const connectionCount = Math.min(3, activeNeurons.length - 1);
          
          for (let j = 0; j < connectionCount; j++) {
            const targetIndex = (i + j + 1) % activeNeurons.length;
            const target = activeNeurons[targetIndex];
            
            if (target === neuron) continue;
            
            // Draw neural beam
            const gradient = ctx.createLinearGradient(
              neuron.x, neuron.y, target.x, target.y
            );
            gradient.addColorStop(0, hexToRgba(colorPalette.accent, 0.1));
            gradient.addColorStop(0.5, hexToRgba(colorPalette.highlight, 0.15));
            gradient.addColorStop(1, hexToRgba(colorPalette.accent, 0.1));
            
            ctx.beginPath();
            ctx.moveTo(neuron.x, neuron.y);
            ctx.lineTo(target.x, target.y);
            ctx.strokeStyle = gradient;
            ctx.lineWidth = 2 + Math.random() * 3;
            ctx.globalAlpha = 0.15;
            ctx.stroke();
          }
        }
      }
    };
    
    const drawCosmosGlow = (ctx: CanvasRenderingContext2D, deltaTime: number) => {
      // Cosmic background glow
      const gradient = ctx.createRadialGradient(
        dimensions.width / 2, dimensions.height / 2, 0,
        dimensions.width / 2, dimensions.height / 2, dimensions.width * 0.8
      );
      gradient.addColorStop(0, hexToRgba(colorPalette.dark, 0.05));
      gradient.addColorStop(1, 'rgba(0,0,0,0)');
      ctx.fillStyle = gradient;
      ctx.fillRect(0, 0, dimensions.width, dimensions.height);
      
      // Nebula clouds
      const nebulaCount = Math.floor(3 * COSMOS_CONSTANTS.NEBULA_INTENSITY);
      
      for (let i = 0; i < nebulaCount; i++) {
        const time = timeRef.current * 0.0001;
        const x = dimensions.width * (0.3 + 0.4 * Math.sin(time + i * Math.PI/3));
        const y = dimensions.height * (0.3 + 0.4 * Math.cos(time + i * Math.PI/3 + Math.PI/6));
        const size = dimensions.width * (0.2 + 0.1 * COSMOS_CONSTANTS.NEBULA_INTENSITY);
        
        const nebulaGradient = ctx.createRadialGradient(
          x, y, 0, x, y, size
        );
        
        const color1 = i % 3 === 0 ? colorPalette.primary : 
                      i % 3 === 1 ? colorPalette.secondary : colorPalette.tertiary;
        
        nebulaGradient.addColorStop(0, hexToRgba(color1, 0.05 + 0.05 * COSMOS_CONSTANTS.NEBULA_INTENSITY));
        nebulaGradient.addColorStop(1, 'rgba(0,0,0,0)');
        
        ctx.fillStyle = nebulaGradient;
        ctx.globalAlpha = 0.3;
        ctx.beginPath();
        ctx.arc(x, y, size, 0, Math.PI * 2);
        ctx.fill();
      }
    };
    
    const drawQuantumGlow = (ctx: CanvasRenderingContext2D, deltaTime: number) => {
      // Quantum field visualization
      const fieldIntensity = 0.02 + 0.02 * Math.sin(timeRef.current * 0.0005);
      
      // Quantum flux waves
      const waveCount = 3;
      for (let i = 0; i < waveCount; i++) {
        const time = timeRef.current * 0.0003;
        const phase = i * Math.PI * 2 / waveCount + time;
        
        // Wave center
        const centerX = dimensions.width * (0.5 + 0.2 * Math.sin(phase));
        const centerY = dimensions.height * (0.5 + 0.2 * Math.cos(phase + Math.PI/4));
        
        // Quantum probability field
        const fieldGradient = ctx.createRadialGradient(
          centerX, centerY, 0,
          centerX, centerY, dimensions.width * 0.4
        );
        
        fieldGradient.addColorStop(0, hexToRgba(colorPalette.tertiary, fieldIntensity));
        fieldGradient.addColorStop(1, 'rgba(0,0,0,0)');
        
        ctx.fillStyle = fieldGradient;
        ctx.globalAlpha = 0.3;
        ctx.beginPath();
        ctx.ellipse(
          centerX, centerY,
          dimensions.width * 0.4, dimensions.height * 0.4,
          time % (Math.PI * 2),
          0, Math.PI * 2
        );
        ctx.fill();
      }
      
      // Quantum entanglement visualization
      const entangledParticles = particlesRef.current.filter(p => p.entangled !== null);
      
      if (entangledParticles.length > 0) {
        for (let i = 0; i < entangledParticles.length; i += 2) {
          const particle = entangledParticles[i];
          
          if (!particlesRef.current[particle.entangled]) continue;
          
          const entangledParticle = particlesRef.current[particle.entangled];
          
          // Probability field between entangled particles
          const midX = (particle.x + entangledParticle.x) / 2;
          const midY = (particle.y + entangledParticle.y) / 2;
          const distance = Math.sqrt(
            Math.pow(particle.x - entangledParticle.x, 2) +
            Math.pow(particle.y - entangledParticle.y, 2)
          );
          
          if (distance > dimensions.width / 2) continue; // Skip if too far apart
          
          const fieldGradient = ctx.createRadialGradient(
            midX, midY, 0,
            midX, midY, distance * 0.6
          );
          
          const intensity = 0.03 + 0.02 * Math.sin(timeRef.current * 0.001 + i);
          
          fieldGradient.addColorStop(0, hexToRgba(colorPalette.tertiary, intensity));
          fieldGradient.addColorStop(1, 'rgba(0,0,0,0)');
          
          ctx.fillStyle = fieldGradient;
          ctx.globalAlpha = 0.15;
          ctx.beginPath();
          ctx.ellipse(
            midX, midY,
            distance * 0.6, distance * 0.3,
            Math.atan2(entangledParticle.y - particle.y, entangledParticle.x - particle.x),
            0, Math.PI * 2
          );
          ctx.fill();
        }
      }
    };
    
    const drawStandardGlow = (ctx: CanvasRenderingContext2D, deltaTime: number) => {
      // Standard ambient glow
      const gradient = ctx.createRadialGradient(
        dimensions.width / 2, dimensions.height / 2, 0,
        dimensions.width / 2, dimensions.height / 2, dimensions.width * 0.7
      );
      gradient.addColorStop(0, hexToRgba(colorPalette.primary, 0.02));
      gradient.addColorStop(1, 'rgba(0,0,0,0)');
      ctx.fillStyle = gradient;
      ctx.fillRect(0, 0, dimensions.width, dimensions.height);
    };
    
    // Keep particles within bounds or wrap around
    const boundaryCheck = (particle: any) => {
      const buffer = particle.size * 2;
      
      // Bounce off edges with damping
      if (particle.x < -buffer) {
        particle.x = -buffer;
        particle.vx = Math.abs(particle.vx) * PHYSICS_CONSTANTS.ELASTICITY;
      } else if (particle.x > dimensions.width + buffer) {
        particle.x = dimensions.width + buffer;
        particle.vx = -Math.abs(particle.vx) * PHYSICS_CONSTANTS.ELASTICITY;
      }
      
      if (particle.y < -buffer) {
        particle.y = -buffer;
        particle.vy = Math.abs(particle.vy) * PHYSICS_CONSTANTS.ELASTICITY;
      } else if (particle.y > dimensions.height + buffer) {
        particle.y = dimensions.height + buffer;
        particle.vy = -Math.abs(particle.vy) * PHYSICS_CONSTANTS.ELASTICITY;
      }
      
      // Z-depth bounds
      if (particle.z < 0) {
        particle.z = 0;
        particle.vz = Math.abs(particle.vz) * PHYSICS_CONSTANTS.ELASTICITY;
      } else if (particle.z > actualDepth) {
        particle.z = actualDepth;
        particle.vz = -Math.abs(particle.vz) * PHYSICS_CONSTANTS.ELASTICITY;
      }
    };
    
    // Wrap around edges (for cosmic mode)
    const wrapAroundBoundary = (particle: any) => {
      const buffer = particle.size * 2;
      
      if (particle.x < -buffer) {
        particle.x = dimensions.width + buffer;
      } else if (particle.x > dimensions.width + buffer) {
        particle.x = -buffer;
      }
      
      if (particle.y < -buffer) {
        particle.y = dimensions.height + buffer;
      } else if (particle.y > dimensions.height + buffer) {
        particle.y = -buffer;
      }
      
      // Z-depth bounds
      if (particle.z < 0) {
        particle.z = 0;
        particle.vz = Math.abs(particle.vz) * PHYSICS_CONSTANTS.ELASTICITY;
      } else if (particle.z > actualDepth) {
        particle.z = actualDepth;
        particle.vz = -Math.abs(particle.vz) * PHYSICS_CONSTANTS.ELASTICITY;
      }
    };
    
    // Mouse event handlers
    const handleMouseMove = (e: MouseEvent) => {
      if (!containerRef.current) return;
      
      const rect = containerRef.current.getBoundingClientRect();
      setMousePosition({
        x: e.clientX - rect.left,
        y: e.clientY - rect.top
      });
      
      // Set hover state for effects
      setIsHovering(true);
    };
    
    const handleMouseLeave = () => {
      setIsHovering(false);
    };
    
    const handleClick = (e: MouseEvent) => {
      if (!containerRef.current) return;
      
      const rect = containerRef.current.getBoundingClientRect();
      const clickX = e.clientX - rect.left;
      const clickY = e.clientY - rect.top;
      
      // Different click effects based on mode
      if (mode === 'neural') {
        // Neural pulse wave
        setIsPulsing(true);
        setTimeout(() => setIsPulsing(false), 2000);
        
        // Activate neurons near click
        particlesRef.current.forEach(particle => {
          const dx = clickX - particle.x;
          const dy = clickY - particle.y;
          const distance = Math.sqrt(dx * dx + dy * dy);
          
          if (distance < 100) {
            particle.active = true;
          }
        });
      } else if (mode === 'quantum') {
        // Quantum wave function collapse
        particlesRef.current.forEach(particle => {
          const dx = clickX - particle.x;
          const dy = clickY - particle.y;
          const distance = Math.sqrt(dx * dx + dy * dy);
          
          if (distance < 120) {
            // Collapse wave function
            particle.superposition = false;
            
            // Add velocity away from click
            const force = 5 / (distance + 1);
            particle.vx += (dx / distance) * force;
            particle.vy += (dy / distance) * force;
          }
        });
      } else if (mode === 'cosmos') {
        // Create a temporary gravity well
        const tempGravityWell = {
          x: clickX,
          y: clickY,
          strength: 5,
          radius: 200,
          decay: 0.95
        };
        
        // Apply initial force
        particlesRef.current.forEach(particle => {
          const dx = clickX - particle.x;
          const dy = clickY - particle.y;
          const distance = Math.sqrt(dx * dx + dy * dy);
          
          if (distance > 0 && distance < tempGravityWell.radius) {
            const force = tempGravityWell.strength / (distance + 1);
            particle.vx -= (dx / distance) * force;
            particle.vy -= (dy / distance) * force;
          }
        });
      } else {
        // Fluid/magnetic explosion effect
        particlesRef.current.forEach(particle => {
          const dx = clickX - particle.x;
          const dy = clickY - particle.y;
          const distance = Math.sqrt(dx * dx + dy * dy);
          
          if (distance > 0 && distance < 150) {
            const force = 3 / (distance + 1);
            particle.vx += (dx / distance) * force;
            particle.vy += (dy / distance) * force;
          }
        });
      }
    };
    
    // Window resize handler
    const handleResize = () => {
      updateDimensions();
    };
    
    // Simplex noise implementation for fluid dynamics
    function noise(x: number, y: number, z: number): number {
      // Simple implementation of Perlin-like noise
      const X = Math.floor(x) & 255;
      const Y = Math.floor(y) & 255;
      const Z = Math.floor(z) & 255;
      
      x -= Math.floor(x);
      y -= Math.floor(y);
      z -= Math.floor(z);
      
      const u = fade(x);
      const v = fade(y);
      const w = fade(z);
      
      // Simple hash function
      const A = (X + Y + Z) % 255;
      const B = (X + Y + Z + 1) % 255;
      
      // Gradient values
      const g1 = Math.sin(A * 0.1) * 0.5 + 0.5;
      const g2 = Math.sin(B * 0.1) * 0.5 + 0.5;
      
      return lerp(v, 
        lerp(u, g1, g2),
        lerp(u, g1, g2)
      );
    }
    
    function fade(t: number): number {
      return t * t * t * (t * (t * 6 - 15) + 10);
    }
    
    function lerp(t: number, a: number, b: number): number {
      return a + t * (b - a);
    }
    
    // Initial setup
    updateDimensions();
    
    // Start animation loop
    animationRef.current = requestAnimationFrame(draw);
    
    // Event listeners
    window.addEventListener('resize', handleResize);
    window.addEventListener('mousemove', handleMouseMove);
    window.addEventListener('mouseleave', handleMouseLeave);
    window.addEventListener('click', handleClick);
    
    // Cleanup on unmount
    return () => {
      window.removeEventListener('resize', handleResize);
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('mouseleave', handleMouseLeave);
      window.removeEventListener('click', handleClick);
      cancelAnimationFrame(animationRef.current);
    };
  }, [
    primaryColor, 
    secondaryColor,
    actualDensity,
    speed,
    interactive,
    glowIntensity,
    mode,
    turbulence,
    reactivity,
    actualParticleSize,
    actualDepth,
    dimensions.width,
    dimensions.height,
    colorPalette,
    showGlow,
    isHovering,
    isPulsing,
    mousePosition
  ]);
  
  // Triple-layer mouse spotlight effect
  return (
    <div 
      ref={containerRef} 
      className="relative w-full h-full overflow-hidden"
      style={{ 
        willChange: 'transform', 
        perspective: '1000px',
        transformStyle: 'preserve-3d'
      }}
    >
      <canvas
        ref={canvasRef}
        className="absolute top-0 left-0 w-full h-full"
        style={{ mixBlendMode: 'screen' }}
      />
      
      {/* Enhanced multi-layered spotlight effects */}
      {isLoaded && isHovering && interactive && (
        <div className="absolute top-0 left-0 w-full h-full pointer-events-none">
          {/* Primary spotlight */}
          <motion.div 
            className="absolute top-0 left-0 w-full h-full"
            animate={{
              background: `radial-gradient(circle ${spotlightSizes.primary}px at ${mousePosition.x}px ${mousePosition.y}px, ${colorPalette.glow}, rgba(0,0,0,0))`
            }}
            transition={{ duration: 0.2, ease: "linear" }}
            style={{ mixBlendMode: 'lighten' }}
          />
          
          {/* Secondary spotlight with faster response */}
          <motion.div 
            className="absolute top-0 left-0 w-full h-full"
            animate={{
              background: `radial-gradient(circle ${spotlightSizes.secondary}px at ${mousePosition.x}px ${mousePosition.y}px, ${colorPalette.highlight}, rgba(0,0,0,0))`
            }}
            transition={{ duration: 0.1, ease: "linear" }}
            style={{ mixBlendMode: 'screen' }}
          />
          
          {/* Accent spotlight with slight offset */}
          <motion.div 
            className="absolute top-0 left-0 w-full h-full"
            animate={{
              background: `radial-gradient(circle ${spotlightSizes.accent}px at ${mousePosition.x - 20}px ${mousePosition.y + 20}px, ${colorPalette.accent}, rgba(0,0,0,0))`
            }}
            transition={{ duration: 0.3, ease: "linear" }}
            style={{ mixBlendMode: 'color-dodge', opacity: 0.5 }}
          />
        </div>
      )}
      
      {/* Pulsing effect when interaction occurs */}
      {isPulsing && (
        <motion.div
          className="absolute top-0 left-0 w-full h-full pointer-events-none"
          initial={{ opacity: 0.7 }}
          animate={{ opacity: 0 }}
          transition={{ duration: 2, ease: [0.19, 1, 0.22, 1] }}
          style={{
            background: `radial-gradient(circle ${spotlightSizes.pulse}px at ${mousePosition.x}px ${mousePosition.y}px, ${colorPalette.highlight}, rgba(0,0,0,0))`,
            mixBlendMode: 'screen'
          }}
        />
      )}
    </div>
  );
}