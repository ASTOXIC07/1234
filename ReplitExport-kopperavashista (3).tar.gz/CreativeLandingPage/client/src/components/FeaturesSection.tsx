import { useEffect, useRef } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { GradientText } from '@/components/ui/gradient-text';

// Register GSAP plugins
gsap.registerPlugin(ScrollTrigger);

// Feature data
const features = [
  {
    icon: (
      <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-[#F8FAFC]" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
      </svg>
    ),
    title: "Lightning Fast Animations",
    description: "Create smooth, high-performance animations that captivate your audience without sacrificing speed."
  },
  {
    icon: (
      <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-[#F8FAFC]" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9.75 17L9 20l-1 1h8l-1-1-.75-3M3 13h18M5 17h14a2 2 0 002-2V5a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
      </svg>
    ),
    title: "Responsive Design",
    description: "Ensure your animations look perfect on any device, from mobile phones to large desktop displays."
  },
  {
    icon: (
      <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-[#F8FAFC]" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6V4m0 2a2 2 0 100 4m0-4a2 2 0 110 4m-6 8a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4m6 6v10m6-2a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4" />
      </svg>
    ),
    title: "Easy Customization",
    description: "Tailor every animation to your brand with our intuitive controls and flexible parameters."
  }
];

export default function FeaturesSection() {
  const sectionRef = useRef<HTMLElement>(null);
  const cardsRef = useRef<Array<HTMLDivElement | null>>([]);

  useEffect(() => {
    if (!sectionRef.current) return;

    // Set initial state for cards
    gsap.set(cardsRef.current, { 
      opacity: 0, 
      y: 50 
    });

    // Create ScrollTrigger for each card with staggered animation
    cardsRef.current.forEach((card, index) => {
      if (!card) return;
      
      ScrollTrigger.create({
        trigger: card,
        start: "top 85%",
        onEnter: () => {
          gsap.to(card, {
            opacity: 1,
            y: 0,
            duration: 0.8,
            delay: index * 0.15,
            ease: "power2.out"
          });
        },
        once: true
      });
    });

    return () => {
      ScrollTrigger.getAll().forEach(trigger => trigger.kill());
    };
  }, []);

  return (
    <section 
      id="features" 
      ref={sectionRef}
      className="py-20 md:py-32 px-6 bg-slate-800/50"
    >
      <div className="container mx-auto">
        <h2 className="text-3xl md:text-4xl font-bold text-center mb-16">
          Powerful <GradientText>Features</GradientText>
        </h2>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-10">
          {features.map((feature, index) => (
            <div 
              key={index}
              ref={el => cardsRef.current[index] = el}
              className="bg-[#0F172A]/80 p-8 rounded-xl shadow-lg"
            >
              <div className="w-16 h-16 rounded-lg bg-gradient-to-r from-[#6366F1] to-[#EC4899] flex items-center justify-center mb-6 mx-auto md:mx-0">
                {feature.icon}
              </div>
              <h3 className="text-xl font-semibold mb-3 text-center md:text-left">{feature.title}</h3>
              <p className="text-slate-300 text-center md:text-left">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
