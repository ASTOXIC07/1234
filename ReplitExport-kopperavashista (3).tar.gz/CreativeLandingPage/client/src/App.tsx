import React, { useEffect, useState, useRef, useCallback } from "react";
import { QueryClientProvider } from "@tanstack/react-query";
import { queryClient } from "./lib/queryClient";
import { Toaster } from "./components/ui/toaster";
import { useLocation } from "wouter";
import { AnimatePresence, motion } from "framer-motion";
import { useSwipeable } from "react-swipeable";

// Import components
import FullscreenNavigation from "./components/FullscreenNavigation";
import PageIndicator from "./components/PageIndicator";
import SwipeIndicator from "./components/SwipeIndicator";

// Import pages
import HomePage from "./pages/HomePage";
import FeaturePage from "./pages/FeaturePage";
import ShowcasePage from "./pages/ShowcasePage";
import ContactPage from "./pages/ContactPage";
import NotFound from "./pages/not-found";

// Define pages for horizontal swiping
const pages = [
  { id: "home", path: "/", component: HomePage, title: "Home" },
  { id: "features", path: "/features", component: FeaturePage, title: "Features" },
  { id: "showcase", path: "/showcase", component: ShowcasePage, title: "Showcase" },
  { id: "contact", path: "/contact", component: ContactPage, title: "Contact" }
];

function App() {
  // Apply dark theme background
  useEffect(() => {
    document.body.className = "bg-[#030014] text-[#F8FAFC] overflow-hidden";
  }, []);

  const [location, setLocation] = useLocation();
  const [currentPageIndex, setCurrentPageIndex] = useState(0);
  const [isTransitioning, setIsTransitioning] = useState(false);
  const [isNavigationOpen, setIsNavigationOpen] = useState(false);
  const [swipeDirection, setSwipeDirection] = useState(0);
  const touchStartX = useRef(0);
  
  // Find the current page index based on location and prevent 404
  useEffect(() => {
    const index = pages.findIndex(page => page.path === location);
    
    if (index !== -1) {
      // Valid page found
      setCurrentPageIndex(index);
    } else if (location !== '/' && location !== '') {
      // Intercept 404s by immediately redirecting to home
      console.log(`Invalid path: ${location}, redirecting to home`);
      setLocation('/');
    }
  }, [location, setLocation]);
  
  // Handle page navigation
  const navigateTo = useCallback((index: number) => {
    if (index < 0 || index >= pages.length || isTransitioning) return;
    
    setIsTransitioning(true);
    setSwipeDirection(index > currentPageIndex ? 1 : -1);
    setLocation(pages[index].path);
    
    setTimeout(() => {
      setIsTransitioning(false);
    }, 1000);
  }, [currentPageIndex, isTransitioning, pages.length, setLocation]);
  
  // Navigate to next/previous page
  const goToNextPage = useCallback(() => {
    if (currentPageIndex < pages.length - 1) {
      navigateTo(currentPageIndex + 1);
    }
  }, [currentPageIndex, pages.length, navigateTo]);
  
  const goToPrevPage = useCallback(() => {
    if (currentPageIndex > 0) {
      navigateTo(currentPageIndex - 1);
    }
  }, [currentPageIndex, navigateTo]);
  
  // Set up swipe handlers
  const swipeHandlers = useSwipeable({
    onSwipedLeft: () => {
      if (!isTransitioning) goToNextPage();
    },
    onSwipedRight: () => {
      if (!isTransitioning) goToPrevPage();
    },
    trackMouse: true,
    preventScrollOnSwipe: true,
    delta: 10, // Minimum swipe distance
    swipeDuration: 500, // Maximum time in ms for a swipe
  });
  
  // Handle keyboard navigation
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (isTransitioning) return; // Prevent navigation during transitions
      
      if (e.key === "ArrowRight" || e.key === "ArrowDown") {
        goToNextPage();
      } else if (e.key === "ArrowLeft" || e.key === "ArrowUp") {
        goToPrevPage();
      }
    };
    
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [currentPageIndex, isTransitioning, goToNextPage, goToPrevPage]);
  
  // We won't use wouter's 404 handling, we'll handle it ourselves
  
  // Check if user prefers reduced motion
  const [prefersReducedMotion, setPrefersReducedMotion] = useState(false);
  const [focusVisible, setFocusVisible] = useState(false);
  
  useEffect(() => {
    // Check if user prefers reduced motion
    const mediaQuery = window.matchMedia('(prefers-reduced-motion: reduce)');
    setPrefersReducedMotion(mediaQuery.matches);
    
    // Listen for changes to motion preference
    const handleMediaChange = (e: MediaQueryListEvent) => {
      setPrefersReducedMotion(e.matches);
    };
    
    mediaQuery.addEventListener('change', handleMediaChange);
    return () => mediaQuery.removeEventListener('change', handleMediaChange);
  }, []);
  
  // Handle keyboard focus state
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // If tab is pressed, show focus indicators
      if (e.key === 'Tab') {
        setFocusVisible(true);
      }
    };
    
    // If mouse is clicked, hide focus indicators
    const handleMouseDown = () => {
      setFocusVisible(false);
    };
    
    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('mousedown', handleMouseDown);
    
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('mousedown', handleMouseDown);
    };
  }, []);
  
  return (
    <QueryClientProvider client={queryClient}>
      {/* Skip to main content link for keyboard users */}
      <a 
        href="#main-content" 
        className={`sr-only focus:not-sr-only focus:absolute focus:top-4 focus:left-4 focus:z-50 focus:p-4 focus:bg-black focus:text-white focus:outline-none ${focusVisible ? 'focus:ring-2 focus:ring-white' : ''}`}
      >
        Skip to main content
      </a>
      <div 
        className="fixed inset-0 flex flex-col"
        {...swipeHandlers}
      >
        {/* Fixed elements that appear on all pages */}
        <motion.header
          className="fixed top-6 left-6 z-50"
          initial={{ opacity: 0, y: prefersReducedMotion ? 0 : -10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5, duration: prefersReducedMotion ? 0.3 : 0.5, ease: "easeOut" }}
        >
          <motion.a
            className={`text-2xl cursor-pointer flex items-center group ${focusVisible ? 'focus:outline-none focus:ring-2 focus:ring-white/50 focus:rounded' : ''}`}
            onClick={() => navigateTo(0)}
            whileHover={prefersReducedMotion ? {} : { scale: 1.05 }}
            whileTap={prefersReducedMotion ? {} : { scale: 0.98 }}
            href="/"
            aria-label="NeuraFlow Home"
            tabIndex={0}
            onKeyDown={(e) => {
              if (e.key === 'Enter' || e.key === ' ') {
                e.preventDefault();
                navigateTo(0);
              }
            }}
          >
            <span className="font-medium text-white">Neura</span>
            <span className="font-light text-white/90">Flow</span>
          </motion.a>
        </motion.header>
        
        {/* Menu toggle button - Apple-style minimal */}
        <motion.div 
          className="fixed top-6 right-6 z-50"
          initial={{ opacity: 0, y: prefersReducedMotion ? 0 : -10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5, duration: prefersReducedMotion ? 0.3 : 0.5, ease: "easeOut" }}
        >
          <motion.button 
            className={`w-10 h-10 rounded-full bg-black/30 backdrop-blur-xl flex items-center justify-center text-white/90 hover:bg-black/40 transition-all shadow-lg ${focusVisible ? 'focus:outline-none focus:ring-2 focus:ring-white/70' : ''}`}
            onClick={() => setIsNavigationOpen(true)}
            whileHover={prefersReducedMotion ? {} : { scale: 1.05 }}
            whileTap={prefersReducedMotion ? {} : { scale: 0.95 }}
            aria-label="Open menu"
            aria-expanded={isNavigationOpen}
            aria-controls="main-navigation"
          >
            <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true" focusable="false">
              <line x1="4" y1="12" x2="20" y2="12"></line>
              <line x1="4" y1="6" x2="20" y2="6"></line>
              <line x1="4" y1="18" x2="20" y2="18"></line>
            </svg>
          </motion.button>
        </motion.div>
        
        {/* Page indicator for horizontal navigation */}
        <PageIndicator 
          pages={pages} 
          currentPageIndex={currentPageIndex} 
          navigateTo={navigateTo} 
        />
        
        {/* Swipe indicator for new users */}
        <SwipeIndicator />
        
        {/* Fullscreen navigation overlay */}
        <FullscreenNavigation 
          isOpen={isNavigationOpen} 
          onClose={() => setIsNavigationOpen(false)} 
          pages={pages}
          currentPageIndex={currentPageIndex}
          navigateTo={(index: number) => {
            setIsNavigationOpen(false);
            setTimeout(() => navigateTo(index), 300);
          }}
        />
        
        {/* Main content with page transitions - Apple-inspired */}
        <main id="main-content" className="flex-grow overflow-hidden" aria-live="polite">
          <AnimatePresence mode="wait" initial={false}>
            {pages.map((page, index) => {
              if (index === currentPageIndex) {
                // Dynamically create component with current index for animation direction
                const PageComponent = page.component;
                return (
                  <PageComponent 
                    key={page.id} 
                    pageIndex={index} 
                    direction={swipeDirection} 
                  />
                );
              }
              return null;
            })}
          </AnimatePresence>
        </main>
        
        {/* Screen reader announcements for page transitions */}
        <div className="sr-only" aria-live="assertive">
          {currentPageIndex !== null && pages[currentPageIndex] && 
            `Current page: ${pages[currentPageIndex].title}`}
        </div>
      </div>
      <Toaster />
    </QueryClientProvider>
  );
}

export default App;
