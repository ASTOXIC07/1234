import * as React from "react"

const MOBILE_BREAKPOINT = 768

export function useIsMobile() {
  const [isMobile, setIsMobile] = React.useState<boolean | undefined>(undefined)
  const [isTouch, setIsTouch] = React.useState<boolean>(false)

  // Detect if device is touch-capable
  React.useEffect(() => {
    const hasTouchCapability = (
      'ontouchstart' in window || 
      navigator.maxTouchPoints > 0 ||
      // @ts-ignore - MS prefixed property
      navigator.msMaxTouchPoints > 0
    )
    setIsTouch(hasTouchCapability)
  }, [])

  // Monitor screen size
  React.useEffect(() => {
    const mql = window.matchMedia(`(max-width: ${MOBILE_BREAKPOINT - 1}px)`)
    const onChange = () => {
      setIsMobile(window.innerWidth < MOBILE_BREAKPOINT)
    }
    mql.addEventListener("change", onChange)
    setIsMobile(window.innerWidth < MOBILE_BREAKPOINT)
    return () => mql.removeEventListener("change", onChange)
  }, [])

  // Consider a device mobile if it's either small screen OR touch-capable
  return !!(isMobile || isTouch)
}
