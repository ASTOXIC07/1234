import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

// Register GSAP plugins
gsap.registerPlugin(ScrollTrigger);

// Add custom keyframe animations that will be used
gsap.registerEffect({
  name: "fadeInUp",
  effect: (targets: gsap.TweenTarget, config: { delay?: number, duration?: number }) => {
    return gsap.fromTo(
      targets,
      { opacity: 0, y: 50 },
      { 
        opacity: 1, 
        y: 0, 
        duration: config.duration || 0.8, 
        delay: config.delay || 0,
        ease: "power2.out" 
      }
    );
  },
  defaults: { duration: 0.8, delay: 0 },
});

// Animation for typewriter effect
gsap.registerEffect({
  name: "typewriter",
  effect: (targets: gsap.TweenTarget, config: { text: string, duration?: number }) => {
    const element = targets as HTMLElement;
    const text = config.text;
    const timeline = gsap.timeline();
    
    // Clear the text first
    element.innerHTML = '';
    element.style.opacity = '1';
    
    // Type each character with a delay
    const duration = config.duration || 0.05; // per character
    
    for (let i = 0; i < text.length; i++) {
      timeline.add(() => {
        element.innerHTML = text.substring(0, i + 1) + 
          (i < text.length - 1 ? '<span class="border-r-2 border-[#F8FAFC]"></span>' : '');
      }, i * duration);
    }
    
    return timeline;
  },
  defaults: { duration: 0.05 },
});

// Create scroll-triggered animations
export function createScrollAnimation(
  element: Element | null, 
  options: {
    opacity?: [number, number],
    y?: [number, number],
    scale?: [number, number],
    delay?: number,
    duration?: number,
    ease?: string,
    start?: string
  } = {}
) {
  if (!element) return null;
  
  const {
    opacity = [0, 1],
    y = [50, 0],
    scale = [1, 1],
    delay = 0,
    duration = 0.8,
    ease = "power2.out",
    start = "top 85%"
  } = options;
  
  // Set initial state
  gsap.set(element, {
    opacity: opacity[0],
    y: y[0],
    scale: scale[0]
  });
  
  // Create the scroll trigger
  return ScrollTrigger.create({
    trigger: element,
    start,
    onEnter: () => {
      gsap.to(element, {
        opacity: opacity[1],
        y: y[1],
        scale: scale[1],
        duration,
        delay,
        ease
      });
    },
    once: true
  });
}

export default gsap;
