/**
 * Advanced color utility functions for sophisticated animations
 */

/**
 * Convert hex color to RGB format
 * @param hex - Hex color string (with or without #)
 * @returns RGB color values as string "r, g, b"
 */
export function hexToRgb(hex: string): string {
  // Remove # if present
  hex = hex.replace(/^#/, '');
  
  // Parse hex to RGB
  const bigint = parseInt(hex, 16);
  const r = (bigint >> 16) & 255;
  const g = (bigint >> 8) & 255;
  const b = bigint & 255;
  
  return `${r}, ${g}, ${b}`;
}

/**
 * Convert hex color to RGBA format
 * @param hex - Hex color string
 * @param alpha - Alpha value (0-1)
 * @returns RGBA color string
 */
export function hexToRgba(hex: string, alpha: number): string {
  return `rgba(${hexToRgb(hex)}, ${alpha})`;
}

/**
 * Create a gradient color between two hex colors
 * @param color1 - Starting color (hex)
 * @param color2 - Ending color (hex)
 * @param ratio - Ratio between colors (0-1)
 * @returns Interpolated color in hex format
 */
export function gradientColor(color1: string, color2: string, ratio: number): string {
  // Ensure ratio is between 0 and 1
  ratio = Math.max(0, Math.min(1, ratio));
  
  // Convert hex to RGB
  const r1 = parseInt(color1.slice(1, 3), 16);
  const g1 = parseInt(color1.slice(3, 5), 16);
  const b1 = parseInt(color1.slice(5, 7), 16);
  
  const r2 = parseInt(color2.slice(1, 3), 16);
  const g2 = parseInt(color2.slice(3, 5), 16);
  const b2 = parseInt(color2.slice(5, 7), 16);
  
  // Interpolate colors
  const r = Math.round(r1 * (1 - ratio) + r2 * ratio);
  const g = Math.round(g1 * (1 - ratio) + g2 * ratio);
  const b = Math.round(b1 * (1 - ratio) + b2 * ratio);
  
  // Convert back to hex
  return `#${((1 << 24) + (r << 16) + (g << 8) + b).toString(16).slice(1)}`;
}

/**
 * Convert RGB to HSL color
 * @param r - Red (0-255)
 * @param g - Green (0-255)
 * @param b - Blue (0-255)
 * @returns HSL values as [h, s, l]
 */
export function rgbToHsl(r: number, g: number, b: number): [number, number, number] {
  r /= 255;
  g /= 255;
  b /= 255;
  
  const max = Math.max(r, g, b);
  const min = Math.min(r, g, b);
  let h = 0, s = 0, l = (max + min) / 2;
  
  if (max !== min) {
    const d = max - min;
    s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
    
    switch(max) {
      case r: h = (g - b) / d + (g < b ? 6 : 0); break;
      case g: h = (b - r) / d + 2; break;
      case b: h = (r - g) / d + 4; break;
    }
    
    h /= 6;
  }
  
  return [h * 360, s * 100, l * 100];
}

/**
 * Convert HSL to RGB color
 * @param h - Hue (0-360)
 * @param s - Saturation (0-100)
 * @param l - Lightness (0-100)
 * @returns RGB values as [r, g, b]
 */
export function hslToRgb(h: number, s: number, l: number): [number, number, number] {
  h /= 360;
  s /= 100;
  l /= 100;
  
  let r, g, b;
  
  if (s === 0) {
    r = g = b = l;
  } else {
    const hue2rgb = (p: number, q: number, t: number) => {
      if (t < 0) t += 1;
      if (t > 1) t -= 1;
      if (t < 1/6) return p + (q - p) * 6 * t;
      if (t < 1/2) return q;
      if (t < 2/3) return p + (q - p) * (2/3 - t) * 6;
      return p;
    };
    
    const q = l < 0.5 ? l * (1 + s) : l + s - l * s;
    const p = 2 * l - q;
    
    r = hue2rgb(p, q, h + 1/3);
    g = hue2rgb(p, q, h);
    b = hue2rgb(p, q, h - 1/3);
  }
  
  return [Math.round(r * 255), Math.round(g * 255), Math.round(b * 255)];
}

/**
 * Shift hue of a hex color
 * @param color - Hex color
 * @param amount - Amount to shift (-180 to 180)
 * @returns Shifted color in hex format
 */
export function shiftHue(color: string, amount: number): string {
  const r = parseInt(color.slice(1, 3), 16);
  const g = parseInt(color.slice(3, 5), 16);
  const b = parseInt(color.slice(5, 7), 16);
  
  const [h, s, l] = rgbToHsl(r, g, b);
  const newHue = (h + amount) % 360;
  const [nr, ng, nb] = hslToRgb(newHue, s, l);
  
  return `#${((1 << 24) + (nr << 16) + (ng << 8) + nb).toString(16).slice(1)}`;
}

/**
 * Generate color palette based on base color
 * @param baseColor - Base color in hex 
 * @returns Object with different variations of the color
 */
export function generateColorPalette(baseColor: string) {
  return {
    base: baseColor,
    lighter: adjustBrightness(baseColor, 20),
    darker: adjustBrightness(baseColor, -20),
    accent: shiftHue(baseColor, 30),
    complement: shiftHue(baseColor, 180),
    muted: adjustSaturation(baseColor, -30),
    vibrant: adjustSaturation(baseColor, 30),
  };
}

/**
 * Adjust brightness of a hex color
 * @param color - Hex color
 * @param percent - Percentage to adjust (-100 to 100)
 * @returns Adjusted color in hex format
 */
export function adjustBrightness(color: string, percent: number): string {
  const r = parseInt(color.slice(1, 3), 16);
  const g = parseInt(color.slice(3, 5), 16);
  const b = parseInt(color.slice(5, 7), 16);
  
  const [h, s, l] = rgbToHsl(r, g, b);
  const newL = Math.max(0, Math.min(100, l + percent));
  const [nr, ng, nb] = hslToRgb(h, s, newL);
  
  return `#${((1 << 24) + (nr << 16) + (ng << 8) + nb).toString(16).slice(1)}`;
}

/**
 * Adjust saturation of a hex color
 * @param color - Hex color
 * @param percent - Percentage to adjust (-100 to 100)
 * @returns Adjusted color in hex format
 */
export function adjustSaturation(color: string, percent: number): string {
  const r = parseInt(color.slice(1, 3), 16);
  const g = parseInt(color.slice(3, 5), 16);
  const b = parseInt(color.slice(5, 7), 16);
  
  const [h, s, l] = rgbToHsl(r, g, b);
  const newS = Math.max(0, Math.min(100, s + percent));
  const [nr, ng, nb] = hslToRgb(h, newS, l);
  
  return `#${((1 << 24) + (nr << 16) + (ng << 8) + nb).toString(16).slice(1)}`;
}