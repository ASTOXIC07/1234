import { useState, useRef, useEffect } from "react";
import ParticleBackground from "../components/ParticleBackground";
import PageTransition from "../components/PageTransition";
import { GradientText } from "../components/ui/gradient-text";
import { NeonButton } from "../components/ui/neon-button";
import { motion, AnimatePresence } from "framer-motion";
import { useToast } from "../hooks/use-toast";
import gsap from "gsap";

interface ContactPageProps {
  pageIndex: number;
  direction: number;
}

export default function ContactPage({ pageIndex, direction }: ContactPageProps) {
  const [formState, setFormState] = useState({
    name: "",
    email: "",
    company: "",
    message: "",
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { toast } = useToast();

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormState((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    // Simulate form submission
    await new Promise((resolve) => setTimeout(resolve, 1500));
    
    toast({
      title: "Message sent!",
      description: "We'll get back to you as soon as possible.",
    });
    
    setFormState({
      name: "",
      email: "",
      company: "",
      message: "",
    });
    
    setIsSubmitting(false);
  };

  // Add form blur animation effect
  const formRef = useRef<HTMLDivElement>(null);
  
  useEffect(() => {
    if (!formRef.current) return;
    
    // Animate the form fields appearing one after another
    const formElements = formRef.current.querySelectorAll('.form-field');
    gsap.fromTo(
      formElements,
      { opacity: 0, y: 20 },
      { 
        opacity: 1, 
        y: 0, 
        stagger: 0.1, 
        duration: 0.6,
        ease: "power2.out",
        delay: 0.5
      }
    );
    
    // Focus effect on input fields
    const inputFields = formRef.current.querySelectorAll('input, textarea');
    inputFields.forEach(field => {
      field.addEventListener('focus', () => {
        gsap.to(field, { 
          borderColor: '#4F46E5',
          boxShadow: '0 0 0 2px rgba(79, 70, 229, 0.3)',
          duration: 0.3
        });
      });
      
      field.addEventListener('blur', () => {
        gsap.to(field, { 
          borderColor: '#1E1E3F',
          boxShadow: 'none',
          duration: 0.3
        });
      });
    });
    
    return () => {
      inputFields.forEach(field => {
        field.removeEventListener('focus', () => {});
        field.removeEventListener('blur', () => {});
      });
    };
  }, []);

  return (
    <PageTransition index={pageIndex} direction={direction}>
      <div className="h-screen w-screen overflow-hidden bg-[#030014] text-white">
        <ParticleBackground color="#7C3AED" density={50} speed={0.3} />

        {/* Header Section */}
        <section className="pt-32 lg:pt-40 pb-20 relative">
          <div className="container mx-auto px-6">
            <div className="max-w-4xl mx-auto text-center">
              <motion.div
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.7, ease: [0.22, 1, 0.36, 1] }}
              >
                <h1 className="text-4xl md:text-6xl font-bold mb-6">
                  <GradientText>Get In Touch</GradientText>
                </h1>
                
                <p className="text-[#94A3B8] text-lg md:text-xl mb-10 max-w-3xl mx-auto">
                  Have questions about NeuraFlow? Ready to start your AI journey? 
                  Our team of experts is here to help you every step of the way.
                </p>
              </motion.div>
            </div>
          </div>
          
          {/* Animated background elements */}
          <div className="absolute top-40 left-1/2 transform -translate-x-1/2 w-[800px] h-[800px] rounded-full bg-gradient-to-r from-[#7C3AED]/10 to-[#2563EB]/10 blur-[100px] opacity-50 -z-10" />
        </section>

        {/* Contact Form Section */}
        <section className="py-10 relative">
          <div className="container mx-auto px-6">
            <div className="max-w-6xl mx-auto">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
                {/* Form Column */}
                <motion.div
                  initial={{ opacity: 0, x: -30 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.7, delay: 0.2 }}
                  className="order-2 lg:order-1"
                >
                  <div className="bg-[#0A0A1B]/70 backdrop-blur-sm rounded-xl p-8 border border-[#1E1E3F]">
                    <h2 className="text-2xl font-bold mb-6">Send us a message</h2>
                    
                    <form onSubmit={handleSubmit} className="space-y-6">
                      <div>
                        <label htmlFor="name" className="block text-sm font-medium text-[#94A3B8] mb-2">
                          Name
                        </label>
                        <input
                          type="text"
                          id="name"
                          name="name"
                          value={formState.name}
                          onChange={handleChange}
                          required
                          className="w-full px-4 py-3 bg-[#030014] border border-[#1E1E3F] rounded-lg focus:ring-2 focus:ring-[#4F46E5] focus:border-transparent transition-all"
                          placeholder="Your name"
                        />
                      </div>
                      
                      <div>
                        <label htmlFor="email" className="block text-sm font-medium text-[#94A3B8] mb-2">
                          Email
                        </label>
                        <input
                          type="email"
                          id="email"
                          name="email"
                          value={formState.email}
                          onChange={handleChange}
                          required
                          className="w-full px-4 py-3 bg-[#030014] border border-[#1E1E3F] rounded-lg focus:ring-2 focus:ring-[#4F46E5] focus:border-transparent transition-all"
                          placeholder="your.email@company.com"
                        />
                      </div>
                      
                      <div>
                        <label htmlFor="company" className="block text-sm font-medium text-[#94A3B8] mb-2">
                          Company
                        </label>
                        <input
                          type="text"
                          id="company"
                          name="company"
                          value={formState.company}
                          onChange={handleChange}
                          className="w-full px-4 py-3 bg-[#030014] border border-[#1E1E3F] rounded-lg focus:ring-2 focus:ring-[#4F46E5] focus:border-transparent transition-all"
                          placeholder="Your company name"
                        />
                      </div>
                      
                      <div>
                        <label htmlFor="message" className="block text-sm font-medium text-[#94A3B8] mb-2">
                          Message
                        </label>
                        <textarea
                          id="message"
                          name="message"
                          value={formState.message}
                          onChange={handleChange}
                          required
                          rows={5}
                          className="w-full px-4 py-3 bg-[#030014] border border-[#1E1E3F] rounded-lg focus:ring-2 focus:ring-[#4F46E5] focus:border-transparent transition-all resize-none"
                          placeholder="Tell us how we can help you..."
                        ></textarea>
                      </div>
                      
                      <div>
                        <NeonButton 
                          type="submit" 
                          className="w-full"
                          disabled={isSubmitting}
                        >
                          {isSubmitting ? (
                            <span className="flex items-center justify-center">
                              <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                              </svg>
                              Sending...
                            </span>
                          ) : "Send Message"}
                        </NeonButton>
                      </div>
                    </form>
                  </div>
                </motion.div>
                
                {/* Info Column */}
                <motion.div
                  initial={{ opacity: 0, x: 30 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.7, delay: 0.4 }}
                  className="order-1 lg:order-2"
                >
                  <div className="bg-gradient-to-br from-[#0A0A1B]/50 to-[#1E1E3F]/20 backdrop-blur-sm rounded-xl p-8 border border-[#1E1E3F] relative overflow-hidden">
                    {/* Background glow */}
                    <div className="absolute -top-20 -right-20 w-60 h-60 bg-[#7C3AED]/10 rounded-full blur-3xl" />
                    
                    <h2 className="text-2xl font-bold mb-6 relative z-10">Contact Information</h2>
                    
                    <div className="space-y-8">
                      <div className="flex items-start space-x-4">
                        <div className="p-3 rounded-lg bg-[#030014]/70 border border-[#1E1E3F]">
                          <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-[#4F46E5]">
                            <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z" />
                          </svg>
                        </div>
                        <div>
                          <h3 className="text-lg font-medium mb-1">Phone</h3>
                          <p className="text-[#94A3B8]">+1 (888) 234-5678</p>
                          <p className="text-[#94A3B8]">Mon-Fri, 9am-6pm EST</p>
                        </div>
                      </div>
                      
                      <div className="flex items-start space-x-4">
                        <div className="p-3 rounded-lg bg-[#030014]/70 border border-[#1E1E3F]">
                          <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-[#4F46E5]">
                            <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z" />
                            <polyline points="22,6 12,13 2,6" />
                          </svg>
                        </div>
                        <div>
                          <h3 className="text-lg font-medium mb-1">Email</h3>
                          <p className="text-[#94A3B8]">info@neuraflow.ai</p>
                          <p className="text-[#94A3B8]">support@neuraflow.ai</p>
                        </div>
                      </div>
                      
                      <div className="flex items-start space-x-4">
                        <div className="p-3 rounded-lg bg-[#030014]/70 border border-[#1E1E3F]">
                          <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-[#4F46E5]">
                            <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z" />
                            <circle cx="12" cy="10" r="3" />
                          </svg>
                        </div>
                        <div>
                          <h3 className="text-lg font-medium mb-1">Location</h3>
                          <p className="text-[#94A3B8]">123 AI Innovation Drive</p>
                          <p className="text-[#94A3B8]">San Francisco, CA 94105</p>
                        </div>
                      </div>
                    </div>
                    
                    <div className="mt-12 pt-8 border-t border-[#1E1E3F]">
                      <h3 className="text-lg font-medium mb-4">Connect with us</h3>
                      <div className="flex space-x-4">
                        {['twitter', 'linkedin', 'github', 'facebook'].map((social, index) => (
                          <a 
                            key={index}
                            href="#"
                            className="p-3 rounded-full bg-[#030014]/70 border border-[#1E1E3F] text-[#94A3B8] hover:text-white hover:border-[#4F46E5] transition-colors"
                          >
                            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                              {social === 'twitter' && (
                                <path d="M22 4s-.7 2.1-2 3.4c1.6 10-9.4 17.3-18 11.6 2.2.1 4.4-.6 6-2C3 15.5.5 9.6 3 5c2.2 2.6 5.6 4.1 9 4-.9-4.2 4-6.6 7-3.8 1.1 0 3-1.2 3-1.2z" />
                              )}
                              {social === 'linkedin' && (
                                <>
                                  <path d="M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-2-2 2 2 0 0 0-2 2v7h-4v-7a6 6 0 0 1 6-6z" />
                                  <rect x="2" y="9" width="4" height="12" />
                                  <circle cx="4" cy="4" r="2" />
                                </>
                              )}
                              {social === 'github' && (
                                <path d="M9 19c-5 1.5-5-2.5-7-3m14 6v-3.87a3.37 3.37 0 0 0-.94-2.61c3.14-.35 6.44-1.54 6.44-7A5.44 5.44 0 0 0 20 4.77 5.07 5.07 0 0 0 19.91 1S18.73.65 16 2.48a13.38 13.38 0 0 0-7 0C6.27.65 5.09 1 5.09 1A5.07 5.07 0 0 0 5 4.77a5.44 5.44 0 0 0-1.5 3.78c0 5.42 3.3 6.61 6.44 7A3.37 3.37 0 0 0 9 18.13V22" />
                              )}
                              {social === 'facebook' && (
                                <path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z" />
                              )}
                            </svg>
                          </a>
                        ))}
                      </div>
                    </div>
                  </div>
                </motion.div>
              </div>
            </div>
          </div>
        </section>

        {/* FAQ Section */}
        <section className="py-20 relative">
          <div className="container mx-auto px-6">
            <div className="max-w-4xl mx-auto">
              <motion.div
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-100px" }}
                transition={{ duration: 0.7 }}
                className="mb-12 text-center"
              >
                <h2 className="text-3xl md:text-4xl font-bold mb-6">
                  Frequently Asked <GradientText>Questions</GradientText>
                </h2>
              </motion.div>
              
              <div className="space-y-6">
                {[
                  {
                    question: "What industries does NeuraFlow specialize in?",
                    answer: "NeuraFlow's AI solutions are adaptable to various industries including healthcare, finance, retail, manufacturing, and more. Our platform is designed to be industry-agnostic while offering specialized modules for specific sector needs."
                  },
                  {
                    question: "Do I need technical expertise to use NeuraFlow?",
                    answer: "While technical expertise can be beneficial, NeuraFlow is designed with intuitive interfaces that allow non-technical users to leverage AI capabilities. We also offer comprehensive training and support to help teams at all technical levels."
                  },
                  {
                    question: "How long does implementation typically take?",
                    answer: "Implementation timelines vary based on the complexity of your needs. Simple deployments can be completed in as little as 2-4 weeks, while more complex enterprise integrations might take 2-3 months. Our team works closely with you to establish realistic timelines."
                  },
                  {
                    question: "Is my data secure with NeuraFlow?",
                    answer: "Absolutely. Security is our top priority. NeuraFlow employs industry-leading encryption, access controls, and compliance measures. We are SOC 2 compliant and adhere to GDPR, HIPAA, and other regulatory standards depending on your industry."
                  }
                ].map((faq, index) => (
                  <motion.div
                    key={index}
                    className="bg-[#0A0A1B]/50 backdrop-blur-sm rounded-xl p-6 border border-[#1E1E3F]"
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true, margin: "-100px" }}
                    transition={{ 
                      duration: 0.5, 
                      delay: index * 0.1,
                      ease: "easeOut" 
                    }}
                  >
                    <h3 className="text-xl font-semibold mb-3">{faq.question}</h3>
                    <p className="text-[#94A3B8]">{faq.answer}</p>
                  </motion.div>
                ))}
              </div>
            </div>
          </div>
          
          {/* Decorative elements */}
          <div className="absolute top-40 -left-40 w-96 h-96 rounded-full bg-[#7C3AED]/5 blur-3xl" />
          <div className="absolute bottom-10 -right-20 w-80 h-80 rounded-full bg-[#2563EB]/5 blur-3xl" />
        </section>
      </div>
    </PageTransition>
  );
}