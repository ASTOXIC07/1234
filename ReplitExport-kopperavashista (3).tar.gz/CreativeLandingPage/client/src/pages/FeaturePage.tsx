import { useEffect, useRef, useState } from "react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import ParticleBackground from "../components/ParticleBackground";
import PageTransition from "../components/PageTransition";
import { GradientText } from "../components/ui/gradient-text";
import { FeatureCard } from "../components/ui/feature-card";
import { motion, useTransform, useMotionValue, AnimatePresence } from "framer-motion";

// Register ScrollTrigger plugin
gsap.registerPlugin(ScrollTrigger);

// Feature data
const features = [
  {
    icon: (
      <svg
        xmlns="http://www.w3.org/2000/svg"
        width="24"
        height="24"
        viewBox="0 0 24 24"
        fill="none"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
      >
        <path d="M12 2a2 2 0 0 0-2 2c0 .74.4 1.39 1 1.73V7h-2v2h2v2c0 3.31-2.69 6-6 6h-.5" />
        <circle cx="5.5" cy="17" r="2.5" />
        <path d="M14 13c3.31 0 6-2.69 6-6 0-1.68-.71-3.31-2-4.44" />
        <path d="M20 4a2 2 0 1 0 0-4 2 2 0 0 0 0 4Z" />
        <path d="M14 7h-4" />
      </svg>
    ),
    title: "Neural Network Architecture",
    description: "Build and customize advanced neural networks with our intuitive drag-and-drop interface. Support for CNNs, RNNs, and Transformers."
  },
  {
    icon: (
      <svg
        xmlns="http://www.w3.org/2000/svg"
        width="24"
        height="24"
        viewBox="0 0 24 24"
        fill="none"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
      >
        <rect width="18" height="18" x="3" y="3" rx="2" />
        <path d="M7 7h10" />
        <path d="M7 12h10" />
        <path d="M7 17h10" />
      </svg>
    ),
    title: "Real-time Data Processing",
    description: "Process and analyze streaming data in real-time with our high-performance computing engine. Seamless integration with external data sources."
  },
  {
    icon: (
      <svg
        xmlns="http://www.w3.org/2000/svg"
        width="24"
        height="24"
        viewBox="0 0 24 24"
        fill="none"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
      >
        <path d="M12 2v4" />
        <path d="M20 12h-4" />
        <path d="M12 18v4" />
        <path d="M4 12H0" />
        <path d="M3.5 3.5l3 3" />
        <path d="M17.5 17.5l3 3" />
        <path d="M17.5 3.5l3-3" />
        <path d="M3.5 17.5l3 3" />
        <circle cx="12" cy="12" r="4" />
      </svg>
    ),
    title: "Auto ML Optimization",
    description: "Automatically optimize hyperparameters and model architecture with our advanced AutoML capabilities. Reduce training time and improve performance."
  },
  {
    icon: (
      <svg
        xmlns="http://www.w3.org/2000/svg"
        width="24"
        height="24"
        viewBox="0 0 24 24"
        fill="none"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
      >
        <path d="M21 12a9 9 0 0 0-9-9 9.75 9.75 0 0 0-6.74 2.74L3 8" />
        <path d="M3 3v5h5" />
        <path d="M3 12a9 9 0 0 0 9 9 9.75 9.75 0 0 0 6.74-2.74L21 16" />
        <path d="M16 16h5v5" />
      </svg>
    ),
    title: "Transfer Learning",
    description: "Leverage pre-trained models and adapt them to your specific needs with our transfer learning capabilities. Reduce training data requirements."
  },
  {
    icon: (
      <svg
        xmlns="http://www.w3.org/2000/svg"
        width="24"
        height="24"
        viewBox="0 0 24 24"
        fill="none"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
      >
        <path d="M21.21 15.89A10 10 0 1 1 8 2.83" />
        <path d="M22 12A10 10 0 0 0 12 2v10z" />
      </svg>
    ),
    title: "Advanced Visualization",
    description: "Visualize model performance, data distributions, and training progress with our interactive dashboards. Gain deeper insights into your AI models."
  },
  {
    icon: (
      <svg
        xmlns="http://www.w3.org/2000/svg"
        width="24"
        height="24"
        viewBox="0 0 24 24"
        fill="none"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
      >
        <path d="M2 13a6 6 0 1 0 12 0 4 4 0 1 0-8 0 2 2 0 0 0 4 0" />
        <circle cx="18" cy="6" r="3" />
        <path d="M18 9v12" />
      </svg>
    ),
    title: "Quantum Computing Integration",
    description: "Access quantum computing capabilities for solving complex optimization problems and accelerating certain ML algorithms."
  },
];

// Technical specifications
const techSpecs = [
  { name: "Processing Power", value: "Up to 100 TFLOPS" },
  { name: "Supported Frameworks", value: "TensorFlow, PyTorch, JAX" },
  { name: "API Latency", value: "<50ms response time" },
  { name: "Scalability", value: "Auto-scaling to handle any load" },
  { name: "Security", value: "Enterprise-grade, SOC 2 compliant" },
  { name: "Data Privacy", value: "GDPR & CCPA compliant" },
  { name: "Deployment Options", value: "Cloud, Edge, On-premise" },
  { name: "Support", value: "24/7 dedicated technical support" }
];

interface FeaturePageProps {
  pageIndex: number;
  direction: number;
}

export default function FeaturePage({ pageIndex, direction }: FeaturePageProps) {
  const contentRef = useRef<HTMLDivElement>(null);
  const chartRef = useRef<HTMLDivElement>(null);
  const [chartData] = useState([75, 92, 88, 95, 78, 85]);
  const [activeFeature, setActiveFeature] = useState(0);
  
  // Mouse position tracking for parallax effect
  const mouseX = useMotionValue(0);
  const mouseY = useMotionValue(0);
  
  // Parallax transformation values
  const rotateY = useTransform(mouseX, [-300, 300], [5, -5]);
  const rotateX = useTransform(mouseY, [-300, 300], [-5, 5]);
  
  // Handle mouse movement on card
  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const centerX = rect.left + rect.width / 2;
    const centerY = rect.top + rect.height / 2;
    mouseX.set(e.clientX - centerX);
    mouseY.set(e.clientY - centerY);
  };
  
  // Disable parallax effect when mouse leaves
  const handleMouseLeave = () => {
    mouseX.set(0);
    mouseY.set(0);
  };

  useEffect(() => {
    if (!contentRef.current) return;
    
    // Create master timeline for feature animations
    const masterTimeline = gsap.timeline();
    
    // Animate heading with split text effect
    const heading = contentRef.current.querySelector('.main-heading');
    if (heading) {
      const chars = heading.textContent?.split('') || [];
      
      // Clear the heading to prepare for animation
      heading.textContent = '';
      
      // Create spans for each character
      chars.forEach(char => {
        const span = document.createElement('span');
        span.textContent = char;
        span.style.opacity = '0';
        span.style.display = 'inline-block';
        heading.appendChild(span);
      });
      
      // Animate each character
      gsap.to(heading.children, {
        opacity: 1,
        y: 0,
        stagger: 0.03,
        duration: 0.5,
        ease: "power2.out",
        delay: 0.3
      });
    }
    
    // Animate feature cards with staggered effect
    const featureCards = contentRef.current.querySelectorAll('.feature-card');
    masterTimeline.fromTo(
      featureCards,
      { y: 50, opacity: 0 },
      { 
        y: 0, 
        opacity: 1, 
        stagger: 0.1, 
        duration: 0.7, 
        ease: "power2.out" 
      },
      0.5
    );
    
    // Animation for specs with glowing effect
    const specItems = contentRef.current.querySelectorAll('.spec-item');
    masterTimeline.fromTo(
      specItems,
      { 
        opacity: 0, 
        scale: 0.9,
        boxShadow: "0 0 0 rgba(124, 58, 237, 0)" 
      },
      { 
        opacity: 1, 
        scale: 1,
        boxShadow: "0 0 15px rgba(124, 58, 237, 0.3)",
        stagger: 0.1, 
        duration: 0.7, 
        ease: "power2.out"
      },
      0.7
    );
    
    // Animate the chart
    if (chartRef.current) {
      const chartBars = chartRef.current.querySelectorAll('.chart-bar');
      masterTimeline.fromTo(
        chartBars,
        { height: 0 },
        { 
          height: (index) => `${chartData[index]}%`, 
          duration: 1,
          stagger: 0.1,
          ease: "power2.out"
        },
        1
      );
    }
    
    // Auto-rotate through features
    const featureInterval = setInterval(() => {
      setActiveFeature(prev => (prev + 1) % features.length);
    }, 3000);
    
    // Cleanup
    return () => {
      clearInterval(featureInterval);
      masterTimeline.kill();
    };
  }, [chartData]);

  return (
    <PageTransition index={pageIndex} direction={direction}>
      <div className="h-screen w-screen overflow-x-hidden bg-[#030014] text-white" ref={contentRef}>
        <ParticleBackground color="#8B5CF6" density={80} speed={0.3} />
        
        {/* Grid overlay for cyber look */}
        <div className="absolute inset-0 z-0 grid-lines opacity-30"></div>

        {/* Main content with scroll */}
        <div className="h-full overflow-y-auto snap-y snap-mandatory scrollbar-thin scrollbar-thumb-[#7C3AED] scrollbar-track-[#1E1E3F]">
          {/* Header Section - Snap section */}
          <section className="h-screen w-full flex items-center justify-center snap-start relative py-16">
            <div className="container mx-auto px-6">
              <div className="max-w-5xl mx-auto text-center">
                <motion.div
                  className="mb-12"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ duration: 0.7, delay: 0.2 }}
                >
                  <h1 className="main-heading text-5xl md:text-7xl font-bold mb-6 tracking-tight">
                    <GradientText>Powerful Features</GradientText>
                  </h1>
                  
                  <p className="text-[#94A3B8] text-xl md:text-2xl mb-12 max-w-3xl mx-auto animate-on-view">
                    Discover the cutting-edge capabilities that make NeuraFlow
                    the leading platform for AI development.
                  </p>
                </motion.div>
                
                {/* Featured capability with rotating features */}
                <motion.div 
                  className="perspective-container max-w-4xl mx-auto"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.7, delay: 0.6 }}
                  onMouseMove={handleMouseMove}
                  onMouseLeave={handleMouseLeave}
                >
                  <motion.div
                    className="glass-morphism p-8 md:p-12 rounded-2xl border border-[#7C3AED]/20 overflow-hidden"
                    style={{
                      rotateY,
                      rotateX,
                      transformPerspective: 1200
                    }}
                  >
                    <div className="absolute -top-20 -right-20 w-64 h-64 rounded-full bg-[#7C3AED]/20 blur-[80px] animate-pulse-glow" />
                    
                    <div className="relative z-10">
                      <div className="flex flex-col md:flex-row gap-8 items-center">
                        <div className="w-full md:w-1/2">
                          <AnimatePresence mode="wait">
                            <motion.div
                              key={activeFeature}
                              initial={{ opacity: 0, x: -20 }}
                              animate={{ opacity: 1, x: 0 }}
                              exit={{ opacity: 0, x: 20 }}
                              transition={{ duration: 0.5 }}
                              className="mb-6"
                            >
                              <div className="w-16 h-16 rounded-xl bg-[#7C3AED]/20 backdrop-blur-md flex items-center justify-center mb-4">
                                <span className="text-[#7C3AED] text-3xl">
                                  {features[activeFeature].icon}
                                </span>
                              </div>
                              
                              <h3 className="text-2xl font-bold mb-3 text-glow">
                                {features[activeFeature].title}
                              </h3>
                              
                              <p className="text-[#94A3B8] text-lg">
                                {features[activeFeature].description}
                              </p>
                            </motion.div>
                          </AnimatePresence>
                          
                          {/* Feature navigation dots */}
                          <div className="flex items-center space-x-2 mt-4">
                            {features.map((_, index) => (
                              <button
                                key={index}
                                className={`w-3 h-3 rounded-full transition-all duration-300 ${
                                  activeFeature === index 
                                    ? 'bg-[#7C3AED] animate-pulse' 
                                    : 'bg-[#1E1E3F] hover:bg-[#7C3AED]/50'
                                }`}
                                onClick={() => setActiveFeature(index)}
                              />
                            ))}
                          </div>
                        </div>
                        
                        {/* Interactive 3D chart */}
                        <div className="w-full md:w-1/2 h-48" ref={chartRef}>
                          <div className="relative h-full w-full flex items-end justify-around p-4 border-b border-l border-[#1E1E3F]">
                            {/* Y axis label */}
                            <div className="absolute -left-8 top-1/2 transform -translate-y-1/2 -rotate-90 text-xs text-[#94A3B8]">
                              Performance
                            </div>
                            
                            {/* X axis label */}
                            <div className="absolute bottom-0 left-1/2 transform translate-y-6 -translate-x-1/2 text-xs text-[#94A3B8]">
                              Feature Categories
                            </div>
                            
                            {/* Chart bars */}
                            {chartData.map((value, index) => (
                              <div key={index} className="relative flex flex-col items-center">
                                <div 
                                  className="chart-bar w-8 bg-gradient-to-t from-[#7C3AED] to-[#2563EB] rounded-t-md"
                                  style={{ height: '0%' }}
                                >
                                  <div className="absolute -top-6 left-1/2 transform -translate-x-1/2 text-xs font-bold">
                                    {value}%
                                  </div>
                                </div>
                                <div className="mt-2 text-xs text-[#94A3B8]">Cat {index+1}</div>
                              </div>
                            ))}
                          </div>
                        </div>
                      </div>
                    </div>
                  </motion.div>
                </motion.div>
                
                {/* Scroll indicator */}
                <motion.div 
                  className="absolute bottom-8 left-1/2 transform -translate-x-1/2"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1, y: [0, 10, 0] }}
                  transition={{ 
                    opacity: { duration: 0.5, delay: 1.5 },
                    y: { repeat: Infinity, duration: 1.5, ease: "easeInOut" }
                  }}
                >
                  <div className="flex flex-col items-center">
                    <span className="text-[#94A3B8] text-sm mb-2">Scroll to explore</span>
                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-[#7C3AED]">
                      <path d="M12 5v14"/>
                      <path d="m19 12-7 7-7-7"/>
                    </svg>
                  </div>
                </motion.div>
              </div>
            </div>
            
            {/* Animated background elements */}
            <div className="absolute top-40 left-1/2 transform -translate-x-1/2 w-[900px] h-[900px] rounded-full bg-gradient-to-r from-[#7C3AED]/10 to-[#2563EB]/10 blur-[120px] opacity-50 -z-10 animate-pulse-glow" />
          </section>

          {/* Features Grid - Snap section */}
          <section className="min-h-screen w-full flex items-center justify-center snap-start relative py-16">
            <div className="container mx-auto px-6 py-12">
              <motion.div
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-100px" }}
                transition={{ duration: 0.7 }}
                className="mb-12 text-center"
              >
                <h2 className="text-3xl md:text-5xl font-bold mb-6">
                  Complete <GradientText>Feature Set</GradientText>
                </h2>
                <p className="text-[#94A3B8] max-w-3xl mx-auto">
                  Every aspect of NeuraFlow has been engineered for excellence, combining
                  cutting-edge technology with intuitive design.
                </p>
              </motion.div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8">
                {features.map((feature, index) => (
                  <motion.div 
                    key={index}
                    className="feature-card interactive-card"
                    initial={{ opacity: 0, y: 30 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true, margin: "-50px" }}
                    transition={{ 
                      duration: 0.7, 
                      delay: index * 0.1,
                      ease: [0.22, 1, 0.36, 1]
                    }}
                  >
                    <div className="glass-morphism-dark p-6 rounded-xl h-full">
                      <div className="mb-4">
                        <div className="w-12 h-12 rounded-lg bg-gradient-to-r from-[#7C3AED]/20 to-[#2563EB]/20 flex items-center justify-center text-[#7C3AED]">
                          {feature.icon}
                        </div>
                      </div>
                      
                      <h3 className="text-xl font-bold mb-3 bg-gradient-to-r from-white to-[#94A3B8] bg-clip-text text-transparent">
                        {feature.title}
                      </h3>
                      
                      <p className="text-[#94A3B8]">
                        {feature.description}
                      </p>
                    </div>
                  </motion.div>
                ))}
              </div>
            </div>
            
            {/* Decorative elements */}
            <div className="absolute -top-20 -right-40 w-96 h-96 rounded-full bg-[#7C3AED]/5 blur-3xl animate-float" />
            <div className="absolute -bottom-20 -left-20 w-80 h-80 rounded-full bg-[#2563EB]/5 blur-3xl animate-float-complex" />
          </section>

          {/* Technical Specifications - Snap section */}
          <section className="min-h-screen w-full flex items-center justify-center snap-start relative py-16">
            <div className="absolute inset-0 bg-gradient-to-b from-[#0A0A1B] to-[#030014] -z-10" />
            
            <div className="container mx-auto px-6 py-12">
              <div className="max-w-5xl mx-auto">
                <motion.div
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true, margin: "-100px" }}
                  transition={{ duration: 0.7 }}
                  className="mb-12 text-center"
                >
                  <h2 className="text-3xl md:text-5xl font-bold mb-6">
                    Technical <GradientText>Specifications</GradientText>
                  </h2>
                  <p className="text-[#94A3B8] max-w-3xl mx-auto">
                    Built from the ground up for performance, reliability, and scale.
                    Every component is optimized for enterprise-grade deployments.
                  </p>
                </motion.div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {techSpecs.map((spec, index) => (
                    <motion.div
                      key={index}
                      className="spec-item glass-morphism p-6 rounded-xl border border-[#1E1E3F] cursor-hover-zoom"
                      initial={{ opacity: 0, y: 20 }}
                      whileInView={{ opacity: 1, y: 0 }}
                      viewport={{ once: true, margin: "-50px" }}
                      transition={{ 
                        duration: 0.5, 
                        delay: index * 0.1,
                        ease: "easeOut" 
                      }}
                      whileHover={{
                        boxShadow: "0 0 20px rgba(124, 58, 237, 0.3)",
                        y: -5,
                        transition: { duration: 0.2 }
                      }}
                    >
                      <div className="flex items-start space-x-3">
                        <div className="mt-1 text-[#7C3AED]">
                          <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                            <polyline points="20 6 9 17 4 12"></polyline>
                          </svg>
                        </div>
                        <div>
                          <h3 className="text-[#94A3B8] text-base font-medium mb-1">{spec.name}</h3>
                          <p className="text-white text-xl font-semibold">{spec.value}</p>
                        </div>
                      </div>
                    </motion.div>
                  ))}
                </div>
                
                {/* Performance comparison card */}
                <motion.div
                  className="mt-12 glass-morphism p-8 rounded-xl border border-[#1E1E3F]"
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true, margin: "-50px" }}
                  transition={{ duration: 0.7, delay: 0.5 }}
                >
                  <h3 className="text-2xl font-bold mb-6 text-center">
                    Performance <GradientText>Comparison</GradientText>
                  </h3>
                  
                  <div className="overflow-x-auto">
                    <table className="w-full">
                      <thead>
                        <tr className="border-b border-[#1E1E3F]">
                          <th className="text-left py-3 px-4 text-[#94A3B8]">Metric</th>
                          <th className="text-left py-3 px-4 text-[#94A3B8]">NeuraFlow</th>
                          <th className="text-left py-3 px-4 text-[#94A3B8]">Competitor A</th>
                          <th className="text-left py-3 px-4 text-[#94A3B8]">Competitor B</th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr className="border-b border-[#1E1E3F]/50 hover:bg-[#1E1E3F]/20">
                          <td className="py-3 px-4">Training Speed</td>
                          <td className="py-3 px-4 text-[#4F46E5]">10x faster</td>
                          <td className="py-3 px-4">Baseline</td>
                          <td className="py-3 px-4">2x faster</td>
                        </tr>
                        <tr className="border-b border-[#1E1E3F]/50 hover:bg-[#1E1E3F]/20">
                          <td className="py-3 px-4">Model Accuracy</td>
                          <td className="py-3 px-4 text-[#4F46E5]">98.7%</td>
                          <td className="py-3 px-4">94.2%</td>
                          <td className="py-3 px-4">95.5%</td>
                        </tr>
                        <tr className="border-b border-[#1E1E3F]/50 hover:bg-[#1E1E3F]/20">
                          <td className="py-3 px-4">Resource Efficiency</td>
                          <td className="py-3 px-4 text-[#4F46E5]">High</td>
                          <td className="py-3 px-4">Low</td>
                          <td className="py-3 px-4">Medium</td>
                        </tr>
                        <tr className="hover:bg-[#1E1E3F]/20">
                          <td className="py-3 px-4">Enterprise Support</td>
                          <td className="py-3 px-4 text-[#4F46E5]">24/7 Dedicated</td>
                          <td className="py-3 px-4">Email only</td>
                          <td className="py-3 px-4">Business hours</td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                </motion.div>
              </div>
            </div>
            
            {/* Swipe indicator for next page */}
            <div className="absolute bottom-4 right-6 text-[#94A3B8] text-xs flex items-center">
              <div className="animate-swipe-hint mr-2">
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="m9 18 6-6-6-6"></path>
                </svg>
              </div>
              Swipe for showcase
            </div>
          </section>
        </div>
      </div>
    </PageTransition>
  );
}