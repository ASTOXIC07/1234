import { useRef, useState, useEffect } from "react";
import { motion, useSpring, AnimatePresence, useMotionValue, useTransform } from "framer-motion";
import PageTransition from "../components/PageTransition";
import EnhancedParticleBackground from "../components/EnhancedParticleBackground";
import { useIsMobile } from "../hooks/use-mobile";
import { generateColorPalette, shiftHue } from "../lib/color-utils";

interface HomePageProps {
  pageIndex: number;
  direction: number;
}

// Define the product features with human-relatable descriptions
const features = [
  {
    id: "fast",
    icon: (
      <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
        <path d="M13 2L3 14h9l-1 8 10-12h-9l1-8z"></path>
      </svg>
    ),
    title: "Magical Performance",
    description: "Experience lightning-fast responses that feel like magic. Your ideas come to life instantly.",
    stat: "50× Faster",
    percent: 100
  },
  {
    id: "accurate",
    icon: (
      <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
        <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path>
        <polyline points="22 4 12 14.01 9 11.01"></polyline>
      </svg>
    ),
    title: "Astonishing Accuracy",
    description: "Results so precise, you'll wonder how it knew exactly what you needed.",
    stat: "99.8%",
    percent: 99.8
  },
  {
    id: "efficient",
    icon: (
      <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
        <path d="M22 12h-4l-3 9L9 3l-3 9H2"></path>
      </svg>
    ),
    title: "Remarkably Efficient",
    description: "Works smarter, not harder. Extending battery life while delivering incredible results.",
    stat: "75% Less Energy",
    percent: 75
  }
];

export default function HomePage({ pageIndex, direction }: HomePageProps) {
  // Refs and state for interactive elements
  const containerRef = useRef<HTMLDivElement>(null);
  const [selectedFeature, setSelectedFeature] = useState(0);
  const [isVideoPlaying, setIsVideoPlaying] = useState(false);
  const [focusVisible, setFocusVisible] = useState(false);
  const isMobile = useIsMobile();
  
  // For realistic parallax effect
  const mouseX = useSpring(0, { stiffness: 50, damping: 20 });
  const mouseY = useSpring(0, { stiffness: 50, damping: 20 });
  
  // Handle mouse movement for subtle parallax
  const handleMouseMove = (e: React.MouseEvent) => {
    // Skip parallax on mobile devices or if user prefers reduced motion
    if (isMobile || prefersReducedMotion) return;
    
    const { clientX, clientY } = e;
    const centerX = window.innerWidth / 2;
    const centerY = window.innerHeight / 2;
    
    // Calculate distance from center with damping
    mouseX.set((clientX - centerX) * 0.005);
    mouseY.set((clientY - centerY) * 0.005);
  };

  // Spring-driven scroll indicator
  const scrollY = useSpring(0, { stiffness: 300, damping: 30 });
  
  // Detect if user prefers reduced motion
  const [prefersReducedMotion, setPrefersReducedMotion] = useState(false);
  
  useEffect(() => {
    // Check if user prefers reduced motion
    const mediaQuery = window.matchMedia('(prefers-reduced-motion: reduce)');
    setPrefersReducedMotion(mediaQuery.matches);
    
    // Listen for changes to motion preference
    const handleMediaChange = (e: MediaQueryListEvent) => {
      setPrefersReducedMotion(e.matches);
    };
    
    mediaQuery.addEventListener('change', handleMediaChange);
    return () => mediaQuery.removeEventListener('change', handleMediaChange);
  }, []);
  
  // Handle keyboard navigation
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // If tab is pressed, show focus indicators
      if (e.key === 'Tab') {
        setFocusVisible(true);
      }
      
      // If escape is pressed and video modal is open, close it
      if (e.key === 'Escape' && isVideoPlaying) {
        setIsVideoPlaying(false);
      }
    };
    
    // If mouse is clicked, hide focus indicators unless video modal is open
    const handleMouseDown = () => {
      if (!isVideoPlaying) {
        setFocusVisible(false);
      }
    };
    
    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('mousedown', handleMouseDown);
    
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('mousedown', handleMouseDown);
    };
  }, [isVideoPlaying]);
  
  return (
    <PageTransition index={pageIndex} direction={direction}>
      <div 
        className="relative h-screen w-screen overflow-hidden bg-black text-white" 
        ref={containerRef}
        onMouseMove={handleMouseMove}
        role="main"
        aria-label="NeuraFlow - Home Page"
      >
        {/* Advanced Particle Background with Neural Effects - Ultra premium version */}
        <div className="absolute inset-0 z-0">
          <EnhancedParticleBackground 
            primaryColor="#6366F1"
            secondaryColor="#FF5A5F"
            density={isMobile ? 40 : 90}
            speed={0.6}
            glowIntensity={0.7}
            mode="neural"
            depth={4}
            complexity="premium"
            interactive={true}
            reactivity={0.9}
            turbulence={0.15}
            particleSize={1.8}
          />
          <div className="absolute inset-0 bg-gradient-to-b from-gray-900/20 to-black/40 backdrop-blur-[1px]" />
        </div>
        
        {/* Dynamic gradients to enhance visuals */}
        <div className="absolute inset-0 z-0 pointer-events-none">
          <div
            className="absolute top-0 left-0 right-0 h-[50vh] bg-gradient-to-b from-blue-500/10 to-transparent opacity-30"
            style={{
              transform: `translateY(${mouseY.get() * -10}px)`,
            }}
          />
          <div 
            className="absolute bottom-0 left-0 right-0 h-[40vh] bg-gradient-to-t from-purple-500/10 to-transparent opacity-20"
            style={{
              transform: `translateY(${mouseY.get() * 10}px)`,
            }}
          />
          
          {/* Ultra-premium Apple-style blur orbs in background with advanced animations */}
          <div className="absolute top-[15%] left-[10%] w-[40vw] h-[40vw] rounded-full bg-purple-500/5 filter blur-[120px] animate-ultra-glow" 
            style={{
              transform: `translate(${mouseX.get() * -15}px, ${mouseY.get() * -15}px)`,
              transformStyle: 'preserve-3d',
              zIndex: 1
            }}
          />
          <div className="absolute bottom-[20%] right-[15%] w-[35vw] h-[35vw] rounded-full bg-blue-500/10 filter blur-[100px] animate-pulse-glow" 
            style={{
              animationDelay: '1s',
              transform: `translate(${mouseX.get() * 15}px, ${mouseY.get() * 15}px)`,
              zIndex: 1
            }}
          />
          
          {/* Neural network glow nodes */}
          <div className="absolute top-[30%] right-[25%] w-[15vw] h-[15vw] rounded-full bg-indigo-500/10 filter blur-[50px] animate-quantum-flicker" 
            style={{
              animationDelay: '0.5s',
              transform: `translate(${mouseX.get() * 10}px, ${mouseY.get() * 5}px)`,
              zIndex: 2
            }}
          />
          <div className="absolute bottom-[35%] left-[25%] w-[20vw] h-[20vw] rounded-full bg-pink-500/5 filter blur-[70px] animate-quantum-flicker" 
            style={{
              animationDelay: '1.5s',
              transform: `translate(${mouseX.get() * -8}px, ${mouseY.get() * 12}px)`,
              zIndex: 2
            }}
          />
          
          {/* Subtle accent highlights with neural pulse effect */}
          <div className="absolute top-[60%] left-[30%] w-[10vw] h-[10vw] rounded-full bg-transparent border border-indigo-500/20 animate-neural-pulse" 
            style={{
              transform: `translate(${mouseX.get() * 5}px, ${mouseY.get() * -7}px) scale(${1 + mouseY.get() * 0.01})`,
            }}
          />
          <div className="absolute top-[20%] right-[35%] w-[8vw] h-[8vw] rounded-full bg-transparent border border-purple-500/20 animate-neural-pulse" 
            style={{
              animationDelay: '0.7s',
              transform: `translate(${mouseX.get() * -6}px, ${mouseY.get() * 4}px) scale(${1 - mouseX.get() * 0.01})`,
            }}
          />
        </div>
        
        {/* Apple-style grain texture overlay */}
        <div className="absolute inset-0 z-0 opacity-[0.02] pointer-events-none mix-blend-overlay" 
          style={{ 
            backgroundImage: `url("data:image/svg+xml,%3Csvg viewBox='0 0 400 400' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noiseFilter'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.65' numOctaves='3' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noiseFilter)'/%3E%3C/svg%3E")` 
          }}
        />
        
        {/* Main content container with vertical sections */}
        <div className="relative z-10 h-full flex flex-col">
          {/* Hero Section */}
          <section className="flex-1 flex flex-col items-center justify-center px-6 md:px-16 pt-20 pb-10">
            <div className="max-w-5xl w-full mx-auto">
              {/* Headline with dramatically staggered reveal */}
              <div className="text-center mb-6">
                {/* Product badge - Apple style */}
                <motion.div
                  className="inline-block mb-4 px-3 py-1 rounded-full bg-white/10 backdrop-blur-md border border-white/10 text-xs font-medium text-white/80"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6, delay: 0.2 }}
                >
                  Introducing NeuraFlow
                </motion.div>
                
                <div className="overflow-hidden">
                  <motion.h1 
                    className="text-5xl md:text-7xl lg:text-8xl font-medium tracking-tight"
                    initial={{ y: prefersReducedMotion ? 0 : 100, opacity: 0 }}
                    animate={{ y: 0, opacity: 1 }}
                    transition={{ 
                      duration: prefersReducedMotion ? 0.5 : 1, 
                      ease: [0.16, 1, 0.3, 1]
                    }}
                    aria-label="Think. Create. Amaze."
                    tabIndex={0}
                  >
                    <span className="bg-clip-text text-transparent bg-gradient-to-r from-white to-white/80">
                      Think. Create. Amaze.
                    </span>
                  </motion.h1>
                </div>
              </div>
              
              {/* Conversational, human-centered subtitle */}
              <motion.p
                className="text-xl md:text-2xl font-light text-white/70 max-w-3xl mx-auto mb-10 leading-relaxed text-center"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ 
                  duration: 0.8, 
                  delay: 0.7,
                  ease: [0.16, 1, 0.3, 1]
                }}
              >
                The AI that understands you like a human, but performs like nothing you've ever seen before.
              </motion.p>
              
              {/* Apple-style "Play Video" showcase button */}
              <motion.div
                className="flex justify-center mb-14"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ 
                  duration: 0.7, 
                  delay: 1,
                  ease: [0.16, 1, 0.3, 1]
                }}
              >
                <button 
                  className={`group flex items-center space-x-2 bg-white/10 hover:bg-white/15 backdrop-blur-xl py-3 px-6 rounded-full border border-white/10 transition-all duration-300 ${focusVisible ? 'ring-2 ring-white ring-offset-2 ring-offset-black' : ''}`}
                  onClick={() => setIsVideoPlaying(true)}
                  aria-label="Watch the promotional film"
                  aria-haspopup="dialog"
                  onKeyDown={(e) => {
                    if (e.key === 'Enter' || e.key === ' ') {
                      e.preventDefault();
                      setIsVideoPlaying(true);
                    }
                  }}
                >
                  <div className="w-8 h-8 rounded-full bg-white flex items-center justify-center group-hover:scale-110 transition-transform duration-300" aria-hidden="true">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-3.5 w-3.5 text-black translate-x-[1px]" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
                      <polygon points="5 3 19 12 5 21 5 3"></polygon>
                    </svg>
                  </div>
                  <span className="text-sm font-medium text-white">Watch the film</span>
                </button>
              </motion.div>
              
              {/* Video modal - Apple style */}
              <AnimatePresence>
                {isVideoPlaying && (
                  <motion.div 
                    className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-xl"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                    transition={{ duration: prefersReducedMotion ? 0.2 : 0.3 }}
                    role="dialog"
                    aria-modal="true"
                    aria-labelledby="video-title"
                    onKeyDown={(e) => {
                      if (e.key === 'Escape') {
                        setIsVideoPlaying(false);
                      }
                    }}
                  >
                    <motion.div 
                      className="relative w-full max-w-5xl aspect-video bg-gray-950 rounded-2xl overflow-hidden shadow-2xl"
                      initial={{ scale: prefersReducedMotion ? 1 : 0.9, opacity: 0 }}
                      animate={{ scale: 1, opacity: 1 }}
                      exit={{ scale: prefersReducedMotion ? 1 : 0.9, opacity: 0 }}
                      transition={{ duration: prefersReducedMotion ? 0.3 : 0.4, ease: [0.16, 1, 0.3, 1] }}
                    >
                      <div className="sr-only" id="video-title">NeuraFlow Product Demonstration Video</div>
                      
                      <div className="absolute inset-0 flex items-center justify-center">
                        <div className="w-16 h-16 rounded-full bg-white/10 backdrop-blur-xl flex items-center justify-center animate-pulse" aria-hidden="true">
                          <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-white" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                            <circle cx="12" cy="12" r="10"></circle>
                            <line x1="10" y1="15" x2="10" y2="9"></line>
                            <line x1="14" y1="15" x2="14" y2="9"></line>
                          </svg>
                        </div>
                      </div>
                      
                      <button 
                        className={`absolute top-4 right-4 w-10 h-10 rounded-full bg-black/20 backdrop-blur-xl flex items-center justify-center hover:bg-black/40 transition-colors duration-300 ${focusVisible ? 'ring-2 ring-white' : ''}`}
                        onClick={() => setIsVideoPlaying(false)}
                        aria-label="Close video"
                        autoFocus={true}
                        onKeyDown={(e) => {
                          if (e.key === 'Enter' || e.key === ' ') {
                            e.preventDefault();
                            setIsVideoPlaying(false);
                          }
                        }}
                      >
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-white" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                          <line x1="18" y1="6" x2="6" y2="18"></line>
                          <line x1="6" y1="6" x2="18" y2="18"></line>
                        </svg>
                      </button>
                    </motion.div>
                  </motion.div>
                )}
              </AnimatePresence>
              
              {/* Interactive Feature Selector - Apple-style */}
              <motion.div
                className="relative mt-auto"
                initial={{ opacity: 0, y: 40 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ 
                  duration: 1, 
                  delay: 1.2,
                  ease: [0.16, 1, 0.3, 1]
                }}
              >
                {/* Feature card with dynamically changing content - Ultra premium 3D effect */}
                <motion.div 
                  className="relative z-10 bg-white/[0.03] backdrop-blur-2xl border border-white/10 rounded-3xl overflow-hidden shadow-2xl hover:shadow-indigo-500/10 transition-all duration-500 perspective-container"
                  whileHover={{ 
                    rotateX: 2, 
                    rotateY: 5, 
                    scale: 1.02,
                    boxShadow: "0 30px 60px -10px rgba(13, 16, 45, 0.5), 0 18px 36px -18px rgba(79, 70, 229, 0.3)"
                  }}
                  style={{ transformStyle: 'preserve-3d' }}
                  transition={{ 
                    type: "spring", 
                    stiffness: 300, 
                    damping: 20
                  }}
                >
                  {/* Feature navigation */}
                  <div className="grid grid-cols-3 border-b border-white/[0.07]" role="tablist" aria-label="Product features">
                    {features.map((feature, idx) => (
                      <button
                        key={feature.id}
                        onClick={() => setSelectedFeature(idx)}
                        className={`relative py-5 text-center transition-colors duration-300 ${
                          selectedFeature === idx ? "text-white" : "text-white/40 hover:text-white/60"
                        } ${focusVisible ? 'focus:outline-none focus:ring-2 focus:ring-white/40 focus:ring-offset-2 focus:ring-offset-black' : ''}`}
                        role="tab"
                        id={`feature-tab-${feature.id}`}
                        aria-selected={selectedFeature === idx}
                        aria-controls={`feature-panel-${feature.id}`}
                        tabIndex={selectedFeature === idx ? 0 : -1}
                        onKeyDown={(e) => {
                          // Handle left/right arrow keys for accessible keyboard navigation
                          if (e.key === 'ArrowLeft') {
                            e.preventDefault();
                            const newIndex = (selectedFeature - 1 + features.length) % features.length;
                            setSelectedFeature(newIndex);
                          } else if (e.key === 'ArrowRight') {
                            e.preventDefault();
                            const newIndex = (selectedFeature + 1) % features.length;
                            setSelectedFeature(newIndex);
                          }
                        }}
                      >
                        <span className="text-sm font-medium">{feature.title}</span>
                        
                        {/* Active indicator line - Apple style */}
                        {selectedFeature === idx && (
                          <motion.div 
                            className="absolute bottom-0 left-0 right-0 h-[2px] bg-white"
                            layoutId="featureIndicator"
                            transition={{ 
                              type: "spring", 
                              stiffness: prefersReducedMotion ? 400 : 300, 
                              damping: prefersReducedMotion ? 40 : 30 
                            }}
                          />
                        )}
                      </button>
                    ))}
                  </div>
                  
                  {/* Feature content with animated transitions */}
                  <div className="p-8 overflow-hidden">
                    <AnimatePresence mode="wait">
                      <motion.div
                        key={features[selectedFeature].id}
                        initial={{ opacity: 0, y: prefersReducedMotion ? 10 : 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: prefersReducedMotion ? -10 : -20 }}
                        transition={{ 
                          duration: prefersReducedMotion ? 0.3 : 0.5, 
                          ease: [0.16, 1, 0.3, 1] 
                        }}
                        className="flex flex-col md:flex-row items-start md:items-center gap-6"
                        role="tabpanel"
                        id={`feature-panel-${features[selectedFeature].id}`}
                        aria-labelledby={`feature-tab-${features[selectedFeature].id}`}
                      >
                        {/* Feature icon with ultra-premium glowing background */}
                        <motion.div 
                          className="flex-shrink-0 w-12 h-12 rounded-full bg-gradient-to-br from-blue-500/20 to-purple-500/20 backdrop-blur-xl flex items-center justify-center shadow-lg border border-white/10 animate-neural-pulse"
                          aria-hidden="true"
                          initial={{ scale: 0.8, opacity: 0 }}
                          animate={{ scale: 1, opacity: 1 }}
                          transition={{ 
                            type: "spring",
                            stiffness: 400,
                            damping: 25,
                            delay: 0.1
                          }}
                          whileHover={{ 
                            scale: 1.05,
                            boxShadow: "0 0 20px 5px rgba(99, 102, 241, 0.3)"
                          }}
                        >
                          <motion.div 
                            className="text-blue-400"
                            animate={{ 
                              rotate: [-2, 2, -2], 
                              scale: [0.95, 1.05, 0.95] 
                            }}
                            transition={{ 
                              duration: 4,
                              ease: "easeInOut",
                              repeat: Infinity,
                              repeatType: "mirror"
                            }}
                          >
                            {features[selectedFeature].icon}
                          </motion.div>
                          
                          {/* Inner glow effect */}
                          <div className="absolute inset-0 rounded-full bg-gradient-to-tr from-indigo-500/5 to-purple-500/10 animate-pulse-glow" />
                          
                          {/* Subtle outer ring */}
                          <div className="absolute -inset-1 rounded-full border border-white/5 opacity-50" />
                        </motion.div>
                        
                        <div className="flex-1">
                          <h3 
                            className="text-xl font-medium text-white mb-2"
                            tabIndex={0} 
                          >
                            {features[selectedFeature].title}
                          </h3>
                          <p className="text-white/60 text-base mb-4 font-light">
                            {features[selectedFeature].description}
                          </p>
                          
                          {/* Progress bar for metrics - Apple style */}
                          <div className="space-y-2">
                            <div className="flex items-center justify-between">
                              <span className="text-sm text-white/50 font-light">Industry Average</span>
                              <span className="text-sm text-white font-medium">{features[selectedFeature].stat}</span>
                            </div>
                            <motion.div 
                              className="h-[6px] bg-white/5 rounded-full overflow-hidden w-full relative backdrop-blur-sm"
                              role="progressbar" 
                              aria-valuenow={features[selectedFeature].percent} 
                              aria-valuemin={0} 
                              aria-valuemax={100}
                              aria-label={`${features[selectedFeature].percent}% better than industry average`}
                              initial={{ opacity: 0.5, y: 5 }}
                              animate={{ opacity: 1, y: 0 }}
                              transition={{ duration: 0.5, delay: 0.1 }}
                              whileHover={{ boxShadow: "0 0 10px 1px rgba(99, 102, 241, 0.2)" }}
                            >
                              {/* Background subtle pulse animation */}
                              <div className="absolute inset-0 bg-gradient-to-r from-indigo-500/5 to-purple-500/10 animate-pulse opacity-50" />
                              
                              {/* Main progress bar */}
                              <motion.div 
                                className="relative h-full bg-gradient-to-r from-blue-500 via-indigo-500 to-blue-500 background-size-200"
                                initial={{ width: "0%" }}
                                animate={{ 
                                  width: `${features[selectedFeature].percent}%`,
                                  backgroundPosition: ["0% 0%", "100% 0%"] 
                                }}
                                transition={{ 
                                  width: {
                                    duration: prefersReducedMotion ? 0.8 : 1.5, 
                                    ease: [0.34, 1.56, 0.64, 1],
                                    delay: 0.2
                                  },
                                  backgroundPosition: {
                                    duration: 3,
                                    ease: "linear",
                                    repeat: Infinity,
                                    repeatType: "reverse"
                                  }
                                }}
                              >
                                {/* Shimmer effect */}
                                <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent animate-glass-shine" />
                              </motion.div>
                              
                              {/* Subtle glow effect */}
                              <div className="absolute top-0 bottom-0 left-0 w-1/4 bg-gradient-to-r from-transparent to-white/10 animate-pulse-glow" 
                                style={{ 
                                  width: `${features[selectedFeature].percent / 4}%`,
                                  filter: 'blur(4px)',
                                  opacity: 0.5,
                                  transformOrigin: 'left center'
                                }} 
                              />
                            </motion.div>
                          </div>
                        </div>
                        
                        {/* Apple-style "Learn more" link */}
                        <div className="flex-shrink-0">
                          <button 
                            className={`group flex items-center space-x-1.5 text-blue-400 hover:text-blue-300 transition-colors duration-300 ${focusVisible ? 'focus:ring-2 focus:ring-blue-400 focus:outline-none rounded px-2 py-1' : ''}`}
                            aria-label={`Learn more about ${features[selectedFeature].title}`}
                          >
                            <span className="text-sm">Learn more</span>
                            <svg 
                              xmlns="http://www.w3.org/2000/svg" 
                              className="h-4 w-4 transform group-hover:translate-x-0.5 transition-transform duration-300" 
                              viewBox="0 0 24 24" 
                              fill="none" 
                              stroke="currentColor" 
                              strokeWidth="2" 
                              strokeLinecap="round" 
                              strokeLinejoin="round"
                              aria-hidden="true"
                            >
                              <path d="M5 12h14M12 5l7 7-7 7"/>
                            </svg>
                          </button>
                        </div>
                      </motion.div>
                    </AnimatePresence>
                  </div>
                </motion.div>
                
                {/* Decorative element behind the card - Apple style depth */}
                <div 
                  className="absolute -bottom-6 left-[10%] right-[10%] h-[30%] bg-blue-500/10 blur-[120px] rounded-full"
                  style={{
                    transform: `translateX(${mouseX.get() * 30}px)`,
                  }}
                />
              </motion.div>
            </div>
          </section>
          
          {/* Bottom nav section with CTA buttons - Apple style */}
          <motion.section 
            className="flex justify-center items-center pb-10 px-6"
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ 
              duration: 0.8, 
              delay: 1.6,
              ease: [0.16, 1, 0.3, 1]
            }}
          >
            <div className="flex flex-col sm:flex-row gap-4">
              <motion.button
                className={`px-8 py-4 rounded-full bg-white text-black/90 text-sm font-medium shadow-lg ${focusVisible ? 'focus:outline-none focus:ring-2 focus:ring-white focus:ring-offset-2 focus:ring-offset-black' : ''}`}
                whileHover={prefersReducedMotion ? {} : { 
                  scale: 1.03, 
                  boxShadow: "0 10px 25px -5px rgba(255, 255, 255, 0.2)" 
                }}
                whileTap={prefersReducedMotion ? {} : { scale: 0.97 }}
                transition={{ duration: 0.2, ease: [0.16, 1, 0.3, 1] }}
                aria-label="Order NeuraFlow Now"
                onKeyDown={(e) => {
                  if (e.key === 'Enter' || e.key === ' ') {
                    e.preventDefault();
                    // Handle order action
                  }
                }}
              >
                Order Now
              </motion.button>
              
              <motion.button
                className={`px-8 py-4 rounded-full bg-white/10 backdrop-blur-lg border border-white/10 text-white text-sm font-medium shadow-md ${focusVisible ? 'focus:outline-none focus:ring-2 focus:ring-white/50 focus:ring-offset-2 focus:ring-offset-black' : ''}`}
                whileHover={prefersReducedMotion ? {} : { 
                  scale: 1.03, 
                  backgroundColor: "rgba(255, 255, 255, 0.15)" 
                }}
                whileTap={prefersReducedMotion ? {} : { scale: 0.97 }}
                transition={{ duration: 0.2, ease: [0.16, 1, 0.3, 1] }}
                aria-label="See All NeuraFlow Features"
                onKeyDown={(e) => {
                  if (e.key === 'Enter' || e.key === ' ') {
                    e.preventDefault();
                    // Handle features navigation
                  }
                }}
              >
                See All Features
              </motion.button>
            </div>
          </motion.section>
        </div>
        
        {/* Elegant scroll indicator with continuous animation */}
        <motion.div 
          className="absolute bottom-6 left-1/2 transform -translate-x-1/2 flex flex-col items-center"
          initial={{ opacity: 0 }}
          animate={{ opacity: 0.6 }}
          transition={{ delay: 2.2, duration: 1 }}
          style={{ y: scrollY }}
          aria-hidden={prefersReducedMotion ? "true" : "false"}  // Hide from screen readers if user prefers reduced motion
        >
          <motion.div
            animate={prefersReducedMotion ? {} : { 
              y: [0, 8, 0],
              opacity: [0.5, 1, 0.5]
            }}
            transition={{ 
              repeat: Infinity, 
              duration: 2.5,
              ease: "easeInOut" 
            }}
          >
            <svg 
              xmlns="http://www.w3.org/2000/svg" 
              className="h-6 w-6 text-white/60" 
              viewBox="0 0 24 24" 
              fill="none" 
              stroke="currentColor" 
              strokeWidth="1.5" 
              strokeLinecap="round" 
              strokeLinejoin="round"
              aria-hidden="true"
              focusable="false"
            >
              <path d="M7 13l5 5 5-5M7 6l5 5 5-5"/>
            </svg>
          </motion.div>
          {/* Use sr-only class to provide additional context for screen readers */}
          <span className="sr-only">Use arrow keys or swipe to navigate between pages</span>
          <span className="text-xs text-white/50 font-light mt-2 tracking-wide">Swipe to explore</span>
        </motion.div>
      </div>
    </PageTransition>
  );
}