import { useEffect, useRef, useState } from "react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import ParticleBackground from "../components/ParticleBackground";
import PageTransition from "../components/PageTransition";
import { GradientText } from "../components/ui/gradient-text";
import { NeonButton } from "../components/ui/neon-button";
import { motion, useScroll, useTransform, AnimatePresence } from "framer-motion";

// Register ScrollTrigger plugin
gsap.registerPlugin(ScrollTrigger);

// Case studies data
const caseStudies = [
  {
    title: "Healthcare AI Diagnostics",
    description: "NeuraFlow powers an AI-based diagnostic tool that analyzes medical images with 99.2% accuracy, helping doctors identify diseases earlier and with greater precision.",
    metrics: [
      { label: "Accuracy", value: "99.2%" },
      { label: "Processing Time", value: "<2s" },
      { label: "Lives Impacted", value: "250,000+" }
    ],
    color: "purple"
  },
  {
    title: "Financial Fraud Detection",
    description: "A major bank implemented NeuraFlow's real-time fraud detection system, reducing fraudulent transactions by 87% and saving over $40M annually.",
    metrics: [
      { label: "Fraud Reduction", value: "87%" },
      { label: "False Positives", value: "<0.1%" },
      { label: "Annual Savings", value: "$40M+" }
    ],
    color: "blue"
  },
  {
    title: "Smart City Infrastructure",
    description: "NeuraFlow's IoT integration enables real-time traffic optimization, reducing congestion by 42% and lowering carbon emissions in urban areas.",
    metrics: [
      { label: "Congestion Reduction", value: "42%" },
      { label: "Carbon Reduction", value: "27%" },
      { label: "Energy Savings", value: "35%" }
    ],
    color: "cyan"
  }
];

// Testimonials data
const testimonials = [
  {
    quote: "NeuraFlow transformed our approach to data analysis. The platform's speed and accuracy are unparalleled in the industry.",
    author: "Dr. Sarah Chen",
    position: "CTO, MediTech Solutions"
  },
  {
    quote: "The implementation was seamless, and the results exceeded our expectations. ROI within the first three months.",
    author: "Michael Rodriguez",
    position: "Head of Innovation, Global Financial"
  },
  {
    quote: "Customer support is exceptional. The team at NeuraFlow truly partners with you to ensure success.",
    author: "Jessica Wong",
    position: "Data Science Director, RetailX"
  },
  {
    quote: "We evaluated several AI platforms and NeuraFlow stood out for its scalability and enterprise-grade features.",
    author: "Robert Johnson",
    position: "CEO, TechVision Inc."
  }
];

interface ShowcasePageProps {
  pageIndex: number;
  direction: number;
}

export default function ShowcasePage({ pageIndex, direction }: ShowcasePageProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const showcaseRef = useRef<HTMLDivElement>(null);
  const [activeStudy, setActiveStudy] = useState(0);
  const [autoplayEnabled, setAutoplayEnabled] = useState(true);
  const [isViewingDetails, setIsViewingDetails] = useState(false);
  
  // Parallax effect for background
  const { scrollYProgress } = useScroll({
    target: containerRef,
    offset: ["start end", "end start"]
  });
  
  const y = useTransform(scrollYProgress, [0, 1], [0, -50]);
  
  // Handle study navigation
  const nextStudy = () => {
    setActiveStudy((prev) => (prev + 1) % caseStudies.length);
  };
  
  const prevStudy = () => {
    setActiveStudy((prev) => (prev === 0 ? caseStudies.length - 1 : prev - 1));
  };
  
  // Testimonial carousel autoplay
  const [activeTestimonial, setActiveTestimonial] = useState(0);
  
  useEffect(() => {
    if (autoplayEnabled) {
      const interval = setInterval(() => {
        setActiveStudy((prev) => (prev + 1) % caseStudies.length);
      }, 5000);
      
      return () => clearInterval(interval);
    }
  }, [autoplayEnabled]);
  
  // Testimonial autoplay
  useEffect(() => {
    const interval = setInterval(() => {
      setActiveTestimonial((prev) => (prev + 1) % testimonials.length);
    }, 4000);
    
    return () => clearInterval(interval);
  }, []);
  
  // Initialize animations
  useEffect(() => {
    if (!showcaseRef.current) return;
    
    const masterTimeline = gsap.timeline();
    
    // Animate title with character splitting
    const heading = showcaseRef.current.querySelector('.showcase-heading');
    if (heading) {
      const chars = heading.textContent?.split('') || [];
      heading.textContent = '';
      
      chars.forEach(char => {
        const span = document.createElement('span');
        span.textContent = char === ' ' ? '\u00A0' : char;
        span.style.display = 'inline-block';
        span.style.opacity = '0';
        span.style.transform = 'translateY(20px)';
        heading.appendChild(span);
      });
      
      gsap.to(heading.children, {
        opacity: 1,
        y: 0,
        stagger: 0.03,
        duration: 0.5,
        ease: "power2.out",
        delay: 0.3
      });
    }
    
    // Animate the case study cards
    const caseStudyElements = showcaseRef.current.querySelectorAll('.case-study-card');
    masterTimeline.fromTo(
      caseStudyElements,
      { 
        y: 30, 
        opacity: 0,
        scale: 0.95
      },
      { 
        y: 0, 
        opacity: 1,
        scale: 1,
        stagger: 0.15,
        duration: 0.7,
        ease: "power2.out"
      },
      0.5
    );
    
    // Animate the stats counters
    const counterElements = showcaseRef.current.querySelectorAll('.counter-value');
    counterElements.forEach(element => {
      const targetValue = parseInt(element.textContent || '0', 10);
      
      gsap.fromTo(
        element,
        { textContent: '0' },
        {
          textContent: targetValue,
          duration: 2,
          snap: { textContent: 1 },
          ease: "power2.out",
          delay: 1
        }
      );
    });
    
    // Clean up
    return () => {
      masterTimeline.kill();
      ScrollTrigger.getAll().forEach(trigger => trigger.kill());
    };
  }, []);

  return (
    <PageTransition index={pageIndex} direction={direction}>
      <div className="h-screen w-screen overflow-hidden bg-[#030014] text-white" ref={containerRef}>
        <ParticleBackground color="#0EA5E9" density={80} speed={0.3} />
        
        {/* Grid overlay for cyber look */}
        <div className="absolute inset-0 z-0 grid-lines opacity-20"></div>
        
        {/* Main content */}
        <div className="h-full overflow-y-auto snap-y snap-mandatory" ref={showcaseRef}>
          {/* Hero Section - Snap Section */}
          <section className="h-screen w-full flex items-center justify-center snap-start relative py-16">
            <div className="container mx-auto px-6">
              <div className="max-w-5xl mx-auto text-center">
                <motion.div
                  className="mb-12"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ duration: 0.7, delay: 0.2 }}
                >
                  <h1 className="showcase-heading text-5xl md:text-7xl font-bold mb-6 tracking-tight">
                    <GradientText>Success Stories</GradientText>
                  </h1>
                  
                  <p className="text-[#94A3B8] text-xl md:text-2xl mb-12 max-w-3xl mx-auto animate-on-view">
                    Discover how leading organizations leverage NeuraFlow
                    to drive innovation and transformation.
                  </p>
                </motion.div>
                
                {/* Interactive case study showcase */}
                <div className="relative max-w-5xl mx-auto perspective-container">
                  {/* Study cards */}
                  <motion.div
                    className="relative z-10"
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.7, delay: 0.6 }}
                  >
                    <AnimatePresence mode="wait">
                      <motion.div
                        key={`case-study-${activeStudy}`}
                        initial={{ opacity: 0, x: direction > 0 ? 100 : -100 }}
                        animate={{ opacity: 1, x: 0 }}
                        exit={{ opacity: 0, x: direction > 0 ? -100 : 100 }}
                        transition={{ 
                          duration: 0.5,
                          ease: [0.22, 1, 0.36, 1]
                        }}
                        className="case-study-card"
                      >
                        <div className="glass-morphism p-8 md:p-10 rounded-2xl border border-[#0EA5E9]/20 overflow-hidden">
                          {/* Background decoration */}
                          <div className={`absolute -top-40 -right-40 w-80 h-80 rounded-full bg-${caseStudies[activeStudy].color}-500/10 blur-[100px] animate-pulse-glow`} />
                          <div className={`absolute -bottom-40 -left-40 w-80 h-80 rounded-full bg-${caseStudies[activeStudy].color}-500/10 blur-[100px] animate-pulse-glow`} />
                          
                          <div className="relative z-10">
                            <div className="flex flex-col md:flex-row gap-8 items-center">
                              {/* Visual element */}
                              <div className="w-full md:w-2/5 aspect-square overflow-hidden rounded-xl relative">
                                <div className={`absolute inset-0 bg-gradient-to-br from-${caseStudies[activeStudy].color}-500/20 to-blue-500/20`}>
                                  <div className="w-full h-full flex items-center justify-center">
                                    <div className={`w-32 h-32 rounded-full bg-gradient-to-r from-${caseStudies[activeStudy].color}-500/40 to-blue-500/40 blur-xl`} />
                                  </div>
                                </div>
                                
                                <div className="absolute inset-0 flex items-center justify-center">
                                  <motion.div 
                                    className="p-6 border border-white/20 rounded-md backdrop-blur-lg bg-black/30 cursor-pointer"
                                    whileHover={{ scale: 1.05, boxShadow: "0 0 20px rgba(14, 165, 233, 0.3)" }}
                                    transition={{ duration: 0.2 }}
                                  >
                                    <svg 
                                      xmlns="http://www.w3.org/2000/svg" 
                                      width="64" 
                                      height="64" 
                                      viewBox="0 0 24 24" 
                                      fill="none" 
                                      stroke="currentColor" 
                                      strokeWidth="1" 
                                      strokeLinecap="round" 
                                      strokeLinejoin="round"
                                      className={`text-${caseStudies[activeStudy].color}-400`}
                                    >
                                      {activeStudy === 0 ? (
                                        // Healthcare icon
                                        <>
                                          <path d="M2 8l2 2-2 2 2 2-2 2" />
                                          <path d="M22 8l-2 2 2 2-2 2 2 2" />
                                          <circle cx="12" cy="12" r="3" />
                                          <path d="M5 3a1 1 0 0 1 1-1h12a1 1 0 0 1 1 1v2a1 1 0 0 1-1 1H6a1 1 0 0 1-1-1V3z" />
                                          <path d="M5 19a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-2a1 1 0 0 0-1-1H6a1 1 0 0 0-1 1v2z" />
                                        </>
                                      ) : activeStudy === 1 ? (
                                        // Finance icon
                                        <>
                                          <path d="M2 17V7a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2Z" />
                                          <path d="M12 7v10" />
                                          <path d="M17 12H7" />
                                        </>
                                      ) : (
                                        // Smart city icon
                                        <>
                                          <path d="M3 9h18v10a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V9Z" />
                                          <path d="m3 9 2.45-4.9A2 2 0 0 1 7.24 3h9.52a2 2 0 0 1 1.8 1.1L21 9" />
                                          <path d="M12 3v6" />
                                        </>
                                      )}
                                    </svg>
                                  </motion.div>
                                </div>
                              </div>
                              
                              {/* Case study content */}
                              <div className="w-full md:w-3/5 text-left">
                                <div className="flex items-center space-x-2 mb-2">
                                  <div className={`h-1 w-16 bg-gradient-to-r from-${caseStudies[activeStudy].color}-500 to-blue-500 rounded-full`}></div>
                                  <span className="text-sm text-[#94A3B8]">CASE STUDY {activeStudy + 1}/{caseStudies.length}</span>
                                </div>
                                
                                <h2 className="text-2xl md:text-3xl font-bold mb-4 text-glow">
                                  {caseStudies[activeStudy].title}
                                </h2>
                                
                                <p className="text-[#94A3B8] text-lg mb-6">
                                  {caseStudies[activeStudy].description}
                                </p>
                                
                                <div className="grid grid-cols-3 gap-4 mb-8">
                                  {caseStudies[activeStudy].metrics.map((metric, i) => (
                                    <div key={i} className="bg-[#0A0A1B]/70 border border-[#1E1E3F] rounded-lg p-4 cursor-hover-zoom">
                                      <p className="text-[#94A3B8] text-sm mb-1">{metric.label}</p>
                                      <p className="counter-value text-xl font-bold text-glow">{metric.value}</p>
                                    </div>
                                  ))}
                                </div>
                                
                                <div className="flex space-x-4">
                                  <NeonButton glowing>
                                    <span className="flex items-center">
                                      <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                                        <path d="M18 15v3H6v3"></path>
                                        <path d="M3 3h18v12H3z"></path>
                                      </svg>
                                      View Demo
                                    </span>
                                  </NeonButton>
                                  
                                  <NeonButton variant="secondary">
                                    <span className="flex items-center">
                                      <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                                        <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path>
                                        <polyline points="7 10 12 15 17 10"></polyline>
                                        <line x1="12" y1="15" x2="12" y2="3"></line>
                                      </svg>
                                      Download Case Study
                                    </span>
                                  </NeonButton>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </motion.div>
                    </AnimatePresence>
                    
                    {/* Navigation controls */}
                    <div className="flex justify-between mt-8">
                      <motion.button
                        className="p-3 rounded-full bg-[#0A0A1B]/70 border border-[#1E1E3F] text-white"
                        onClick={prevStudy}
                        whileHover={{ scale: 1.1, backgroundColor: 'rgba(14, 165, 233, 0.2)' }}
                        whileTap={{ scale: 0.95 }}
                      >
                        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                          <path d="m15 18-6-6 6-6" />
                        </svg>
                      </motion.button>
                      
                      <div className="flex space-x-2">
                        {caseStudies.map((_, index) => (
                          <button
                            key={index}
                            className={`w-3 h-3 rounded-full transition-all duration-300 ${
                              activeStudy === index 
                                ? 'bg-[#0EA5E9] animate-pulse' 
                                : 'bg-[#1E1E3F] hover:bg-[#0EA5E9]/50'
                            }`}
                            onClick={() => setActiveStudy(index)}
                          />
                        ))}
                      </div>
                      
                      <motion.button
                        className="p-3 rounded-full bg-[#0A0A1B]/70 border border-[#1E1E3F] text-white"
                        onClick={nextStudy}
                        whileHover={{ scale: 1.1, backgroundColor: 'rgba(14, 165, 233, 0.2)' }}
                        whileTap={{ scale: 0.95 }}
                      >
                        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                          <path d="m9 18 6-6-6-6" />
                        </svg>
                      </motion.button>
                    </div>
                  </motion.div>
                </div>
                
                {/* Scroll indicator */}
                <motion.div 
                  className="absolute bottom-8 left-1/2 transform -translate-x-1/2"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1, y: [0, 10, 0] }}
                  transition={{ 
                    opacity: { duration: 0.5, delay: 1.5 },
                    y: { repeat: Infinity, duration: 1.5, ease: "easeInOut" }
                  }}
                >
                  <div className="flex flex-col items-center">
                    <span className="text-[#94A3B8] text-sm mb-2">Scroll for testimonials</span>
                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-[#0EA5E9]">
                      <path d="M12 5v14"/>
                      <path d="m19 12-7 7-7-7"/>
                    </svg>
                  </div>
                </motion.div>
              </div>
            </div>
          </section>
          
          {/* Testimonials Section - Snap section */}
          <section className="min-h-screen w-full flex items-center justify-center snap-start relative py-16">
            <div className="absolute inset-0 bg-gradient-to-b from-[#030014] to-[#0A0A1B]/70 -z-10" />
            
            <div className="container mx-auto px-6">
              <div className="max-w-5xl mx-auto">
                <motion.div
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true, margin: "-100px" }}
                  transition={{ duration: 0.7 }}
                  className="mb-16 text-center"
                >
                  <h2 className="text-4xl md:text-5xl font-bold mb-6">
                    What <GradientText>Clients Say</GradientText>
                  </h2>
                  <p className="text-[#94A3B8] max-w-3xl mx-auto">
                    Hear directly from our clients about their experience with NeuraFlow
                    and the transformative results they've achieved.
                  </p>
                </motion.div>
                
                {/* Testimonial carousel */}
                <div className="relative mb-16">
                  <div className="max-w-3xl mx-auto">
                    <AnimatePresence mode="wait">
                      <motion.div
                        key={`testimonial-${activeTestimonial}`}
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: -20 }}
                        transition={{ duration: 0.5 }}
                        className="glass-morphism p-8 rounded-2xl border border-[#0EA5E9]/20 text-center"
                      >
                        <div className="mb-6 flex justify-center">
                          <div className="w-20 h-20 rounded-full bg-gradient-to-r from-[#0EA5E9]/20 to-[#4F46E5]/20 flex items-center justify-center text-[#0EA5E9]">
                            <svg width="40" height="40" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
                              <path d="M10.667 13.333H6.66699C6.66699 8.66667 10.667 5.33333 14.667 5.33333V9.33333C12.0003 9.33333 10.667 11.3333 10.667 13.333ZM22.667 13.333H18.667C18.667 8.66667 22.667 5.33333 26.667 5.33333V9.33333C24.0003 9.33333 22.667 11.3333 22.667 13.333Z" fill="currentColor"/>
                            </svg>
                          </div>
                        </div>
                        
                        <p className="text-white text-xl md:text-2xl mb-8 italic font-light">
                          "{testimonials[activeTestimonial].quote}"
                        </p>
                        
                        <div className="flex flex-col items-center">
                          <p className="font-semibold text-white text-lg">{testimonials[activeTestimonial].author}</p>
                          <p className="text-[#94A3B8]">{testimonials[activeTestimonial].position}</p>
                        </div>
                      </motion.div>
                    </AnimatePresence>
                    
                    {/* Testimonial indicators */}
                    <div className="flex justify-center mt-8 space-x-2">
                      {testimonials.map((_, index) => (
                        <button
                          key={index}
                          className={`w-2 h-2 rounded-full transition-all duration-300 ${
                            activeTestimonial === index 
                              ? 'w-8 bg-[#0EA5E9]' 
                              : 'bg-[#1E1E3F] hover:bg-[#0EA5E9]/50'
                          }`}
                          onClick={() => setActiveTestimonial(index)}
                        />
                      ))}
                    </div>
                  </div>
                  
                  {/* Client logos */}
                  <motion.div
                    className="mt-16"
                    initial={{ opacity: 0, y: 30 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true, margin: "-100px" }}
                    transition={{ duration: 0.7, delay: 0.3 }}
                  >
                    <p className="text-center text-[#94A3B8] mb-8">Trusted by innovative companies worldwide</p>
                    
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
                      {[...Array(4)].map((_, index) => (
                        <div key={index} className="flex items-center justify-center">
                          <div className="h-16 w-40 bg-[#0A0A1B]/70 border border-[#1E1E3F] rounded-md flex items-center justify-center">
                            <div className="text-center text-[#94A3B8] opacity-70">
                              <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                                <rect width="18" height="18" x="3" y="3" rx="2" />
                                <path d="M9 17V7l7 5-7 5Z" />
                              </svg>
                              <div className="mt-1 text-xs">Client Logo {index + 1}</div>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </motion.div>
                </div>
                
                {/* CTA Section */}
                <motion.div
                  className="max-w-3xl mx-auto text-center"
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true, margin: "-100px" }}
                  transition={{ duration: 0.7, delay: 0.5 }}
                >
                  <h2 className="text-3xl md:text-4xl font-bold mb-6">
                    Ready to achieve similar <GradientText>results</GradientText>?
                  </h2>
                  
                  <p className="text-[#94A3B8] text-lg mb-10">
                    Join industry leaders who trust NeuraFlow for their AI initiatives.
                  </p>
                  
                  <NeonButton size="lg" glowing>
                    <span className="flex items-center">
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                        <path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"></path>
                        <circle cx="9" cy="7" r="4"></circle>
                        <line x1="19" y1="8" x2="19" y2="14"></line>
                        <line x1="22" y1="11" x2="16" y2="11"></line>
                      </svg>
                      Start Your Journey
                    </span>
                  </NeonButton>
                </motion.div>
              </div>
            </div>
            
            {/* Decorative elements */}
            <div className="absolute top-20 -right-40 w-96 h-96 rounded-full bg-[#0EA5E9]/5 blur-3xl animate-float" />
            <div className="absolute bottom-10 -left-20 w-80 h-80 rounded-full bg-[#4F46E5]/5 blur-3xl animate-float-complex" />
            
            {/* Swipe indicator */}
            <div className="absolute bottom-4 right-6 text-[#94A3B8] text-xs flex items-center">
              <div className="animate-swipe-hint mr-2">
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="m9 18 6-6-6-6"></path>
                </svg>
              </div>
              Swipe for contact
            </div>
          </section>
        </div>
      </div>
    </PageTransition>
  );
}