import { Link } from "wouter";
import { motion } from "framer-motion";
import { NeonButton } from "../components/ui/neon-button";
import { GradientText } from "../components/ui/gradient-text";
import ParticleBackground from "../components/ParticleBackground";

export default function NotFound() {
  return (
    <div className="min-h-screen w-full flex items-center justify-center bg-[#030014] text-white">
      <ParticleBackground color="#0EA5E9" density={30} />
      
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.7 }}
        className="text-center p-6 max-w-md relative z-10"
      >
        <h1 className="text-8xl font-bold mb-4">
          <GradientText>404</GradientText>
        </h1>
        
        <h2 className="text-3xl font-semibold mb-6">Page Not Found</h2>
        
        <p className="text-[#94A3B8] mb-10">
          The page you're looking for doesn't exist or has been moved to another location.
        </p>
        
        <Link href="/">
          <NeonButton>
            Return Home
          </NeonButton>
        </Link>
        
        {/* Decorative element */}
        <div className="absolute -z-10 top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-96 h-96 rounded-full bg-[#4F46E5]/10 blur-3xl"></div>
      </motion.div>
    </div>
  );
}
