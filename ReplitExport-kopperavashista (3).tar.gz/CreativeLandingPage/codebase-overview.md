
# Project Codebase Overview

## Server-side Files
- `server/index.ts`: Main Express server setup with logging middleware
- `server/routes.ts`: Route registration and HTTP server setup
- `server/storage.ts`: Storage interface implementation
- `server/vite.ts`: Vite configuration for server

## Client-side Files
- `client/src/App.tsx`: Main React application with page routing and animations
- `client/src/lib/gsap.ts`: GSAP animations configuration
- `client/src/lib/queryClient.ts`: React Query client setup
- `client/src/components/ui/sheet.tsx`: UI component for slide-out panels
- `client/src/index.css`: CSS animations and styles

## Shared Files
- `shared/schema.ts`: Database schema definitions using Drizzle ORM

## Configuration Files
- `.gitignore`: Git ignore patterns
- `package.json`: Project dependencies and scripts
- `.replit`: Replit configuration for deployment and workflows

## Important Features
1. Express server with request logging
2. React frontend with animated page transitions
3. GSAP animations
4. Database schema with Drizzle ORM
5. UI components with Tailwind CSS
6. Development server running on port 5000

All source code is preserved in the repository and can be accessed through the file system.
