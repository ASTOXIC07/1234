import { users, type User, type InsertUser, rides, type Ride, type InsertRide, paymentMethods, type PaymentMethod, type InsertPaymentMethod } from "@shared/schema";
import session from "express-session";
import createMemoryStore from "memorystore";

const MemoryStore = createMemoryStore(session);

export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  getRides(userId: number): Promise<Ride[]>;
  getRide(id: number): Promise<Ride | undefined>;
  createRide(ride: InsertRide): Promise<Ride>;
  updateRideStatus(id: number, status: string): Promise<Ride | undefined>;
  
  getPaymentMethods(userId: number): Promise<PaymentMethod[]>;
  getPaymentMethod(id: number): Promise<PaymentMethod | undefined>;
  createPaymentMethod(paymentMethod: InsertPaymentMethod): Promise<PaymentMethod>;
  updateDefaultPaymentMethod(userId: number, id: number): Promise<void>;
  
  sessionStore: session.SessionStore;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private rides: Map<number, Ride>;
  private paymentMethods: Map<number, PaymentMethod>;
  sessionStore: session.SessionStore;
  
  currentUserId: number;
  currentRideId: number;
  currentPaymentMethodId: number;

  constructor() {
    this.users = new Map();
    this.rides = new Map();
    this.paymentMethods = new Map();
    
    this.currentUserId = 1;
    this.currentRideId = 1;
    this.currentPaymentMethodId = 1;
    
    this.sessionStore = new MemoryStore({
      checkPeriod: 86400000, // 24 hours
    });
    
    // Create a default user for testing
    this.createUser({
      username: "demo",
      password: "password123",
      email: "demo@example.com",
      fullName: "Demo User"
    });
    
    // Create a default payment method for the user
    this.createPaymentMethod({
      userId: 1,
      type: "visa",
      lastFour: "4589",
      isDefault: true
    });
    
    // Create some ride history for the user
    this.createRide({
      userId: 1,
      source: "123 Main St, San Francisco",
      destination: "Golden Gate Park",
      rideService: "UberX",
      driver: "John D.",
      price: "$18.75",
      status: "completed"
    });
    
    this.createRide({
      userId: 1,
      source: "123 Main St, San Francisco",
      destination: "555 Market St",
      rideService: "Lyft",
      driver: "Alice S.",
      price: "$12.50",
      status: "completed"
    });
    
    this.createRide({
      userId: 1,
      source: "123 Main St, San Francisco",
      destination: "SFO Terminal 2",
      rideService: "UberXL",
      driver: "Mike T.",
      price: "$35.20",
      status: "completed"
    });
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }
  
  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.email === email,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const createdAt = new Date();
    const user: User = { ...insertUser, id, createdAt };
    this.users.set(id, user);
    return user;
  }
  
  async getRides(userId: number): Promise<Ride[]> {
    return Array.from(this.rides.values()).filter(
      (ride) => ride.userId === userId,
    );
  }
  
  async getRide(id: number): Promise<Ride | undefined> {
    return this.rides.get(id);
  }
  
  async createRide(insertRide: InsertRide): Promise<Ride> {
    const id = this.currentRideId++;
    const createdAt = new Date();
    const ride: Ride = { ...insertRide, id, createdAt };
    this.rides.set(id, ride);
    return ride;
  }
  
  async updateRideStatus(id: number, status: string): Promise<Ride | undefined> {
    const ride = this.rides.get(id);
    if (!ride) return undefined;
    
    const updatedRide = { ...ride, status };
    this.rides.set(id, updatedRide);
    return updatedRide;
  }
  
  async getPaymentMethods(userId: number): Promise<PaymentMethod[]> {
    return Array.from(this.paymentMethods.values()).filter(
      (paymentMethod) => paymentMethod.userId === userId,
    );
  }
  
  async getPaymentMethod(id: number): Promise<PaymentMethod | undefined> {
    return this.paymentMethods.get(id);
  }
  
  async createPaymentMethod(insertPaymentMethod: InsertPaymentMethod): Promise<PaymentMethod> {
    const id = this.currentPaymentMethodId++;
    const paymentMethod: PaymentMethod = { ...insertPaymentMethod, id };
    
    // If this is the default payment method, unset any other default
    if (paymentMethod.isDefault) {
      for (const [existingId, existingPaymentMethod] of this.paymentMethods) {
        if (existingPaymentMethod.userId === paymentMethod.userId && existingPaymentMethod.isDefault) {
          this.paymentMethods.set(existingId, { ...existingPaymentMethod, isDefault: false });
        }
      }
    }
    
    this.paymentMethods.set(id, paymentMethod);
    return paymentMethod;
  }
  
  async updateDefaultPaymentMethod(userId: number, id: number): Promise<void> {
    // Unset any current defaults
    for (const [existingId, existingPaymentMethod] of this.paymentMethods) {
      if (existingPaymentMethod.userId === userId && existingPaymentMethod.isDefault) {
        this.paymentMethods.set(existingId, { ...existingPaymentMethod, isDefault: false });
      }
    }
    
    // Set the new default
    const paymentMethod = this.paymentMethods.get(id);
    if (paymentMethod && paymentMethod.userId === userId) {
      this.paymentMethods.set(id, { ...paymentMethod, isDefault: true });
    }
  }
}

export const storage = new MemStorage();
