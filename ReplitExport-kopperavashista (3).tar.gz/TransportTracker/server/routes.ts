import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth } from "./auth";
import { z } from "zod";
import { insertRideSchema, insertPaymentMethodSchema } from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // Setup authentication
  setupAuth(app);
  
  // Check authentication for API routes
  const requireAuth = (req: any, res: any, next: any) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Unauthorized" });
    }
    next();
  };
  
  // Ride routes
  app.get("/api/rides", requireAuth, async (req, res) => {
    const rides = await storage.getRides(req.user!.id);
    res.json(rides);
  });
  
  app.get("/api/rides/:id", requireAuth, async (req, res) => {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ message: "Invalid ride ID" });
    }
    
    const ride = await storage.getRide(id);
    if (!ride || ride.userId !== req.user!.id) {
      return res.status(404).json({ message: "Ride not found" });
    }
    
    res.json(ride);
  });
  
  app.post("/api/rides", requireAuth, async (req, res) => {
    try {
      const rideData = insertRideSchema.parse({
        ...req.body,
        userId: req.user!.id
      });
      
      const ride = await storage.createRide(rideData);
      res.status(201).json(ride);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid ride data", errors: error.errors });
      }
      res.status(500).json({ message: "Internal server error" });
    }
  });
  
  app.patch("/api/rides/:id/status", requireAuth, async (req, res) => {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ message: "Invalid ride ID" });
    }
    
    const { status } = req.body;
    if (!status || typeof status !== "string") {
      return res.status(400).json({ message: "Status is required" });
    }
    
    const ride = await storage.getRide(id);
    if (!ride || ride.userId !== req.user!.id) {
      return res.status(404).json({ message: "Ride not found" });
    }
    
    const updatedRide = await storage.updateRideStatus(id, status);
    res.json(updatedRide);
  });
  
  // Payment method routes
  app.get("/api/payment-methods", requireAuth, async (req, res) => {
    const paymentMethods = await storage.getPaymentMethods(req.user!.id);
    res.json(paymentMethods);
  });
  
  app.post("/api/payment-methods", requireAuth, async (req, res) => {
    try {
      const paymentMethodData = insertPaymentMethodSchema.parse({
        ...req.body,
        userId: req.user!.id
      });
      
      const paymentMethod = await storage.createPaymentMethod(paymentMethodData);
      res.status(201).json(paymentMethod);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid payment method data", errors: error.errors });
      }
      res.status(500).json({ message: "Internal server error" });
    }
  });
  
  app.patch("/api/payment-methods/:id/default", requireAuth, async (req, res) => {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ message: "Invalid payment method ID" });
    }
    
    const paymentMethod = await storage.getPaymentMethod(id);
    if (!paymentMethod || paymentMethod.userId !== req.user!.id) {
      return res.status(404).json({ message: "Payment method not found" });
    }
    
    await storage.updateDefaultPaymentMethod(req.user!.id, id);
    const updatedPaymentMethods = await storage.getPaymentMethods(req.user!.id);
    res.json(updatedPaymentMethods);
  });
  
  // Mock API for available ride services
  app.post("/api/search-rides", requireAuth, (req, res) => {
    const { source, destination } = req.body;
    
    if (!source || !destination) {
      return res.status(400).json({ message: "Source and destination are required" });
    }
    
    // Return mock ride service options
    const rideServices = [
      {
        id: "uber-x",
        name: "UberX",
        logoColor: "bg-blue-100",
        logoIcon: "fa-car",
        eta: 4,
        price: 18.75,
        duration: 12,
        seatsAvailable: 4,
        features: ["10% off with code RIDE10"]
      },
      {
        id: "lyft",
        name: "Lyft",
        logoColor: "bg-green-100",
        logoIcon: "fa-car-side",
        eta: 2,
        price: 20.50,
        duration: 10,
        seatsAvailable: 3,
        features: ["Top rated driver"]
      },
      {
        id: "yellow-cab",
        name: "Yellow Cab",
        logoColor: "bg-yellow-100",
        logoIcon: "fa-taxi",
        eta: 8,
        price: 15.25,
        duration: 15,
        seatsAvailable: 4,
        features: ["Cash payment available"]
      }
    ];
    
    // Simulate server processing time
    setTimeout(() => {
      res.json(rideServices);
    }, 500);
  });

  const httpServer = createServer(app);
  
  return httpServer;
}
