import * as tf from '@tensorflow/tfjs';
import { formatDistance, addMinutes, subMinutes, format } from 'date-fns';

// Types for AI service
export interface TripPrediction {
  estimatedTime: number;
  confidence: number;
  trafficLevel: 'Low' | 'Moderate' | 'High' | 'Very High';
  recommendation: string;
  alternateRoutes?: AlternateRoute[];
  priceEstimate: {
    minPrice: number;
    maxPrice: number;
    surgeMultiplier?: number;
  };
}

export interface AlternateRoute {
  id: string;
  estimatedTime: number;
  trafficLevel: 'Low' | 'Moderate' | 'High' | 'Very High';
  distance: number;
  description: string;
}

/**
 * AI-powered service for time analysis and ride recommendations
 */
export class AIService {
  private model: tf.LayersModel | null = null;
  private readonly timeFactors = [0.8, 1.0, 1.3, 1.8]; // Multipliers for different traffic conditions
  private readonly DEFAULT_AVG_SPEED = 25; // mph
  private isModelLoaded = false;

  constructor() {
    this.loadModel();
  }

  /**
   * Load the TensorFlow.js model for predictions
   */
  private async loadModel(): Promise<void> {
    try {
      // We're using a simple model for demo purposes
      // In production, you would load a real trained model
      const model = tf.sequential();
      
      model.add(tf.layers.dense({
        inputShape: [4], 
        units: 8, 
        activation: 'relu'
      }));
      
      model.add(tf.layers.dense({
        units: 4, 
        activation: 'relu'
      }));
      
      model.add(tf.layers.dense({
        units: 1, 
        activation: 'linear'
      }));
      
      model.compile({
        optimizer: 'adam',
        loss: 'meanSquaredError'
      });

      this.model = model;
      this.isModelLoaded = true;
      console.log('AI prediction model loaded');
    } catch (error) {
      console.error('Failed to load AI model:', error);
    }
  }

  /**
   * Predict trip details based on source, destination, time, and weather
   */
  async predictTrip(
    sourceLocation: { lat: number; lng: number },
    destinationLocation: { lat: number; lng: number },
    departureTime: Date,
    options?: {
      weather?: 'clear' | 'rain' | 'snow';
      historyFactor?: number;
    }
  ): Promise<TripPrediction> {
    // Wait for model to be loaded
    if (!this.isModelLoaded) {
      await new Promise(resolve => {
        const checkInterval = setInterval(() => {
          if (this.isModelLoaded) {
            clearInterval(checkInterval);
            resolve(true);
          }
        }, 200);
      });
    }

    // Calculate distance in km using Haversine formula
    const distance = this.calculateDistance(
      sourceLocation.lat, 
      sourceLocation.lng,
      destinationLocation.lat,
      destinationLocation.lng
    );

    // Get current hour (0-23)
    const hour = departureTime.getHours();
    
    // Determine if it's rush hour (7-9 AM or 4-7 PM)
    const isRushHour = (hour >= 7 && hour <= 9) || (hour >= 16 && hour <= 19);
    
    // Determine if it's weekend
    const isWeekend = departureTime.getDay() === 0 || departureTime.getDay() === 6;
    
    // Weather factor: clear = 1, rain = 1.3, snow = 1.8
    const weatherFactor = options?.weather === 'rain' ? 1.3 : options?.weather === 'snow' ? 1.8 : 1;
    
    // Calculate basic time estimate (distance / average speed)
    // Average speed varies by traffic conditions
    const avgSpeedAdjustment = isRushHour && !isWeekend ? 0.7 : isWeekend ? 1.2 : 1;
    const adjustedSpeed = this.DEFAULT_AVG_SPEED * avgSpeedAdjustment;
    
    // Convert km to miles for calculation
    const distanceMiles = distance * 0.621371;
    
    // Base time estimate in minutes
    let timeEstimate = (distanceMiles / adjustedSpeed) * 60;
    
    // Apply weather factor
    timeEstimate *= weatherFactor;
    
    // Apply user history factor if available
    if (options?.historyFactor) {
      timeEstimate *= options.historyFactor;
    }
    
    // Determine traffic level based on various factors
    let trafficIndex = 0;
    if (isRushHour && !isWeekend) trafficIndex += 2;
    if (isWeekend) trafficIndex -= 1;
    if (options?.weather === 'rain') trafficIndex += 1;
    if (options?.weather === 'snow') trafficIndex += 2;
    
    // Clamp traffic index to 0-3
    trafficIndex = Math.max(0, Math.min(3, trafficIndex));
    
    const trafficLevels: ['Low', 'Moderate', 'High', 'Very High'] = ['Low', 'Moderate', 'High', 'Very High'];
    const trafficLevel = trafficLevels[trafficIndex];
    
    // Apply AI model if available for refined prediction
    if (this.model) {
      try {
        // Prepare input tensor: [distance, hour, isWeekend, trafficIndex]
        const input = tf.tensor2d([[
          distance, 
          hour, 
          isWeekend ? 1 : 0, 
          trafficIndex
        ]]);
        
        // Get prediction
        const prediction = this.model.predict(input) as tf.Tensor;
        const predictedValue = (await prediction.data())[0];
        
        // Blend model prediction with rule-based prediction (70% AI, 30% rule-based)
        timeEstimate = 0.3 * timeEstimate + 0.7 * predictedValue;
        
        // Clean up tensors
        input.dispose();
        prediction.dispose();
      } catch (error) {
        console.warn('AI prediction failed, using rule-based fallback:', error);
      }
    }
    
    // Generate alternate routes
    const alternateRoutes = this.generateAlternateRoutes(
      distance, 
      timeEstimate, 
      trafficLevel as TripPrediction['trafficLevel']
    );
    
    // Generate price estimate
    const basePrice = 5 + (distanceMiles * 2.5) + (timeEstimate / 4);
    const surgeMultiplier = isRushHour && !isWeekend ? 1.5 : 1.0;
    
    // Format estimated arrival time
    const arrivalTime = addMinutes(departureTime, Math.round(timeEstimate));
    const arrivalTimeFormatted = format(arrivalTime, 'h:mm a');
    
    // Generate recommendation
    let recommendation = `Based on current traffic conditions, we recommend departing now to arrive by ${arrivalTimeFormatted}.`;
    
    if (trafficIndex >= 2) {
      const betterTime = this.suggestBetterTime(departureTime, isRushHour, isWeekend);
      recommendation = `Traffic is heavy. Consider leaving at ${betterTime} for a smoother ride or take an alternate route.`;
    }
    
    return {
      estimatedTime: Math.round(timeEstimate),
      confidence: this.calculateConfidence(trafficIndex),
      trafficLevel: trafficLevel as TripPrediction['trafficLevel'],
      recommendation,
      alternateRoutes,
      priceEstimate: {
        minPrice: Math.round((basePrice * 0.9) * 100) / 100,
        maxPrice: Math.round((basePrice * surgeMultiplier) * 100) / 100,
        surgeMultiplier: surgeMultiplier > 1 ? surgeMultiplier : undefined
      }
    };
  }

  /**
   * Generate alternate routes with different characteristics
   */
  private generateAlternateRoutes(
    distance: number, 
    baseTime: number, 
    baseTrafficLevel: TripPrediction['trafficLevel']
  ): AlternateRoute[] {
    const trafficLevels: TripPrediction['trafficLevel'][] = ['Low', 'Moderate', 'High', 'Very High'];
    const baseTrafficIndex = trafficLevels.indexOf(baseTrafficLevel);
    
    return [
      {
        id: 'highway',
        estimatedTime: Math.round(baseTime * 0.8),
        trafficLevel: trafficLevels[Math.max(0, baseTrafficIndex - 1)] as TripPrediction['trafficLevel'],
        distance: Math.round(distance * 1.2 * 10) / 10,
        description: 'Highway route with faster speeds but slightly longer distance'
      },
      {
        id: 'scenic',
        estimatedTime: Math.round(baseTime * 1.2),
        trafficLevel: trafficLevels[Math.max(0, baseTrafficIndex - 2)] as TripPrediction['trafficLevel'],
        distance: Math.round(distance * 1.1 * 10) / 10,
        description: 'Scenic route with less traffic but longer travel time'
      },
      {
        id: 'direct',
        estimatedTime: Math.round(baseTime * 0.9),
        trafficLevel: trafficLevels[Math.min(3, baseTrafficIndex + 1)] as TripPrediction['trafficLevel'],
        distance: Math.round(distance * 0.9 * 10) / 10,
        description: 'Direct route through city streets'
      }
    ];
  }

  /**
   * Calculate distance between two points using Haversine formula
   */
  private calculateDistance(lat1: number, lon1: number, lat2: number, lon2: number): number {
    const R = 6371; // Radius of the earth in km
    const dLat = this.deg2rad(lat2 - lat1);
    const dLon = this.deg2rad(lon2 - lon1);
    const a =
      Math.sin(dLat / 2) * Math.sin(dLat / 2) +
      Math.cos(this.deg2rad(lat1)) * Math.cos(this.deg2rad(lat2)) *
      Math.sin(dLon / 2) * Math.sin(dLon / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    return R * c; // Distance in km
  }

  private deg2rad(deg: number): number {
    return deg * (Math.PI / 180);
  }

  /**
   * Calculate confidence score for prediction (0-100)
   */
  private calculateConfidence(trafficIndex: number): number {
    // Confidence decreases with higher traffic unpredictability
    return Math.round(95 - (trafficIndex * 10));
  }

  /**
   * Suggest a better departure time to avoid traffic
   */
  private suggestBetterTime(
    currentTime: Date, 
    isRushHour: boolean, 
    isWeekend: boolean
  ): string {
    let betterTime: Date;
    
    if (isRushHour && !isWeekend) {
      // If morning rush hour, suggest later
      const hour = currentTime.getHours();
      if (hour >= 7 && hour <= 9) {
        betterTime = addMinutes(currentTime, 90);
      } else {
        // If evening rush hour, suggest earlier or later
        betterTime = hour < 17.5 ? subMinutes(currentTime, 60) : addMinutes(currentTime, 90);
      }
    } else {
      // If not rush hour, suggest minor adjustment
      betterTime = addMinutes(currentTime, 15);
    }
    
    return format(betterTime, 'h:mm a');
  }
}

// Singleton instance for the application
export const aiService = new AIService();

/**
 * Hook for accessing the AI service
 */
export function useAIService() {
  return aiService;
}