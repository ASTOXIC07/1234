import { useState, useEffect, useRef } from 'react';
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { motion, AnimatePresence } from 'framer-motion';
import { Map, Loader2 } from 'lucide-react';

interface LocationInputProps {
  id: string;
  label: string;
  placeholder: string;
  defaultValue?: string;
  icon: 'pickup' | 'destination';
  onChange?: (value: string) => void;
}

// Provide a list of sample locations for autocomplete
// In a real app, this would come from an API like OpenStreetMap's Nominatim
const getSampleLocations = (input: string) => {
  if (!input || input.length < 2) return [];
  
  // Popular places in San Francisco
  const popularPlaces = [
    { id: 101, name: 'Golden Gate Park', full: 'Golden Gate Park, San Francisco, CA' },
    { id: 102, name: 'Union Square', full: 'Union Square, San Francisco, CA' },
    { id: 103, name: 'Fisherman\'s Wharf', full: 'Fisherman\'s Wharf, San Francisco, CA' },
    { id: 104, name: 'North Beach', full: 'North Beach, San Francisco, CA' },
    { id: 105, name: 'Mission District', full: 'Mission District, San Francisco, CA' },
    { id: 106, name: 'Chinatown', full: 'Chinatown, San Francisco, CA' },
    { id: 107, name: 'Lombard Street', full: 'Lombard Street, San Francisco, CA' },
    { id: 108, name: 'Embarcadero', full: 'Embarcadero, San Francisco, CA' },
    { id: 109, name: 'AT&T Park', full: 'AT&T Park, San Francisco, CA' },
    { id: 110, name: 'Presidio', full: 'Presidio, San Francisco, CA' },
    { id: 111, name: 'Haight-Ashbury', full: 'Haight-Ashbury, San Francisco, CA' },
    { id: 112, name: 'Alcatraz Island', full: 'Alcatraz Island, San Francisco, CA' },
    { id: 113, name: 'Coit Tower', full: 'Coit Tower, San Francisco, CA' },
    { id: 114, name: 'Twin Peaks', full: 'Twin Peaks, San Francisco, CA' },
    { id: 115, name: 'Marina District', full: 'Marina District, San Francisco, CA' },
  ];
  
  // Nearby cities
  const nearbyCities = [
    { id: 201, name: 'Palo Alto', full: 'Palo Alto, CA' },
    { id: 202, name: 'Mountain View', full: 'Mountain View, CA' },
    { id: 203, name: 'Berkeley', full: 'Berkeley, CA' },
    { id: 204, name: 'Oakland', full: 'Oakland, CA' },
    { id: 205, name: 'San Jose', full: 'San Jose, CA' },
    { id: 206, name: 'Sausalito', full: 'Sausalito, CA' },
    { id: 207, name: 'Fremont', full: 'Fremont, CA' },
  ];
  
  // Filter locations based on input
  const inputLower = input.toLowerCase();
  const matchedPopular = popularPlaces.filter(place => 
    place.name.toLowerCase().includes(inputLower)
  );
  
  const matchedCities = nearbyCities.filter(place => 
    place.name.toLowerCase().includes(inputLower)
  );
  
  // Street names for when the input doesn't match popular places
  const streetOptions = ['Street', 'Avenue', 'Boulevard', 'Road', 'Drive', 'Plaza', 'Court', 'Lane'];
  const cityOptions = ['San Francisco', 'Oakland', 'Palo Alto', 'Berkeley'];
  
  // If we have matches, return them, otherwise generate streets
  if (matchedPopular.length > 0 || matchedCities.length > 0) {
    return [...matchedPopular, ...matchedCities];
  }
  
  // Generate street suggestions
  const generatedSuggestions = [];
  for (let i = 0; i < Math.min(5, streetOptions.length); i++) {
    const streetType = streetOptions[i];
    const city = cityOptions[i % cityOptions.length];
    generatedSuggestions.push({
      id: 300 + i,
      name: `${input} ${streetType}`,
      full: `${input} ${streetType}, ${city}, CA`
    });
  }
  
  return generatedSuggestions;
};

const LocationInput: React.FC<LocationInputProps> = ({
  id,
  label,
  placeholder,
  defaultValue = '',
  icon,
  onChange
}) => {
  const [value, setValue] = useState(defaultValue);
  const [suggestions, setSuggestions] = useState<Array<{id: number, name: string, full: string}>>([]);
  const [isFocused, setIsFocused] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);
  const suggestionsRef = useRef<HTMLDivElement>(null);
  
  // Handle outside clicks to close suggestions
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (suggestionsRef.current && !suggestionsRef.current.contains(event.target as Node) && 
          inputRef.current && !inputRef.current.contains(event.target as Node)) {
        setIsFocused(false);
      }
    };
    
    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);
  
  // Fetch location suggestions
  useEffect(() => {
    if (value.trim().length >= 2) {
      setIsLoading(true);
      
      // Simulate API call delay
      const timer = setTimeout(() => {
        const locations = getSampleLocations(value);
        setSuggestions(locations);
        setIsLoading(false);
      }, 300);
      
      return () => clearTimeout(timer);
    } else {
      setSuggestions([]);
    }
  }, [value]);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newValue = e.target.value;
    setValue(newValue);
    if (newValue.trim().length >= 2) {
      setIsFocused(true);
    }
    onChange && onChange(newValue);
  };
  
  const handleSuggestionClick = (suggestion: {id: number, name: string, full: string}) => {
    setValue(suggestion.full);
    setIsFocused(false);
    setSuggestions([]);
    
    // Immediately trigger the onChange to update coordinates on the map
    if (onChange) {
      // Short timeout to ensure UI update completes first
      setTimeout(() => {
        onChange(suggestion.full);
      }, 10);
    }
  };

  const iconColor = icon === 'pickup' ? 'bg-primary' : 'bg-accent';

  return (
    <div className="flex items-start mb-3 relative">
      <div className="mt-2 mr-2">
        <motion.div 
          className={`h-5 w-5 rounded-full ${iconColor} flex items-center justify-center`}
          initial={{ scale: 0.8, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ duration: 0.2 }}
        >
          <div className="h-2 w-2 rounded-full bg-white"></div>
        </motion.div>
      </div>
      <div className="flex-1">
        <Label htmlFor={id} className="block text-xs text-gray-500">{label}</Label>
        <Input
          ref={inputRef}
          type="text"
          id={id}
          placeholder={placeholder}
          value={value}
          onChange={handleInputChange}
          onFocus={() => value.trim().length >= 2 && setIsFocused(true)}
          className="w-full border-0 focus:ring-0 p-0 text-gray-900 placeholder-gray-400"
        />
        
        {/* Location suggestions dropdown */}
        <AnimatePresence>
          {isFocused && (suggestions.length > 0 || isLoading) && (
            <motion.div
              ref={suggestionsRef}
              className="absolute z-50 mt-1 w-full bg-white rounded-md shadow-lg overflow-hidden"
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.2 }}
            >
              {isLoading ? (
                <div className="p-3 flex items-center justify-center text-gray-500">
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  Finding locations...
                </div>
              ) : (
                <div className="max-h-60 overflow-y-auto">
                  {suggestions.map((suggestion) => (
                    <div
                      key={suggestion.id}
                      className="px-4 py-2 hover:bg-gray-100 cursor-pointer flex items-center"
                      onClick={() => handleSuggestionClick(suggestion)}
                    >
                      <Map className="h-4 w-4 mr-2 text-gray-500 flex-shrink-0" />
                      <div>
                        <div className="font-medium">{suggestion.name}</div>
                        <div className="text-xs text-gray-500">{suggestion.full}</div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
};

export default LocationInput;
