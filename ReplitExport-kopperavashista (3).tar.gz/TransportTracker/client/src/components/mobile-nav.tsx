import { Home, Clock, QrCode, Gift, User } from "lucide-react";
import { motion } from "framer-motion";
import { useLocation } from "wouter";

const MobileNav = () => {
  const [location, navigate] = useLocation();

  const isActive = (path: string) => location === path;

  return (
    <motion.nav 
      className="fixed bottom-0 w-full bg-white border-t border-gray-200 md:hidden z-10"
      initial={{ y: 100 }}
      animate={{ y: 0 }}
      transition={{ duration: 0.3 }}
    >
      <div className="flex justify-around">
        <button 
          className={`flex flex-col items-center py-3 px-4 ${isActive('/') ? 'text-primary' : 'text-gray-500'}`}
          onClick={() => navigate('/')}
        >
          <Home size={20} />
          <span className="text-xs mt-1">Home</span>
        </button>
        
        <button 
          className={`flex flex-col items-center py-3 px-4 ${isActive('/history') ? 'text-primary' : 'text-gray-500'}`}
          onClick={() => navigate('/history')}
        >
          <Clock size={20} />
          <span className="text-xs mt-1">History</span>
        </button>
        
        <button 
          className="flex flex-col items-center py-3 px-4"
          onClick={() => {
            // Could be used for QR code scanning feature
          }}
        >
          <div className="h-12 w-12 rounded-full bg-primary -mt-6 flex items-center justify-center text-white">
            <QrCode size={20} />
          </div>
        </button>
        
        <button 
          className="flex flex-col items-center py-3 px-4 text-gray-500"
        >
          <Gift size={20} />
          <span className="text-xs mt-1">Rewards</span>
        </button>
        
        <button 
          className={`flex flex-col items-center py-3 px-4 ${isActive('/profile') ? 'text-primary' : 'text-gray-500'}`}
          onClick={() => navigate('/profile')}
        >
          <User size={20} />
          <span className="text-xs mt-1">Profile</span>
        </button>
      </div>
    </motion.nav>
  );
};

export default MobileNav;
