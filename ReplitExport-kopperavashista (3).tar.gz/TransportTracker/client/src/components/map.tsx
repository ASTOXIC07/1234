import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { MapContainer, TileLayer, Marker, Popup, Polyline, useMap, LayersControl, ZoomControl } from 'react-leaflet';
import 'leaflet/dist/leaflet.css';
import L from 'leaflet';
import { Button } from '@/components/ui/button';
import { ArrowLeft, Layers } from 'lucide-react';

// Fix Leaflet marker icon issue
delete (L.Icon.Default.prototype as any)._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://unpkg.com/leaflet@1.7.1/dist/images/marker-icon-2x.png',
  iconUrl: 'https://unpkg.com/leaflet@1.7.1/dist/images/marker-icon.png',
  shadowUrl: 'https://unpkg.com/leaflet@1.7.1/dist/images/marker-shadow.png',
});

// Custom styled marker icons for pickup and destination
const pickupIcon = new L.Icon({
  iconUrl: 'https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-2x-green.png',
  shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/0.7.7/images/marker-shadow.png',
  iconSize: [25, 41],
  iconAnchor: [12, 41],
  popupAnchor: [1, -34],
  shadowSize: [41, 41]
});

const destinationIcon = new L.Icon({
  iconUrl: 'https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-2x-red.png',
  shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/0.7.7/images/marker-shadow.png',
  iconSize: [25, 41],
  iconAnchor: [12, 41],
  popupAnchor: [1, -34],
  shadowSize: [41, 41]
});

// Helper function to simulate traffic data on the map
function createTrafficOverlay(map: L.Map, start: [number, number], end: [number, number]): void {
  // Create traffic intensity gradient
  const trafficGradient = {
    'low': '#4CAF50',    // Green
    'medium': '#FFC107', // Yellow/Amber
    'high': '#FF5722',   // Orange/Deep Orange
    'severe': '#F44336'  // Red
  };
  
  // Create random traffic hotspots
  const trafficPoints = 4;
  const baseLat = Math.min(start[0], end[0]);
  const baseLng = Math.min(start[1], end[1]);
  const latRange = Math.abs(end[0] - start[0]);
  const lngRange = Math.abs(end[1] - start[1]);
  
  for (let i = 0; i < trafficPoints; i++) {
    // Create random position within the map area
    const lat = baseLat + Math.random() * latRange;
    const lng = baseLng + Math.random() * lngRange;
    
    // Random traffic intensity
    const trafficLevels = Object.keys(trafficGradient);
    const intensity = trafficLevels[Math.floor(Math.random() * trafficLevels.length)];
    const color = trafficGradient[intensity as keyof typeof trafficGradient];
    
    // Create traffic circle
    const radius = 200 + Math.random() * 400; // Radius in meters
    const circle = L.circle([lat, lng], {
      color: color,
      fillColor: color,
      fillOpacity: 0.3,
      radius: radius
    }).addTo(map);
    
    // Add popup with traffic info
    circle.bindPopup(`
      <div style="text-align: center;">
        <strong>Traffic Level: ${intensity.charAt(0).toUpperCase() + intensity.slice(1)}</strong>
        <div>~${Math.round(radius/100)} min delay</div>
      </div>
    `);
  }
}

// Free map tile providers
const mapTiles = {
  standard: {
    url: 'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',
    attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
    name: 'Standard'
  },
  cartoLight: {
    url: 'https://{s}.basemaps.cartocdn.com/light_all/{z}/{x}/{y}{r}.png',
    attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors, &copy; <a href="https://carto.com/attributions">CARTO</a>',
    name: 'Carto Light'
  },
  cartoDark: {
    url: 'https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png',
    attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors, &copy; <a href="https://carto.com/attributions">CARTO</a>',
    name: 'Carto Dark'
  },
  stamenTerrain: {
    url: 'https://stamen-tiles-{s}.a.ssl.fastly.net/terrain/{z}/{x}/{y}{r}.png',
    attribution: 'Map tiles by <a href="http://stamen.com">Stamen Design</a>, <a href="http://creativecommons.org/licenses/by/3.0">CC BY 3.0</a> &mdash; Map data &copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
    name: 'Terrain'
  },
  jawg: {
    url: 'https://{s}.tile.jawg.io/jawg-matrix/{z}/{x}/{y}{r}.png?access-token=community',
    attribution: '<a href="http://jawg.io" title="Tiles Courtesy of Jawg Maps" target="_blank">&copy; <b>Jawg</b>Maps</a> &copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
    name: 'Jawg Matrix'
  },
  voyager: {
    url: 'https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png',
    attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors &copy; <a href="https://carto.com/attributions">CARTO</a>',
    name: 'Voyager'
  },
  stamenWatercolor: {
    url: 'https://stamen-tiles-{s}.a.ssl.fastly.net/watercolor/{z}/{x}/{y}.png',
    attribution: 'Map tiles by <a href="http://stamen.com">Stamen Design</a>, <a href="http://creativecommons.org/licenses/by/3.0">CC BY 3.0</a> &mdash; Map data &copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
    name: 'Watercolor'
  }
};

// Auto-zoom component to fit markers in view
function SetBoundsToMarkers({ markers }: { markers: [number, number][] }) {
  const map = useMap();
  
  useEffect(() => {
    if (markers.length > 0) {
      const bounds = L.latLngBounds(markers.map(m => L.latLng(m[0], m[1])));
      map.fitBounds(bounds, { padding: [50, 50] });
    }
  }, [map, markers]);
  
  return null;
}

// Component to add traffic overlay to the map
function TrafficOverlay({ source, destination }: { source: [number, number], destination: [number, number] }) {
  const map = useMap();
  
  useEffect(() => {
    // Create traffic overlay after a short delay to ensure map is ready
    const timer = setTimeout(() => {
      createTrafficOverlay(map, source, destination);
    }, 800);
    
    return () => clearTimeout(timer);
  }, [map, source, destination]);
  
  return null;
}

// Helper to generate a curved/realistic path between two points
function generateRealisticRoutePath(
  start: [number, number], 
  end: [number, number], 
  variation: number = 0.1
): [number, number][] {
  // Direct distance and direction
  const dx = end[0] - start[0];
  const dy = end[1] - start[1];
  const distance = Math.sqrt(dx * dx + dy * dy);
  
  // Generate a midpoint with some perpendicular offset
  const midpoint: [number, number] = [
    start[0] + dx * 0.5, 
    start[1] + dy * 0.5
  ];
  
  // Create offset based on perpendicular direction and distance
  // Different offset directions create different curve paths
  const perpendicularOffsetX = -dy * distance * variation;
  const perpendicularOffsetY = dx * distance * variation;
  
  const offsetMidpoint: [number, number] = [
    midpoint[0] + perpendicularOffsetX,
    midpoint[1] + perpendicularOffsetY
  ];
  
  // Generate some additional intermediate points for a smoother curve
  const path: [number, number][] = [start];
  
  // Add a few intermediate points
  const steps = 8;
  for (let i = 1; i < steps; i++) {
    const t = i / steps;
    const t2 = t * t;
    const mt = 1 - t;
    const mt2 = mt * mt;
    
    // Quadratic Bezier curve formula
    const x = mt2 * start[0] + 2 * mt * t * offsetMidpoint[0] + t2 * end[0];
    const y = mt2 * start[1] + 2 * mt * t * offsetMidpoint[1] + t2 * end[1];
    
    path.push([x, y]);
  }
  
  path.push(end);
  return path;
}

interface MapProps {
  height?: string;
  fullScreen?: boolean;
  withBackButton?: boolean;
  onBackClick?: () => void;
  loadingText?: string;
  subText?: string;
  source?: { lat: number; lng: number; name?: string };
  destination?: { lat: number; lng: number; name?: string };
  routeVariation?: number; // Controls the curve of the route (0 = straight, higher = more curved)
}

const Map: React.FC<MapProps> = ({
  height = 'h-48 md:h-72 lg:h-96',
  fullScreen = false,
  withBackButton = false,
  onBackClick,
  loadingText = "Interactive Map",
  subText = "Loading map...",
  source = { lat: 37.7749, lng: -122.4194, name: 'Pickup Location' },
  destination = { lat: 37.7694, lng: -122.4862, name: 'Drop-off Location' },
  routeVariation = 0.1
}) => {
  const [isMapLoaded, setIsMapLoaded] = useState(false);
  const heightClass = fullScreen ? 'h-[60vh]' : height;

  // Generate realistic polyline path between source and destination
  const polylinePath = generateRealisticRoutePath(
    [source.lat, source.lng],
    [destination.lat, destination.lng],
    routeVariation
  );

  // List of markers for auto-zoom
  const markers: [number, number][] = [
    [source.lat, source.lng],
    [destination.lat, destination.lng]
  ];

  useEffect(() => {
    // Set map as loaded after a short delay
    const timer = setTimeout(() => setIsMapLoaded(true), 500);
    return () => clearTimeout(timer);
  }, []);

  return (
    <motion.div 
      className={`map-container relative w-full ${heightClass} bg-gray-200 overflow-hidden rounded-lg shadow-lg`}
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.5 }}
    >
      <div className="absolute inset-0 z-0">
        <MapContainer 
          style={{ height: '100%', width: '100%' }}
          zoom={13} 
          zoomControl={false}
          // @ts-ignore - center prop is valid but type definition is incorrect
          center={[source.lat, source.lng]}
        >
          {/* Layer control for map styles */}
          <LayersControl position="topright">
            {/* Default base layer */}
            <LayersControl.BaseLayer checked name={mapTiles.cartoLight.name}>
              <TileLayer
                attribution={mapTiles.cartoLight.attribution}
                url={mapTiles.cartoLight.url}
              />
            </LayersControl.BaseLayer>
            
            {/* Additional map styles */}
            <LayersControl.BaseLayer name={mapTiles.cartoDark.name}>
              <TileLayer
                attribution={mapTiles.cartoDark.attribution}
                url={mapTiles.cartoDark.url}
              />
            </LayersControl.BaseLayer>
            
            <LayersControl.BaseLayer name={mapTiles.standard.name}>
              <TileLayer
                attribution={mapTiles.standard.attribution}
                url={mapTiles.standard.url}
              />
            </LayersControl.BaseLayer>
            
            <LayersControl.BaseLayer name={mapTiles.stamenTerrain.name}>
              <TileLayer
                attribution={mapTiles.stamenTerrain.attribution}
                url={mapTiles.stamenTerrain.url}
              />
            </LayersControl.BaseLayer>
            
            <LayersControl.BaseLayer name={mapTiles.jawg.name}>
              <TileLayer
                attribution={mapTiles.jawg.attribution}
                url={mapTiles.jawg.url}
              />
            </LayersControl.BaseLayer>
          </LayersControl>
          
          {/* Add zoom control in a better position */}
          <ZoomControl position="bottomright" />
          
          {/* Pickup marker */}
          <Marker 
            // @ts-ignore - icon prop is valid but type definition is incorrect
            position={[source.lat, source.lng]} 
            icon={pickupIcon}
          >
            <Popup>
              <div className="font-medium">{source.name || 'Pickup Location'}</div>
            </Popup>
          </Marker>
          
          {/* Destination marker */}
          <Marker 
            // @ts-ignore - icon prop is valid but type definition is incorrect
            position={[destination.lat, destination.lng]} 
            icon={destinationIcon}
          >
            <Popup>
              <div className="font-medium">{destination.name || 'Drop-off Location'}</div>
            </Popup>
          </Marker>
          
          {/* Route line with animated dash effect */}
          <Polyline 
            positions={polylinePath}
            // @ts-ignore - pathOptions is valid but type definition is incorrect
            pathOptions={{ 
              color: '#6366F1', 
              weight: 5, 
              opacity: 0.7,
              dashArray: '10, 10',
              lineCap: 'round'
            }}
          />
          
          {/* Traffic simulation overlay */}
          <TrafficOverlay 
            source={[source.lat, source.lng]} 
            destination={[destination.lat, destination.lng]} 
          />
          
          {/* Auto-zoom to fit markers */}
          <SetBoundsToMarkers markers={markers} />
        </MapContainer>
      </div>
      
      {/* Map controls - nice UI for switching layers */}
      <div className="absolute top-2 right-2 flex flex-col gap-2 z-10">
        <Button
          variant="outline"
          size="sm"
          className="bg-white/90 backdrop-blur-sm shadow-md hover:bg-white"
        >
          Traffic
        </Button>
      </div>
      
      {/* Layer switch button - more user friendly than the default control */}
      <Button
        variant="outline"
        size="icon"
        className="absolute bottom-4 right-4 bg-white shadow-md z-10 hover:bg-gray-100 transition-colors"
        onClick={() => {
          // Find the layers control and click it
          const layersControl = document.querySelector('.leaflet-control-layers-toggle');
          if (layersControl) {
            (layersControl as HTMLElement).click();
          }
        }}
      >
        <Layers className="h-4 w-4" />
      </Button>
      
      {!isMapLoaded && (
        <div className="absolute inset-0 bg-black bg-opacity-20 flex items-center justify-center z-10">
          <div className="text-white text-center">
            <div className="text-lg font-medium">{loadingText}</div>
            <div className="text-sm text-gray-200">{subText}</div>
          </div>
        </div>
      )}
      
      {withBackButton && (
        <Button
          variant="outline"
          size="icon"
          className="absolute top-4 left-4 bg-white shadow-md z-10 hover:bg-gray-100 transition-colors"
          onClick={onBackClick}
        >
          <ArrowLeft className="h-4 w-4" />
        </Button>
      )}
    </motion.div>
  );
};

export default Map;
