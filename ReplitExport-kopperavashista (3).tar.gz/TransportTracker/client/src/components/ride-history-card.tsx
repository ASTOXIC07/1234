import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Ride } from "@shared/schema";
import { motion } from "framer-motion";
import { format } from "date-fns";

interface RideHistoryCardProps {
  ride: Ride;
  onViewDetails: (rideId: number) => void;
}

const RideHistoryCard: React.FC<RideHistoryCardProps> = ({ ride, onViewDetails }) => {
  const formattedDate = ride.createdAt ? format(new Date(ride.createdAt), "MMM d, h:mm a") : "Unknown date";
  
  return (
    <motion.div
      initial={{ y: 20, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 0.3 }}
      className="bg-white rounded-xl shadow p-4 mb-4 custom-shadow"
    >
      <div className="flex justify-between items-start">
        <div>
          <div className="font-medium">Trip to {ride.destination.split(',')[0]}</div>
          <div className="text-sm text-gray-500">{formattedDate}</div>
        </div>
        <div className="text-right">
          <div className="font-semibold">{ride.price}</div>
          <Badge variant="outline" className="bg-green-100 text-green-800 border-green-200">
            {ride.status.charAt(0).toUpperCase() + ride.status.slice(1)}
          </Badge>
        </div>
      </div>
      
      <div className="mt-3 pt-3 border-t border-gray-100">
        <div className="flex items-center text-sm text-gray-600">
          <i className="fas fa-map-marker-alt text-primary mr-2"></i>
          <div>{ride.source.split(',')[0]} → {ride.destination.split(',')[0]}</div>
        </div>
        <div className="flex items-center text-sm text-gray-600 mt-1">
          <i className="fas fa-car text-gray-400 mr-2"></i>
          <div>{ride.rideService} {ride.driver ? `• ${ride.driver}` : ''}</div>
        </div>
      </div>
      
      <Button 
        variant="outline" 
        className="mt-3 w-full border-gray-300 text-gray-700 hover:bg-gray-50"
        onClick={() => onViewDetails(ride.id)}
      >
        View Details
      </Button>
    </motion.div>
  );
};

export default RideHistoryCard;
