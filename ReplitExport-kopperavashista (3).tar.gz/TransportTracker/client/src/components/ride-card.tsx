import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { RideService } from "@shared/schema";
import { motion } from "framer-motion";
import { useLocation } from "wouter";
import { Check } from "lucide-react";

interface RideCardProps {
  service: RideService;
  onClick?: () => void;
  selected?: boolean;
}

const RideCard: React.FC<RideCardProps> = ({ service, onClick, selected = false }) => {
  const [, navigate] = useLocation();

  const handleSelectRide = () => {
    if (onClick) {
      onClick();
    } else {
      navigate(`/ride-details/${service.id}`);
    }
  };

  return (
    <motion.div
      initial={{ y: 20, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 0.3 }}
      whileHover={{ y: -4, boxShadow: "0 10px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04)" }}
      className={`ride-card bg-white rounded-xl shadow p-4 mb-4 custom-shadow border-2 ${selected ? 'border-primary' : 'border-transparent'}`}
    >
      <div className="flex justify-between items-center mb-3">
        <div className="flex items-center">
          <div className={`h-10 w-10 rounded-full ${service.logoColor} flex items-center justify-center relative`}>
            <i className={`fas ${service.logoIcon} text-${service.logoColor.replace('bg-', '')}-500`}></i>
            {selected && (
              <div className="absolute -top-2 -right-2 bg-primary text-white rounded-full h-5 w-5 flex items-center justify-center">
                <Check className="h-3 w-3" />
              </div>
            )}
          </div>
          <div className="ml-3">
            <div className="font-medium">{service.name}</div>
            <div className="text-sm text-gray-500">{service.eta} min away</div>
          </div>
        </div>
        <div className="text-right">
          <div className="text-lg font-semibold">${service.price.toFixed(2)}</div>
          <div className="text-sm text-gray-500">{service.duration} min</div>
        </div>
      </div>
      
      <div className={`${selected ? 'bg-primary/5' : 'bg-gray-50'} rounded-lg p-2 text-sm text-gray-600`}>
        <div className="flex items-center mb-1">
          <i className="fas fa-user-friends mr-2 text-gray-400"></i>
          <span>{service.seatsAvailable} seats available</span>
        </div>
        {service.features.map((feature, index) => (
          <div className="flex items-center" key={index}>
            <i className={`${feature.includes('%') ? 'fas fa-tag text-status-success' : 'fas fa-info-circle'} mr-2 ${feature.includes('%') ? 'text-status-success' : 'text-gray-400'}`}></i>
            <span className={feature.includes('%') ? 'text-status-success' : ''}>{feature}</span>
          </div>
        ))}
      </div>
      
      <Button 
        variant={selected ? "default" : "outline"}
        className={`mt-3 w-full ${selected ? '' : 'border-primary text-primary hover:bg-primary hover:text-white'}`}
        onClick={handleSelectRide}
      >
        {selected ? "Selected" : "Select Ride"}
      </Button>
    </motion.div>
  );
};

export default RideCard;
