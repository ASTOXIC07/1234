import { useEffect, useState } from 'react';
import { ArrowRight, Clock, TrendingDown, TrendingUp, AlertTriangle, BarChart3 } from 'lucide-react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { RideService } from '@shared/schema';
import { TripPrediction, useAIService } from '@/lib/ai-service';
import { Line, Bar } from 'react-chartjs-2';
import { Chart as ChartJS, CategoryScale, LinearScale, PointElement, LineElement, Title, Tooltip, Legend, BarElement } from 'chart.js';

// Register Chart.js components
ChartJS.register(CategoryScale, LinearScale, PointElement, LineElement, Title, Tooltip, Legend, BarElement);

interface RideAnalysisProps {
  source: { lat: number; lng: number };
  destination: { lat: number; lng: number };
  selectedService?: RideService;
  onSelectAlternateRoute?: (routeId: string) => void;
}

export function RideAnalysis({ source, destination, selectedService, onSelectAlternateRoute }: RideAnalysisProps) {
  const aiService = useAIService();
  const [prediction, setPrediction] = useState<TripPrediction | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    async function fetchPrediction() {
      try {
        setIsLoading(true);
        // Generate current date for prediction
        const departureTime = new Date();
        // Get weather condition (would come from a weather API in production)
        const weather = Math.random() > 0.7 ? 'rain' : 'clear';
        
        // Get prediction from AI service
        const result = await aiService.predictTrip(
          source,
          destination,
          departureTime,
          { weather: weather as any, historyFactor: 1.0 }
        );
        
        setPrediction(result);
      } catch (error) {
        console.error('Failed to get trip prediction:', error);
      } finally {
        setIsLoading(false);
      }
    }
    
    fetchPrediction();
  }, [source, destination, aiService]);

  // Color mapping for traffic levels
  const trafficColorMap = {
    'Low': 'bg-green-500',
    'Moderate': 'bg-yellow-500',
    'High': 'bg-orange-500',
    'Very High': 'bg-red-500'
  };
  
  // Price data for chart
  const priceData = {
    labels: ['6 AM', '9 AM', '12 PM', '3 PM', '6 PM', '9 PM'],
    datasets: [
      {
        label: 'Average Price',
        data: [15, 22, 18, 17, 23, 19],
        borderColor: 'rgb(75, 192, 192)',
        backgroundColor: 'rgba(75, 192, 192, 0.2)',
        tension: 0.3
      }
    ]
  };
  
  // Time data for chart
  const timeData = {
    labels: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
    datasets: [
      {
        label: 'Average Travel Time (min)',
        data: [24, 22, 25, 27, 30, 18, 15],
        backgroundColor: 'rgba(99, 102, 241, 0.5)',
        borderColor: 'rgb(99, 102, 241)',
        borderWidth: 1
      }
    ]
  };
  
  // Loading state and animation
  if (isLoading) {
    return (
      <Card className="w-full overflow-hidden">
        <CardHeader className="pb-2">
          <CardTitle className="flex items-center">
            <div className="animate-pulse bg-muted h-6 w-1/3 rounded"></div>
          </CardTitle>
          <CardDescription>
            <div className="animate-pulse bg-muted h-4 w-2/3 rounded mt-2"></div>
          </CardDescription>
        </CardHeader>
        <CardContent className="py-2">
          <div className="space-y-4">
            <div className="animate-pulse bg-muted h-32 w-full rounded"></div>
            <div className="animate-pulse bg-muted h-24 w-full rounded"></div>
          </div>
        </CardContent>
      </Card>
    );
  }
  
  // No prediction data
  if (!prediction) {
    return (
      <Card className="w-full overflow-hidden">
        <CardHeader className="pb-2">
          <CardTitle>Unable to Analyze Trip</CardTitle>
          <CardDescription>
            We couldn't generate an analysis for this trip. Please try again later.
          </CardDescription>
        </CardHeader>
      </Card>
    );
  }
  
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
    >
      <Card className="w-full overflow-hidden shadow-lg">
        <CardHeader className="pb-2 border-b">
          <CardTitle className="flex items-center text-xl">
            <BarChart3 className="mr-2 h-5 w-5 text-primary" />
            AI-Powered Trip Analysis
          </CardTitle>
          <CardDescription>
            Smart recommendations based on traffic patterns and historical data
          </CardDescription>
        </CardHeader>
        
        <CardContent className="pt-4">
          <Tabs defaultValue="overview" className="w-full">
            <TabsList className="w-full grid grid-cols-3 mb-4">
              <TabsTrigger value="overview">Overview</TabsTrigger>
              <TabsTrigger value="routes">Route Options</TabsTrigger>
              <TabsTrigger value="trends">Trends</TabsTrigger>
            </TabsList>
            
            {/* Overview Tab */}
            <TabsContent value="overview" className="space-y-4">
              {/* Primary Analysis Card */}
              <div className="grid grid-cols-2 gap-4">
                <div className="col-span-2 md:col-span-1">
                  <div className="p-4 rounded-lg bg-muted">
                    <div className="flex items-center justify-between mb-2">
                      <h3 className="font-semibold text-lg">Estimated Time</h3>
                      <Badge variant={prediction.trafficLevel === 'Low' ? 'default' : 'destructive'}>
                        {prediction.trafficLevel} Traffic
                      </Badge>
                    </div>
                    
                    <div className="flex items-baseline gap-2">
                      <span className="text-3xl font-bold">{prediction.estimatedTime}</span>
                      <span className="text-sm text-muted-foreground">minutes</span>
                    </div>
                    
                    <div className="mt-3">
                      <div className="flex justify-between text-sm mb-1">
                        <span>Prediction confidence</span>
                        <span>{prediction.confidence}%</span>
                      </div>
                      <Progress value={prediction.confidence} className="h-2" />
                    </div>
                  </div>
                </div>
                
                <div className="col-span-2 md:col-span-1">
                  <div className="p-4 rounded-lg bg-muted">
                    <div className="flex items-center justify-between mb-2">
                      <h3 className="font-semibold text-lg">Price Estimate</h3>
                      {prediction.priceEstimate.surgeMultiplier && (
                        <Badge variant="destructive">
                          Surge x{prediction.priceEstimate.surgeMultiplier}
                        </Badge>
                      )}
                    </div>
                    
                    <div className="flex items-baseline gap-2">
                      <span className="text-3xl font-bold">
                        ${prediction.priceEstimate.minPrice}
                      </span>
                      <span className="text-sm text-muted-foreground">
                        - ${prediction.priceEstimate.maxPrice}
                      </span>
                    </div>
                    
                    <div className="mt-3 text-sm text-muted-foreground">
                      {prediction.priceEstimate.surgeMultiplier 
                        ? "Surge pricing is in effect due to high demand" 
                        : "Standard pricing is in effect"}
                    </div>
                  </div>
                </div>
              </div>
              
              {/* Recommendation */}
              <div className="bg-primary/10 p-4 rounded-lg border border-primary/20">
                <div className="flex gap-3">
                  {prediction.trafficLevel === 'High' || prediction.trafficLevel === 'Very High' 
                    ? <AlertTriangle className="h-5 w-5 text-amber-600 flex-shrink-0 mt-0.5" />
                    : <Clock className="h-5 w-5 text-primary flex-shrink-0 mt-0.5" />
                  }
                  <div>
                    <h3 className="font-medium mb-1">Smart Recommendation</h3>
                    <p className="text-sm">{prediction.recommendation}</p>
                  </div>
                </div>
              </div>
            </TabsContent>
            
            {/* Routes Tab */}
            <TabsContent value="routes" className="space-y-4">
              <div className="grid gap-3">
                {prediction.alternateRoutes?.map((route) => (
                  <div 
                    key={route.id}
                    className="p-3 rounded-lg border hover:border-primary/50 hover:bg-muted/50 transition-colors"
                  >
                    <div className="flex justify-between items-center">
                      <div>
                        <h3 className="font-medium capitalize">{route.id} Route</h3>
                        <p className="text-sm text-muted-foreground">{route.description}</p>
                      </div>
                      <Badge variant="outline">{route.estimatedTime} min</Badge>
                    </div>
                    
                    <div className="flex items-center justify-between mt-3">
                      <div className="flex items-center gap-2">
                        <div className={`h-2 w-2 rounded-full ${trafficColorMap[route.trafficLevel]}`}></div>
                        <span className="text-xs">{route.trafficLevel} traffic</span>
                        <span className="text-xs text-muted-foreground">·</span>
                        <span className="text-xs">{route.distance} km</span>
                      </div>
                      
                      <Button 
                        variant="ghost" 
                        size="sm"
                        onClick={() => onSelectAlternateRoute?.(route.id)}
                      >
                        Select
                        <ArrowRight className="ml-2 h-3 w-3" />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </TabsContent>
            
            {/* Trends Tab */}
            <TabsContent value="trends" className="space-y-4">
              <div className="space-y-6">
                <div>
                  <h3 className="text-sm font-medium mb-2">Price Trends (24 Hours)</h3>
                  <div className="h-48">
                    <Line 
                      data={priceData}
                      options={{
                        responsive: true,
                        maintainAspectRatio: false,
                        scales: {
                          y: {
                            beginAtZero: true,
                            ticks: {
                              callback: (value) => `$${value}`
                            }
                          }
                        },
                        plugins: {
                          legend: {
                            display: false
                          }
                        }
                      }}
                    />
                  </div>
                </div>
                
                <div>
                  <h3 className="text-sm font-medium mb-2">Travel Time by Day</h3>
                  <div className="h-48">
                    <Bar 
                      data={timeData} 
                      options={{
                        responsive: true,
                        maintainAspectRatio: false,
                        scales: {
                          y: {
                            beginAtZero: true
                          }
                        },
                        plugins: {
                          legend: {
                            display: false
                          }
                        }
                      }}
                    />
                  </div>
                </div>
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
        
        <CardFooter className="pt-0 flex justify-between text-xs text-muted-foreground border-t mt-4 pt-3">
          <div className="flex items-center gap-1">
            <span>{selectedService?.name || 'All services'}</span>
            {selectedService && (
              <>
                <span>·</span>
                <span>Base price: ${(selectedService.price - 5).toFixed(2)}</span>
              </>
            )}
          </div>
          
          <div className="flex items-center gap-1">
            {prediction.confidence >= 80 ? (
              <TrendingUp className="h-3 w-3 text-green-500" />
            ) : (
              <TrendingDown className="h-3 w-3 text-amber-500" />
            )}
            <span>Prediction accuracy: {prediction.confidence}%</span>
          </div>
        </CardFooter>
      </Card>
    </motion.div>
  );
}