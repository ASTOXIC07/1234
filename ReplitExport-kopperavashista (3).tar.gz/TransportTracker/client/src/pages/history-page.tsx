import { useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import { useLocation } from 'wouter';
import { motion } from 'framer-motion';
import NavBar from '@/components/nav-bar';
import MobileNav from '@/components/mobile-nav';
import RideHistoryCard from '@/components/ride-history-card';
import { Ride } from '@shared/schema';
import { Loader2 } from 'lucide-react';

export default function HistoryPage() {
  const [, navigate] = useLocation();
  
  // Fetch ride history
  const { data: rides, isLoading, error } = useQuery<Ride[]>({
    queryKey: ['/api/rides'],
  });
  
  const handleViewDetails = (rideId: number) => {
    // For demo purposes, we'll navigate to the ride tracking page
    // In a real app, this would go to a detailed view of the completed ride
    navigate(`/ride-tracking/${rideId}`);
  };
  
  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }
  
  return (
    <div className="min-h-screen bg-gray-50 flex flex-col pb-24 md:pb-0">
      <NavBar />
      
      <main className="flex-1 p-4">
        <motion.div
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ duration: 0.3 }}
        >
          <h2 className="text-xl font-medium mb-4">Your Ride History</h2>
          
          {rides && rides.length > 0 ? (
            rides.map((ride, index) => (
              <RideHistoryCard 
                key={ride.id} 
                ride={ride} 
                onViewDetails={handleViewDetails} 
              />
            ))
          ) : (
            <div className="bg-white rounded-xl shadow p-6 text-center">
              <i className="fas fa-route text-gray-400 text-4xl mb-3"></i>
              <h3 className="text-lg font-medium mb-2">No rides yet</h3>
              <p className="text-gray-500">
                You haven't taken any rides yet. Book a ride to get started!
              </p>
            </div>
          )}
        </motion.div>
      </main>
      
      <MobileNav />
    </div>
  );
}
