import { useState } from 'react';
import { useParams, useLocation } from 'wouter';
import { useMutation, useQuery } from '@tanstack/react-query';
import { apiRequest, queryClient } from '@/lib/queryClient';
import { motion, AnimatePresence } from 'framer-motion';
import { useToast } from '@/hooks/use-toast';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import Map from '@/components/map';
import { Loader2 } from 'lucide-react';
import { getRideService } from '@/utils/ride-services';
import { InsertRide } from '@shared/schema';

export default function RideDetailsPage() {
  const { serviceId } = useParams();
  const { toast } = useToast();
  const [, navigate] = useLocation();
  const [showConfirmModal, setShowConfirmModal] = useState(false);
  
  // Get ride service details
  const service = getRideService(serviceId || '');
  
  // Get payment methods
  const { data: paymentMethods } = useQuery({
    queryKey: ['/api/payment-methods'],
  });
  
  // Default payment method with fallback
  let defaultPaymentMethod: { lastFour?: string; isDefault?: boolean } = { lastFour: '4589' };
  
  // Use type assertion to safely work with paymentMethods if available
  if (paymentMethods && Array.isArray(paymentMethods)) {
    const methods = paymentMethods as Array<{ lastFour: string; isDefault: boolean }>;
    defaultPaymentMethod = methods.find(pm => pm.isDefault) || methods[0] || defaultPaymentMethod;
  }
  
  // Book ride mutation
  const bookRideMutation = useMutation({
    mutationFn: async (rideData: Partial<InsertRide>) => {
      const res = await apiRequest('POST', '/api/rides', rideData);
      return await res.json();
    },
    onSuccess: (data) => {
      toast({
        title: 'Booking Confirmed!',
        description: 'Your ride has been booked successfully.',
      });
      setShowConfirmModal(true);
      queryClient.invalidateQueries({ queryKey: ['/api/rides'] });
    },
    onError: (error: Error) => {
      toast({
        title: 'Booking failed',
        description: error.message,
        variant: 'destructive',
      });
    },
  });
  
  const handleConfirmRide = () => {
    if (!service) {
      toast({
        title: 'Error',
        description: 'Ride service not found.',
        variant: 'destructive',
      });
      return;
    }
    
    bookRideMutation.mutate({
      source: '123 Main St, San Francisco',
      destination: 'Golden Gate Park',
      rideService: service.name,
      driver: 'John Driver',
      price: `$${service.price.toFixed(2)}`,
      status: 'booked',
    });
  };
  
  const handleTrackRide = () => {
    // Assuming the first ride is the one we just created
    navigate('/ride-tracking/1');
  };
  
  const handleGoBack = () => {
    navigate('/');
  };
  
  if (!service) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <p>Ride service not found.</p>
          <Button className="mt-4" onClick={handleGoBack}>
            Go Back
          </Button>
        </div>
      </div>
    );
  }
  
  // Define source and destination coordinates
  const sourceCoords = {
    lat: 37.7749,
    lng: -122.4194,
    name: '123 Main St, San Francisco'
  };
  
  const destinationCoords = {
    lat: 37.7694,
    lng: -122.4862,
    name: 'Golden Gate Park'
  };

  return (
    <div className="bg-white min-h-screen pb-24 md:pb-0">
      <Map 
        height="h-64 md:h-96" 
        withBackButton 
        onBackClick={handleGoBack}
        loadingText="Route Map"
        subText="Showing optimal route to destination"
        source={sourceCoords}
        destination={destinationCoords}
        routeVariation={0.08} // Slight curve to show optimal route
      />
      
      <div className="p-4">
        <motion.div
          className="bg-white rounded-xl shadow-lg p-4 -mt-10 relative"
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ duration: 0.3 }}
        >
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-xl font-medium">{service.name}</h2>
            <div className="text-lg font-semibold">${service.price.toFixed(2)}</div>
          </div>
          
          <div className="flex items-center mb-6">
            <div className="h-12 w-12 rounded-full bg-gray-200 flex items-center justify-center">
              <i className={`fas ${service.logoIcon} text-${service.logoColor.replace('bg-', '')}-500`}></i>
            </div>
            <div className="ml-3">
              <div className="font-medium">John Driver</div>
              <div className="text-sm text-gray-500">Toyota Camry • ABC123</div>
            </div>
            <div className="ml-auto flex space-x-2">
              <Button variant="outline" size="icon" className="h-10 w-10 rounded-full">
                <i className="fas fa-phone text-primary"></i>
              </Button>
              <Button variant="outline" size="icon" className="h-10 w-10 rounded-full">
                <i className="fas fa-comment text-primary"></i>
              </Button>
            </div>
          </div>
          
          <div className="bg-gray-50 rounded-lg p-3 mb-4">
            <div className="flex items-start mb-3">
              <div className="mt-2 mr-2">
                <div className="h-5 w-5 rounded-full bg-primary flex items-center justify-center">
                  <div className="h-2 w-2 rounded-full bg-white"></div>
                </div>
              </div>
              <div>
                <div className="text-xs text-gray-500">PICKUP</div>
                <div>123 Main St, San Francisco</div>
              </div>
              <div className="ml-auto">
                <div className="text-xs text-gray-500">ETA</div>
                <div>{service.eta} min</div>
              </div>
            </div>
            
            <div className="border-l-2 border-dashed border-gray-300 h-6 ml-2.5"></div>
            
            <div className="flex items-start">
              <div className="mt-2 mr-2">
                <div className="h-5 w-5 rounded-full bg-accent flex items-center justify-center">
                  <div className="h-2 w-2 rounded-full bg-white"></div>
                </div>
              </div>
              <div>
                <div className="text-xs text-gray-500">DESTINATION</div>
                <div>Golden Gate Park</div>
              </div>
              <div className="ml-auto">
                <div className="text-xs text-gray-500">ARRIVAL</div>
                <div>{new Date(Date.now() + service.duration * 60000).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</div>
              </div>
            </div>
          </div>
          
          <Separator className="my-4" />
          
          <div>
            <h3 className="font-medium mb-2">Payment Method</h3>
            <div className="flex items-center justify-between bg-gray-50 p-3 rounded-lg">
              <div className="flex items-center">
                <div className="h-8 w-8 bg-blue-100 rounded flex items-center justify-center">
                  <i className="fab fa-cc-visa text-blue-800"></i>
                </div>
                <span className="ml-3">Visa ****{defaultPaymentMethod?.lastFour || '4589'}</span>
              </div>
              <Button variant="link" className="text-primary text-sm font-medium">
                Change
              </Button>
            </div>
          </div>
          
          <Button
            className="mt-6 w-full py-3"
            size="lg"
            onClick={handleConfirmRide}
            disabled={bookRideMutation.isPending}
          >
            {bookRideMutation.isPending ? (
              <>
                <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                Processing...
              </>
            ) : (
              "Confirm Ride"
            )}
          </Button>
        </motion.div>
      </div>
      
      <AnimatePresence>
        {showConfirmModal && (
          <motion.div
            className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-20"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
          >
            <motion.div
              className="bg-white rounded-xl p-6 max-w-sm mx-4"
              initial={{ scale: 0.9, y: 50 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.9, y: 50 }}
            >
              <div className="flex justify-center mb-4">
                <div className="h-16 w-16 rounded-full bg-green-500 flex items-center justify-center text-white">
                  <i className="fas fa-check text-2xl"></i>
                </div>
              </div>
              <h3 className="text-xl font-medium text-center mb-2">Booking Confirmed!</h3>
              <p className="text-center text-gray-600 mb-4">Your ride has been booked successfully. Your driver is on the way.</p>
              <div className="bg-gray-50 rounded-lg p-3 mb-4">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm font-medium">Estimated arrival</span>
                  <span className="font-medium">{service.eta} minutes</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium">Ride fare</span>
                  <span className="font-medium">${service.price.toFixed(2)}</span>
                </div>
              </div>
              <Button className="w-full py-3" size="lg" onClick={handleTrackRide}>
                Track Your Ride
              </Button>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
