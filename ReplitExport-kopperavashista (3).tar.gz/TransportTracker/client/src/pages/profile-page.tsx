import { useState } from 'react';
import { useAuth } from '@/hooks/use-auth';
import { useLocation } from 'wouter';
import { motion } from 'framer-motion';
import { useQuery } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import NavBar from '@/components/nav-bar';
import MobileNav from '@/components/mobile-nav';
import { Loader2 } from 'lucide-react';

export default function ProfilePage() {
  const { user, logoutMutation } = useAuth();
  const [, navigate] = useLocation();
  
  // Get payment methods
  const { data: paymentMethods } = useQuery({
    queryKey: ['/api/payment-methods'],
  });
  
  const getInitials = (name?: string): string => {
    if (!name) return user?.username?.substring(0, 2).toUpperCase() || "U";
    return name
      .split(" ")
      .map((n) => n[0])
      .join("")
      .toUpperCase();
  };
  
  const handleSignOut = () => {
    if (confirm('Are you sure you want to sign out?')) {
      logoutMutation.mutate();
    }
  };
  
  return (
    <div className="min-h-screen bg-gray-50 flex flex-col pb-24 md:pb-0">
      <NavBar />
      
      <main className="flex-1 p-4">
        <motion.div
          className="bg-white rounded-xl shadow p-6 mb-4"
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ duration: 0.3 }}
        >
          <div className="flex flex-col items-center mb-4">
            <Avatar className="h-20 w-20 bg-primary text-white text-xl font-medium mb-2">
              <AvatarFallback>{getInitials(user?.fullName)}</AvatarFallback>
            </Avatar>
            <h2 className="text-xl font-medium">{user?.fullName || user?.username}</h2>
            <div className="text-gray-500">{user?.email}</div>
          </div>
          
          <div className="space-y-4 mt-6">
            <motion.div 
              className="flex items-center p-3 bg-gray-50 rounded-lg cursor-pointer hover:bg-gray-100 transition-colors"
              whileHover={{ x: 5 }}
            >
              <i className="fas fa-credit-card w-8 text-center text-primary"></i>
              <span className="font-medium">Payment Methods</span>
              <i className="fas fa-chevron-right ml-auto text-gray-400"></i>
            </motion.div>
            
            <motion.div 
              className="flex items-center p-3 bg-gray-50 rounded-lg cursor-pointer hover:bg-gray-100 transition-colors"
              whileHover={{ x: 5 }}
            >
              <i className="fas fa-map-marker-alt w-8 text-center text-primary"></i>
              <span className="font-medium">Saved Locations</span>
              <i className="fas fa-chevron-right ml-auto text-gray-400"></i>
            </motion.div>
            
            <motion.div 
              className="flex items-center p-3 bg-gray-50 rounded-lg cursor-pointer hover:bg-gray-100 transition-colors"
              whileHover={{ x: 5 }}
            >
              <i className="fas fa-bell w-8 text-center text-primary"></i>
              <span className="font-medium">Notifications</span>
              <i className="fas fa-chevron-right ml-auto text-gray-400"></i>
            </motion.div>
            
            <motion.div 
              className="flex items-center p-3 bg-gray-50 rounded-lg cursor-pointer hover:bg-gray-100 transition-colors"
              whileHover={{ x: 5 }}
            >
              <i className="fas fa-shield-alt w-8 text-center text-primary"></i>
              <span className="font-medium">Privacy & Security</span>
              <i className="fas fa-chevron-right ml-auto text-gray-400"></i>
            </motion.div>
            
            <motion.div 
              className="flex items-center p-3 bg-gray-50 rounded-lg cursor-pointer hover:bg-gray-100 transition-colors"
              whileHover={{ x: 5 }}
            >
              <i className="fas fa-question-circle w-8 text-center text-primary"></i>
              <span className="font-medium">Help & Support</span>
              <i className="fas fa-chevron-right ml-auto text-gray-400"></i>
            </motion.div>
          </div>
          
          <Button
            variant="outline"
            className="mt-6 w-full py-3 border-red-500 text-red-500 hover:bg-red-500 hover:text-white"
            onClick={handleSignOut}
            disabled={logoutMutation.isPending}
          >
            {logoutMutation.isPending ? (
              <>
                <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                Signing out...
              </>
            ) : (
              "Sign Out"
            )}
          </Button>
        </motion.div>
      </main>
      
      <MobileNav />
    </div>
  );
}
