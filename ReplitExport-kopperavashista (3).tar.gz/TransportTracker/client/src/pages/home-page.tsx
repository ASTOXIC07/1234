import { useState, useEffect } from 'react';
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { motion, AnimatePresence } from "framer-motion";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { RideService } from "@shared/schema";
import NavBar from "@/components/nav-bar";
import MobileNav from "@/components/mobile-nav";
import Map from "@/components/map";
import RideCard from "@/components/ride-card";
import LocationInput from "@/components/location-input";
import { RideAnalysis } from "@/components/ride-analysis";
import { Loader2, MapPin, Route, Sparkles, ArrowRight } from "lucide-react";

// Geocoding service (simplified for demo without requiring Google Maps API)
const geocodeAddress = async (address: string): Promise<{lat: number, lng: number}> => {
  // This is a mock implementation - in production, you'd use a real geocoding service like Nominatim
  
  // Generate consistent coordinates based on the input string to avoid random jumping
  // Use a simple hash function to generate a consistent offset
  const getHashCode = (str: string) => {
    let hash = 0;
    for (let i = 0; i < str.length; i++) {
      hash = str.charCodeAt(i) + ((hash << 5) - hash);
    }
    return hash;
  };
  
  // Basic locations for known areas
  const knownLocations: Record<string, {lat: number, lng: number}> = {
    'san francisco': { lat: 37.7749, lng: -122.4194 },
    'golden gate park': { lat: 37.7694, lng: -122.4862 },
    'downtown': { lat: 37.7937, lng: -122.3965 },
    'fisherman\'s wharf': { lat: 37.8080, lng: -122.4177 },
    'union square': { lat: 37.7879, lng: -122.4075 },
    'north beach': { lat: 37.7997, lng: -122.4098 },
    'mission district': { lat: 37.7599, lng: -122.4148 },
    'chinatown': { lat: 37.7941, lng: -122.4078 },
    'lombard street': { lat: 37.8021, lng: -122.4186 },
    'palo alto': { lat: 37.4419, lng: -122.1430 },
    'mountain view': { lat: 37.3861, lng: -122.0839 },
    'berkeley': { lat: 37.8715, lng: -122.2730 },
    'oakland': { lat: 37.8044, lng: -122.2711 },
  };
  
  // Check if the address includes any known locations
  const lowerAddress = address.toLowerCase();
  for (const [key, coords] of Object.entries(knownLocations)) {
    if (lowerAddress.includes(key)) {
      // Add a small consistent offset for variations of the same location
      const hash = getHashCode(address);
      const latOffset = (hash % 100) / 10000; // small offset ±0.01
      const lngOffset = ((hash >> 10) % 100) / 10000;
      
      return {
        lat: coords.lat + latOffset,
        lng: coords.lng + lngOffset
      };
    }
  }
  
  // Default to San Francisco with a consistent offset based on string hash
  const hash = getHashCode(address);
  const baseCoords = {
    lat: 37.7749 + (hash % 100) / 2000 - 0.025, // offset ±0.025
    lng: -122.4194 + ((hash >> 10) % 100) / 2000 - 0.025
  };
  
  // Simulate API delay
  await new Promise(resolve => setTimeout(resolve, 300));
  
  return baseCoords;
};

export default function HomePage() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [source, setSource] = useState("123 Main St, San Francisco");
  const [destination, setDestination] = useState("Golden Gate Park, San Francisco");
  const [rideServices, setRideServices] = useState<RideService[]>([]);
  const [isSearching, setIsSearching] = useState(false);
  const [selectedService, setSelectedService] = useState<RideService | undefined>(undefined);
  const [showAnalysis, setShowAnalysis] = useState(false);
  
  // Coordinates for map
  const [sourceCoords, setSourceCoords] = useState<{lat: number, lng: number}>({
    lat: 37.7749, lng: -122.4194
  });
  const [destCoords, setDestCoords] = useState<{lat: number, lng: number}>({
    lat: 37.7694, lng: -122.4862
  });
  
  // Convert addresses to coordinates when they change
  useEffect(() => {
    const updateCoords = async () => {
      try {
        const sourceGeo = await geocodeAddress(source);
        const destGeo = await geocodeAddress(destination);
        
        setSourceCoords(sourceGeo);
        setDestCoords(destGeo);
      } catch (error) {
        console.error("Error geocoding addresses:", error);
      }
    };
    
    if (source && destination) {
      updateCoords();
    }
  }, [source, destination]);
  
  const searchRidesMutation = useMutation({
    mutationFn: async ({ source, destination }: { source: string; destination: string }) => {
      const res = await apiRequest("POST", "/api/search-rides", { source, destination });
      return await res.json() as RideService[];
    },
    onSuccess: (data) => {
      setRideServices(data);
      setIsSearching(false);
      setShowAnalysis(true);
      toast({
        title: "Rides found!",
        description: `We found ${data.length} ride options for you.`,
      });
    },
    onError: (error: Error) => {
      setIsSearching(false);
      toast({
        title: "Error finding rides",
        description: error.message,
        variant: "destructive",
      });
    }
  });
  
  const handleFindRides = () => {
    if (!source || !destination) {
      toast({
        title: "Missing information",
        description: "Please enter both pickup and destination locations.",
        variant: "destructive",
      });
      return;
    }
    
    setIsSearching(true);
    searchRidesMutation.mutate({ source, destination });
  };
  
  const handleSelectRide = (service: RideService) => {
    setSelectedService(service);
    // Scroll to the ride analysis section
    document.getElementById('ride-analysis')?.scrollIntoView({ behavior: 'smooth' });
  };
  
  return (
    <div className="min-h-screen bg-gray-50 flex flex-col pb-24 md:pb-0">
      <NavBar />
      
      <main className="flex-1">
        <Map 
          height="h-56 md:h-80 lg:h-96" 
          source={{
            lat: sourceCoords.lat,
            lng: sourceCoords.lng,
            name: source
          }}
          destination={{
            lat: destCoords.lat,
            lng: destCoords.lng,
            name: destination
          }}
        />
        
        <motion.div
          className="relative px-4 -mt-8 sm:-mt-12"
          initial={{ y: 50, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ duration: 0.4, delay: 0.1 }}
        >
          <div className="bg-white rounded-xl shadow-xl p-4 border border-gray-100">
            <Tabs defaultValue="ride" className="w-full">
              <TabsList className="grid w-full grid-cols-2 mb-4">
                <TabsTrigger value="ride" className="flex gap-2">
                  <Route className="h-4 w-4" />
                  Find a Ride
                </TabsTrigger>
                <TabsTrigger value="smart" className="flex gap-2">
                  <Sparkles className="h-4 w-4" />
                  Smart Analysis
                </TabsTrigger>
              </TabsList>
              
              <TabsContent value="ride" className="space-y-4">
                <div>
                  <h2 className="text-lg font-medium mb-4 flex items-center">
                    <MapPin className="h-5 w-5 mr-2 text-primary" />
                    Where are you going?
                  </h2>
                  
                  <LocationInput
                    id="pickup"
                    label="PICKUP"
                    placeholder="Current location"
                    defaultValue={source}
                    icon="pickup"
                    onChange={(value) => setSource(value)}
                  />
                  
                  <LocationInput
                    id="destination"
                    label="DESTINATION"
                    placeholder="Enter destination"
                    defaultValue={destination}
                    icon="destination"
                    onChange={(value) => setDestination(value)}
                  />
                  
                  <Button
                    className="w-full py-3 mt-6"
                    size="lg"
                    onClick={handleFindRides}
                    disabled={!source || !destination || isSearching}
                  >
                    {isSearching ? (
                      <>
                        <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                        Finding rides...
                      </>
                    ) : (
                      "Find Rides"
                    )}
                  </Button>
                </div>
              </TabsContent>
              
              <TabsContent value="smart" className="space-y-4">
                <div>
                  <h2 className="text-lg font-medium mb-2">AI-Powered Analysis</h2>
                  <p className="text-sm text-muted-foreground mb-4">
                    Get intelligent ride recommendations and traffic predictions powered by machine learning.
                  </p>
                  
                  <div className="space-y-3">
                    <div className="bg-primary/10 p-3 rounded-lg flex gap-3">
                      <div className="h-10 w-10 bg-primary rounded-full flex items-center justify-center flex-shrink-0">
                        <Sparkles className="h-5 w-5 text-white" />
                      </div>
                      <div>
                        <h3 className="font-medium">Smart Features</h3>
                        <p className="text-sm text-muted-foreground">Traffic prediction, price analysis, and route optimization</p>
                      </div>
                    </div>
                    
                    <Button
                      className="w-full"
                      variant="outline"
                      onClick={handleFindRides}
                      disabled={!source || !destination || isSearching}
                    >
                      Analyze My Trip
                      <ArrowRight className="ml-2 h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </TabsContent>
            </Tabs>
          </div>
        </motion.div>
        
        <AnimatePresence>
          {isSearching && (
            <motion.div
              className="fixed inset-0 bg-black bg-opacity-60 backdrop-blur-sm flex flex-col items-center justify-center z-30"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.3 }}
            >
              <div className="h-20 w-20 rounded-full bg-primary flex items-center justify-center mb-4 shadow-lg">
                <div className="flex space-x-2">
                  <div className="loading-dot h-3 w-3 rounded-full bg-white animate-pulse"></div>
                  <div className="loading-dot h-3 w-3 rounded-full bg-white animate-pulse" style={{ animationDelay: '0.2s' }}></div>
                  <div className="loading-dot h-3 w-3 rounded-full bg-white animate-pulse" style={{ animationDelay: '0.4s' }}></div>
                </div>
              </div>
              <h3 className="text-xl font-medium text-white">Finding the best rides for you</h3>
              <p className="text-gray-300 mt-2">Analyzing traffic and ride options...</p>
            </motion.div>
          )}
        </AnimatePresence>
        
        <div className="px-4 sm:px-6 md:px-8 py-6 max-w-5xl mx-auto">
          {showAnalysis && (
            <div className="grid grid-cols-1 md:grid-cols-12 gap-6 mb-6" id="ride-analysis">
              <div className="md:col-span-7">
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5 }}
                >
                  <h2 className="text-xl font-medium mb-4">Available Rides</h2>
                  
                  <div className="space-y-3">
                    {rideServices.map((service) => (
                      <RideCard 
                        key={service.id} 
                        service={service} 
                        onClick={() => handleSelectRide(service)}
                        selected={selectedService?.id === service.id}
                      />
                    ))}
                  </div>
                </motion.div>
              </div>
              
              <div className="md:col-span-5">
                <RideAnalysis 
                  source={sourceCoords}
                  destination={destCoords}
                  selectedService={selectedService}
                />
              </div>
            </div>
          )}
        </div>
      </main>
      
      <MobileNav />
    </div>
  );
}
