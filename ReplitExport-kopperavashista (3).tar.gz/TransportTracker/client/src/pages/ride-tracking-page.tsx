import { useState, useEffect } from 'react';
import { useParams, useLocation } from 'wouter';
import { useQuery, useMutation } from '@tanstack/react-query';
import { apiRequest, queryClient } from '@/lib/queryClient';
import { motion } from 'framer-motion';
import { useToast } from '@/hooks/use-toast';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Alert, AlertDescription } from '@/components/ui/alert';
import Map from '@/components/map';
import { Loader2 } from 'lucide-react';

export default function RideTrackingPage() {
  const { rideId } = useParams();
  const { toast } = useToast();
  const [, navigate] = useLocation();
  const [arrivalTime, setArrivalTime] = useState(4); // minutes
  
  // Get ride details
  const { data: ride, isLoading, error } = useQuery({
    queryKey: [`/api/rides/${rideId}`],
  });
  
  // Cancel ride mutation
  const cancelRideMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest('PATCH', `/api/rides/${rideId}/status`, { status: 'cancelled' });
      return await res.json();
    },
    onSuccess: () => {
      toast({
        title: 'Ride Cancelled',
        description: 'Your ride has been cancelled successfully.',
      });
      queryClient.invalidateQueries({ queryKey: [`/api/rides/${rideId}`] });
      queryClient.invalidateQueries({ queryKey: ['/api/rides'] });
      navigate('/');
    },
    onError: (error: Error) => {
      toast({
        title: 'Error',
        description: error.message,
        variant: 'destructive',
      });
    },
  });
  
  // Simulate driver arrival countdown
  useEffect(() => {
    if (arrivalTime > 0) {
      const timer = setTimeout(() => {
        setArrivalTime(prev => prev - 1);
      }, 60000); // Update every minute
      
      return () => clearTimeout(timer);
    }
  }, [arrivalTime]);
  
  const handleCancelRide = () => {
    if (confirm('Are you sure you want to cancel this ride?')) {
      cancelRideMutation.mutate();
    }
  };
  
  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }
  
  if (error || !ride) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <p>Failed to load ride details.</p>
          <Button className="mt-4" onClick={() => navigate('/')}>
            Go Home
          </Button>
        </div>
      </div>
    );
  }
  
  // Mock the ride data with source and destination coordinates
  const sourceLocation = {
    lat: 37.7749,
    lng: -122.4194,
    name: (ride as any).source || 'Pickup Location' 
  };
  
  const destinationLocation = {
    lat: 37.7694,
    lng: -122.4862,
    name: (ride as any).destination || 'Drop-off Location'
  };
  
  // Driver location is slightly away from the pickup to simulate movement
  const driverLocation = {
    lat: sourceLocation.lat + (arrivalTime > 0 ? 0.005 * arrivalTime : 0), 
    lng: sourceLocation.lng + (arrivalTime > 0 ? 0.003 * arrivalTime : 0)
  };

  return (
    <div className="bg-white min-h-screen pb-24 md:pb-0">
      <Map 
        fullScreen 
        loadingText="Live Tracking"
        subText="Your driver is on the way"
        source={sourceLocation}
        destination={destinationLocation}
        routeVariation={0.15} // More curved route for realistic driving path
      />
      
      <motion.div
        className="absolute bottom-16 left-1/2 transform -translate-x-1/2 bg-white/90 backdrop-blur-sm px-6 py-3 rounded-full shadow-lg text-center z-10 border border-primary/10"
        initial={{ y: 50, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 0.3, delay: 0.2 }}
      >
        <div className="flex items-center gap-2">
          <div className="relative flex-shrink-0">
            <div className="w-3 h-3 bg-green-500 rounded-full animate-ping absolute"></div>
            <div className="w-3 h-3 bg-green-500 rounded-full relative"></div>
          </div>
          <div className="text-sm font-medium">
            {arrivalTime > 0 
              ? `Arriving in ${arrivalTime} minute${arrivalTime !== 1 ? 's' : ''}` 
              : 'Driver has arrived'}
          </div>
        </div>
      </motion.div>
      
      <div className="p-4">
        <motion.div
          className="bg-white rounded-xl shadow-lg p-4"
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ duration: 0.3 }}
        >
          <div className="flex items-center mb-6">
            <div className="h-14 w-14 rounded-full bg-gray-200"></div>
            <div className="ml-3">
              <div className="font-medium">{(ride as any).driver || 'John Driver'}</div>
              <div className="text-sm text-gray-500">Toyota Camry • ABC123</div>
              <div className="flex items-center mt-1">
                <i className="fas fa-star text-yellow-400 text-xs"></i>
                <i className="fas fa-star text-yellow-400 text-xs"></i>
                <i className="fas fa-star text-yellow-400 text-xs"></i>
                <i className="fas fa-star text-yellow-400 text-xs"></i>
                <i className="fas fa-star-half-alt text-yellow-400 text-xs"></i>
                <span className="text-xs text-gray-500 ml-1">4.8 (342 rides)</span>
              </div>
            </div>
            <div className="ml-auto flex space-x-2">
              <Button variant="outline" size="icon" className="h-10 w-10 rounded-full">
                <i className="fas fa-phone text-primary"></i>
              </Button>
              <Button variant="outline" size="icon" className="h-10 w-10 rounded-full">
                <i className="fas fa-comment text-primary"></i>
              </Button>
            </div>
          </div>
          
          <Alert className="bg-blue-50 border border-blue-100 mb-4">
            <AlertDescription className="text-blue-700 flex items-center">
              <i className="fas fa-info-circle mr-2"></i>
              <span className="text-sm">
                {arrivalTime > 0 
                  ? `Driver is ${arrivalTime} minute${arrivalTime !== 1 ? 's' : ''} away` 
                  : 'Driver has arrived at pickup location'}
              </span>
            </AlertDescription>
          </Alert>
          
          <Button
            variant="outline"
            className="mt-2 w-full py-3 border-red-500 text-red-500 hover:bg-red-500 hover:text-white"
            onClick={handleCancelRide}
            disabled={cancelRideMutation.isPending}
          >
            {cancelRideMutation.isPending ? (
              <>
                <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                Cancelling...
              </>
            ) : (
              "Cancel Ride"
            )}
          </Button>
        </motion.div>
      </div>
    </div>
  );
}
