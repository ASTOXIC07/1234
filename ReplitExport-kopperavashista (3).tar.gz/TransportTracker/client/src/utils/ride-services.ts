import { RideService } from "@shared/schema";

// Mock ride services data
const rideServices: RideService[] = [
  {
    id: "uber-x",
    name: "UberX",
    logoColor: "bg-blue-100",
    logoIcon: "fa-car",
    eta: 4,
    price: 18.75,
    duration: 12,
    seatsAvailable: 4,
    features: ["10% off with code RIDE10"]
  },
  {
    id: "lyft",
    name: "Lyft",
    logoColor: "bg-green-100",
    logoIcon: "fa-car-side",
    eta: 2,
    price: 20.50,
    duration: 10,
    seatsAvailable: 3,
    features: ["Top rated driver"]
  },
  {
    id: "yellow-cab",
    name: "Yellow Cab",
    logoColor: "bg-yellow-100",
    logoIcon: "fa-taxi",
    eta: 8,
    price: 15.25,
    duration: 15,
    seatsAvailable: 4,
    features: ["Cash payment available"]
  }
];

export function getRideServices(): RideService[] {
  return rideServices;
}

export function getRideService(id: string): RideService | undefined {
  return rideServices.find(service => service.id === id);
}
