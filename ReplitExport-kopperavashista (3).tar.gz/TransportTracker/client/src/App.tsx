import { QueryClientProvider } from "@tanstack/react-query";
import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { Toaster } from "@/components/ui/toaster";
import NotFound from "@/pages/not-found";
import { AuthProvider } from "@/hooks/use-auth";
import { ProtectedRoute } from "./lib/protected-route";
import { motion } from "framer-motion";

// Pages
import AuthPage from "@/pages/auth-page";
import HomePage from "@/pages/home-page";
import RideDetailsPage from "@/pages/ride-details-page";
import RideTrackingPage from "@/pages/ride-tracking-page";
import HistoryPage from "@/pages/history-page";
import ProfilePage from "@/pages/profile-page";

function Router() {
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.3 }}
      className="app-wrapper"
    >
      <Switch>
        <Route path="/auth" component={AuthPage} />
        <ProtectedRoute path="/" component={HomePage} />
        <ProtectedRoute path="/ride-details/:serviceId" component={RideDetailsPage} />
        <ProtectedRoute path="/ride-tracking/:rideId" component={RideTrackingPage} />
        <ProtectedRoute path="/history" component={HistoryPage} />
        <ProtectedRoute path="/profile" component={ProfilePage} />
        <Route component={NotFound} />
      </Switch>
    </motion.div>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <Router />
        <Toaster />
      </AuthProvider>
    </QueryClientProvider>
  );
}

export default App;
